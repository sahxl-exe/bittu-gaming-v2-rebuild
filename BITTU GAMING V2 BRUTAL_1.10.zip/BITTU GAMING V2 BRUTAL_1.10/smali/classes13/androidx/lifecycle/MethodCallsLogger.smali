.class public Landroidx/lifecycle/MethodCallsLogger;
.super Ljava/lang/Object;
.source "MethodCallsLogger.java"

.field private mCalledMethods:Ljava/util/Map;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/MethodCallsLogger;->mCalledMethods:Ljava/util/Map;
    .line 10: return-void
.end method

# virtual methods
.method public approveCall(Ljava/lang/String;I)Z
    .registers 10

    .line 0: iget-object v0, v7, Landroidx/lifecycle/MethodCallsLogger;->mCalledMethods:Ljava/util/Map;
    .line 2: invoke-interface {v0, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ljava/lang/Integer;
    .line 8: const/4 v1, 0
    .line 9: if-eqz v0, :cond_16
    .line 11: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    .line 14: move-result v2
    .line 15: goto :goto_17
    .line 16: const/4 v2, 0
    .line 17: and-int v3, v2, v9
    .line 19: const/4 v4, 1
    .line 20: if-eqz v3, :cond_24
    .line 22: const/4 v3, 1
    .line 23: goto :goto_25
    .line 24: const/4 v3, 0
    .line 25: iget-object v5, v7, Landroidx/lifecycle/MethodCallsLogger;->mCalledMethods:Ljava/util/Map;
    .line 27: or-int v6, v2, v9
    .line 29: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 32: move-result-object v6
    .line 33: invoke-interface {v5, v8, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 36: if-nez v3, :cond_39
    .line 38: const/4 v1, 1
    .line 39: return v1
.end method
