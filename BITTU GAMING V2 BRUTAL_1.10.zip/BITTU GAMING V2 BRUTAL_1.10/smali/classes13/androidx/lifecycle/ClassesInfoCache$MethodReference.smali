.class final Landroidx/lifecycle/ClassesInfoCache$MethodReference;
.super Ljava/lang/Object;
.source "ClassesInfoCache.java"

.field final mCallType:I
.field final mMethod:Ljava/lang/reflect/Method;

# direct methods
.method constructor <init>(ILjava/lang/reflect/Method;)V
    .registers 4

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: iput v2, v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mCallType:I
    .line 5: iput-object v3, v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 7: const/4 v0, 1
    .line 8: invoke-virtual {v3, v0}, Ljava/lang/reflect/Method;->setAccessible(Z)V
    .line 11: return-void
.end method

# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7

    .line 0: const/4 v0, 1
    .line 1: if-ne v5, v6, :cond_4
    .line 3: return v0
    .line 4: instance-of v1, v6, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 6: const/4 v2, 0
    .line 7: if-nez v1, :cond_10
    .line 9: return v2
    .line 10: move-object v1, v6
    .line 11: check-cast v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 13: iget v3, v5, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mCallType:I
    .line 15: iget v4, v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mCallType:I
    .line 17: if-ne v3, v4, :cond_38
    .line 19: iget-object v3, v5, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 21: invoke-virtual {v3}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 24: move-result-object v3
    .line 25: iget-object v4, v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 27: invoke-virtual {v4}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 30: move-result-object v4
    .line 31: invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    .line 34: move-result v3
    .line 35: if-eqz v3, :cond_38
    .line 37: goto :goto_39
    .line 38: const/4 v0, 0
    .line 39: return v0
.end method

# virtual methods
.method public hashCode()I
    .registers 3

    .line 0: iget v0, v2, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mCallType:I
    .line 2: mul-int/lit8 v0, v0, 31
    .line 4: iget-object v1, v2, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 6: invoke-virtual {v1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 9: move-result-object v1
    .line 10: invoke-virtual {v1}, Ljava/lang/String;->hashCode()I
    .line 13: move-result v1
    .line 14: add-int/2addr v0, v1
    .line 15: return v0
.end method

# virtual methods
.method  invokeCallback(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .registers 8

    .line 0: iget v0, v4, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mCallType:I
    .line 2: const/4 v1, 1
    .line 3: const/4 v2, 0
    .line 4: packed-switch v0, :data_62
    .line 7: goto :goto_39
    .line 8: iget-object v0, v4, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 10: const/4 v3, 2
    .line 11: new-array v3, v3, [Ljava/lang/Object;
    .line 13: aput-object v5, v3, v2
    .line 15: aput-object v6, v3, v1
    .line 17: invoke-virtual {v0, v7, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 20: goto :goto_39
    .line 21: iget-object v0, v4, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 23: new-array v1, v1, [Ljava/lang/Object;
    .line 25: aput-object v5, v1, v2
    .line 27: invoke-virtual {v0, v7, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 30: goto :goto_39
    .line 31: iget-object v0, v4, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 33: new-array v1, v2, [Ljava/lang/Object;
    .line 35: invoke-virtual {v0, v7, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 38: nop
    .line 39: nop
    .line 40: return-void
    .line 41: move-exception v0
    .line 42: new-instance v1, Ljava/lang/RuntimeException;
    .line 44: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 47: throw v1
    .line 48: move-exception v0
    .line 49: new-instance v1, Ljava/lang/RuntimeException;
    .line 51: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 54: move-result-object v2
    .line 55: const-string v3, "Failed to call observer method"
    .line 57: invoke-direct {v1, v3, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 60: throw v1
    .line 61: nop
    .line 62: nop
    .line 63: move/16 v0, v0
    .line 66: const-string/jumbo v0, "string@1114112"
    .line 69: nop
    .line 70: move-wide v0, v0
    .line 71: nop
.end method
