.class public abstract interface Landroidx/lifecycle/LifecycleObserver;
.super Ljava/lang/Object;
.source "LifecycleObserver.java"
