.class final Landroidx/lifecycle/ClassesInfoCache;
.super Ljava/lang/Object;
.source "ClassesInfoCache.java"

.field private static final CALL_TYPE_NO_ARG:I
.field private static final CALL_TYPE_PROVIDER:I
.field private static final CALL_TYPE_PROVIDER_WITH_EVENT:I
.field static sInstance:Landroidx/lifecycle/ClassesInfoCache;

.field private final mCallbackMap:Ljava/util/Map;
.field private final mHasLifecycleMethods:Ljava/util/Map;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/lifecycle/ClassesInfoCache;
    .line 2: invoke-direct {v0}, Landroidx/lifecycle/ClassesInfoCache;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/ClassesInfoCache;->sInstance:Landroidx/lifecycle/ClassesInfoCache;
    .line 7: return-void
.end method

# direct methods
.method constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/ClassesInfoCache;->mCallbackMap:Ljava/util/Map;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/lifecycle/ClassesInfoCache;->mHasLifecycleMethods:Ljava/util/Map;
    .line 17: return-void
.end method

# direct methods
.method private createInfo(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .registers 19

    .line 0: move-object/from16 v0, v16
    .line 2: move-object/from16 v1, v17
    .line 4: invoke-virtual/range {v17 .. v17}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    .line 7: move-result-object v2
    .line 8: new-instance v3, Ljava/util/HashMap;
    .line 10: invoke-direct {v3}, Ljava/util/HashMap;-><init>()V
    .line 13: if-eqz v2, :cond_26
    .line 15: invoke-virtual {v0, v2}, Landroidx/lifecycle/ClassesInfoCache;->getInfo(Ljava/lang/Class;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 18: move-result-object v4
    .line 19: if-eqz v4, :cond_26
    .line 21: iget-object v5, v4, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mHandlerToEvent:Ljava/util/Map;
    .line 23: invoke-interface {v3, v5}, Ljava/util/Map;->putAll(Ljava/util/Map;)V
    .line 26: invoke-virtual/range {v17 .. v17}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;
    .line 29: move-result-object v4
    .line 30: array-length v5, v4
    .line 31: const/4 v6, 0
    .line 32: const/4 v7, 0
    .line 33: if-ge v7, v5, :cond_82
    .line 35: aget-object v8, v4, v7
    .line 37: invoke-virtual {v0, v8}, Landroidx/lifecycle/ClassesInfoCache;->getInfo(Ljava/lang/Class;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 40: move-result-object v9
    .line 41: iget-object v9, v9, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mHandlerToEvent:Ljava/util/Map;
    .line 43: invoke-interface {v9}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 46: move-result-object v9
    .line 47: invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 50: move-result-object v9
    .line 51: invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z
    .line 54: move-result v10
    .line 55: if-eqz v10, :cond_79
    .line 57: invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 60: move-result-object v10
    .line 61: check-cast v10, Ljava/util/Map$Entry;
    .line 63: invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 66: move-result-object v11
    .line 67: check-cast v11, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 69: invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 72: move-result-object v12
    .line 73: check-cast v12, Landroidx/lifecycle/Lifecycle$Event;
    .line 75: invoke-direct {v0, v3, v11, v12, v1}, Landroidx/lifecycle/ClassesInfoCache;->verifyAndPutHandler(Ljava/util/Map;Landroidx/lifecycle/ClassesInfoCache$MethodReference;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Class;)V
    .line 78: goto :goto_51
    .line 79: add-int/lit8 v7, v7, 1
    .line 81: goto :goto_33
    .line 82: if-eqz v18, :cond_87
    .line 84: move-object/from16 v5, v18
    .line 86: goto :goto_91
    .line 87: invoke-direct/range {v16 .. v17}, Landroidx/lifecycle/ClassesInfoCache;->getDeclaredMethods(Ljava/lang/Class;)[Ljava/lang/reflect/Method;
    .line 90: move-result-object v5
    .line 91: const/4 v7, 0
    .line 92: array-length v8, v5
    .line 93: const/4 v9, 0
    .line 94: if-ge v9, v8, :cond_202
    .line 96: aget-object v10, v5, v9
    .line 98: const-class v11, Landroidx/lifecycle/OnLifecycleEvent;
    .line 100: invoke-virtual {v10, v11}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    .line 103: move-result-object v11
    .line 104: check-cast v11, Landroidx/lifecycle/OnLifecycleEvent;
    .line 106: if-nez v11, :cond_109
    .line 108: goto :goto_190
    .line 109: const/4 v7, 1
    .line 110: invoke-virtual {v10}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;
    .line 113: move-result-object v12
    .line 114: const/4 v13, 0
    .line 115: array-length v14, v12
    .line 116: if-lez v14, :cond_138
    .line 118: const/4 v13, 1
    .line 119: aget-object v14, v12, v6
    .line 121: const-class v15, Landroidx/lifecycle/LifecycleOwner;
    .line 123: invoke-virtual {v14, v15}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 126: move-result v14
    .line 127: if-eqz v14, :cond_130
    .line 129: goto :goto_138
    .line 130: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 132: const-string v8, "invalid parameter type. Must be one and instanceof LifecycleOwner"
    .line 134: invoke-direct {v6, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 137: throw v6
    .line 138: invoke-interface {v11}, Landroidx/lifecycle/OnLifecycleEvent;->value()Landroidx/lifecycle/Lifecycle$Event;
    .line 141: move-result-object v14
    .line 142: array-length v15, v12
    .line 143: const/4 v6, 1
    .line 144: if-le v15, v6, :cond_178
    .line 146: const/4 v13, 2
    .line 147: aget-object v6, v12, v6
    .line 149: const-class v15, Landroidx/lifecycle/Lifecycle$Event;
    .line 151: invoke-virtual {v6, v15}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 154: move-result v6
    .line 155: if-eqz v6, :cond_170
    .line 157: sget-object v6, Landroidx/lifecycle/Lifecycle$Event;->ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
    .line 159: if-ne v14, v6, :cond_162
    .line 161: goto :goto_178
    .line 162: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 164: const-string v8, "Second arg is supported only for ON_ANY value"
    .line 166: invoke-direct {v6, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 169: throw v6
    .line 170: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 172: const-string v8, "invalid parameter type. second arg must be an event"
    .line 174: invoke-direct {v6, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 177: throw v6
    .line 178: array-length v6, v12
    .line 179: const/4 v15, 2
    .line 180: if-gt v6, v15, :cond_194
    .line 182: new-instance v6, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 184: invoke-direct {v6, v13, v10}, Landroidx/lifecycle/ClassesInfoCache$MethodReference;-><init>(ILjava/lang/reflect/Method;)V
    .line 187: invoke-direct {v0, v3, v6, v14, v1}, Landroidx/lifecycle/ClassesInfoCache;->verifyAndPutHandler(Ljava/util/Map;Landroidx/lifecycle/ClassesInfoCache$MethodReference;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Class;)V
    .line 190: add-int/lit8 v9, v9, 1
    .line 192: const/4 v6, 0
    .line 193: goto :goto_94
    .line 194: new-instance v6, Ljava/lang/IllegalArgumentException;
    .line 196: const-string v8, "cannot have more than 2 params"
    .line 198: invoke-direct {v6, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 201: throw v6
    .line 202: new-instance v6, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 204: invoke-direct {v6, v3}, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;-><init>(Ljava/util/Map;)V
    .line 207: iget-object v8, v0, Landroidx/lifecycle/ClassesInfoCache;->mCallbackMap:Ljava/util/Map;
    .line 209: invoke-interface {v8, v1, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 212: iget-object v8, v0, Landroidx/lifecycle/ClassesInfoCache;->mHasLifecycleMethods:Ljava/util/Map;
    .line 214: invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 217: move-result-object v9
    .line 218: invoke-interface {v8, v1, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 221: return-object v6
.end method

# direct methods
.method private getDeclaredMethods(Ljava/lang/Class;)[Ljava/lang/reflect/Method;
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;
    .line 3: move-result-object v0
    .line 4: return-object v0
    .line 5: move-exception v0
    .line 6: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 8: const-string v2, "The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor."
    .line 10: invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# direct methods
.method private verifyAndPutHandler(Ljava/util/Map;Landroidx/lifecycle/ClassesInfoCache$MethodReference;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Class;)V
    .registers 10

    .line 0: invoke-interface {v6, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 3: move-result-object v0
    .line 4: check-cast v0, Landroidx/lifecycle/Lifecycle$Event;
    .line 6: if-eqz v0, :cond_68
    .line 8: if-ne v8, v0, :cond_11
    .line 10: goto :goto_68
    .line 11: iget-object v1, v7, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->mMethod:Ljava/lang/reflect/Method;
    .line 13: new-instance v2, Ljava/lang/IllegalArgumentException;
    .line 15: new-instance v3, Ljava/lang/StringBuilder;
    .line 17: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 20: const-string v4, "Method "
    .line 22: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 25: invoke-virtual {v1}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;
    .line 28: move-result-object v4
    .line 29: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: const-string v4, " in "
    .line 34: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 37: invoke-virtual {v9}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 40: move-result-object v4
    .line 41: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 44: const-string v4, " already declared with different @OnLifecycleEvent value: previous value "
    .line 46: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 49: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 52: const-string v4, ", new value "
    .line 54: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 57: invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 60: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 63: move-result-object v3
    .line 64: invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 67: throw v2
    .line 68: if-nez v0, :cond_73
    .line 70: invoke-interface {v6, v7, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 73: return-void
.end method

# virtual methods
.method  getInfo(Ljava/lang/Class;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/ClassesInfoCache;->mCallbackMap:Ljava/util/Map;
    .line 2: invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 8: if-eqz v0, :cond_11
    .line 10: return-object v0
    .line 11: const/4 v1, 0
    .line 12: invoke-direct {v2, v3, v1}, Landroidx/lifecycle/ClassesInfoCache;->createInfo(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 15: move-result-object v0
    .line 16: return-object v0
.end method

# virtual methods
.method  hasLifecycleMethods(Ljava/lang/Class;)Z
    .registers 9

    .line 0: iget-object v0, v7, Landroidx/lifecycle/ClassesInfoCache;->mHasLifecycleMethods:Ljava/util/Map;
    .line 2: invoke-interface {v0, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ljava/lang/Boolean;
    .line 8: if-eqz v0, :cond_15
    .line 10: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 13: move-result v1
    .line 14: return v1
    .line 15: invoke-direct {v7, v8}, Landroidx/lifecycle/ClassesInfoCache;->getDeclaredMethods(Ljava/lang/Class;)[Ljava/lang/reflect/Method;
    .line 18: move-result-object v1
    .line 19: array-length v2, v1
    .line 20: const/4 v3, 0
    .line 21: const/4 v4, 0
    .line 22: if-ge v4, v2, :cond_44
    .line 24: aget-object v5, v1, v4
    .line 26: const-class v6, Landroidx/lifecycle/OnLifecycleEvent;
    .line 28: invoke-virtual {v5, v6}, Ljava/lang/reflect/Method;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    .line 31: move-result-object v6
    .line 32: check-cast v6, Landroidx/lifecycle/OnLifecycleEvent;
    .line 34: if-eqz v6, :cond_41
    .line 36: invoke-direct {v7, v8, v1}, Landroidx/lifecycle/ClassesInfoCache;->createInfo(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
    .line 39: const/4 v2, 1
    .line 40: return v2
    .line 41: add-int/lit8 v4, v4, 1
    .line 43: goto :goto_22
    .line 44: iget-object v2, v7, Landroidx/lifecycle/ClassesInfoCache;->mHasLifecycleMethods:Ljava/util/Map;
    .line 46: invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 49: move-result-object v4
    .line 50: invoke-interface {v2, v8, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 53: return v3
.end method
