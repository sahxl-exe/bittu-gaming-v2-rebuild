.class public abstract Landroidx/lifecycle/Lifecycle;
.super Ljava/lang/Object;
.source "Lifecycle.java"

.field  mInternalScopeRef:Ljava/util/concurrent/atomic/AtomicReference;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;
    .line 5: invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/Lifecycle;->mInternalScopeRef:Ljava/util/concurrent/atomic/AtomicReference;
    .line 10: return-void
.end method

# virtual methods
.method public abstract addObserver(Landroidx/lifecycle/LifecycleObserver;)V
.end method

# virtual methods
.method public abstract getCurrentState()Landroidx/lifecycle/Lifecycle$State;
.end method

# virtual methods
.method public abstract removeObserver(Landroidx/lifecycle/LifecycleObserver;)V
.end method
