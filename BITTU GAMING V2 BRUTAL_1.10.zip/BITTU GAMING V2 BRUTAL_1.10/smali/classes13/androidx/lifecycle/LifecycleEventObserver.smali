.class public abstract interface Landroidx/lifecycle/LifecycleEventObserver;
.super Ljava/lang/Object;
.source "LifecycleEventObserver.java"
.implements Landroidx/lifecycle/LifecycleObserver;

# virtual methods
.method public abstract onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
.end method
