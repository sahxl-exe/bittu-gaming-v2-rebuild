.class public Landroidx/lifecycle/Lifecycling;
.super Ljava/lang/Object;
.source "Lifecycling.java"

.field private static final GENERATED_CALLBACK:I
.field private static final REFLECTIVE_CALLBACK:I
.field private static sCallbackCache:Ljava/util/Map;
.field private static sClassToAdapters:Ljava/util/Map;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Ljava/util/HashMap;
    .line 2: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 5: sput-object v0, Landroidx/lifecycle/Lifecycling;->sCallbackCache:Ljava/util/Map;
    .line 7: new-instance v0, Ljava/util/HashMap;
    .line 9: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 12: sput-object v0, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 14: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method private static createGeneratedAdapter(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)Landroidx/lifecycle/GeneratedAdapter;
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: new-array v0, v0, [Ljava/lang/Object;
    .line 3: const/4 v1, 0
    .line 4: aput-object v3, v0, v1
    .line 6: invoke-virtual {v2, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Landroidx/lifecycle/GeneratedAdapter;
    .line 12: return-object v0
    .line 13: move-exception v0
    .line 14: new-instance v1, Ljava/lang/RuntimeException;
    .line 16: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 19: throw v1
    .line 20: move-exception v0
    .line 21: new-instance v1, Ljava/lang/RuntimeException;
    .line 23: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 26: throw v1
    .line 27: move-exception v0
    .line 28: new-instance v1, Ljava/lang/RuntimeException;
    .line 30: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 33: throw v1
.end method

# direct methods
.method private static generatedConstructor(Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .registers 9

    .line 0: invoke-virtual {v8}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v8}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 7: move-result-object v1
    .line 8: if-eqz v0, :cond_15
    .line 10: invoke-virtual {v0}, Ljava/lang/Package;->getName()Ljava/lang/String;
    .line 13: move-result-object v2
    .line 14: goto :goto_17
    .line 15: const-string v2, ""
    .line 17: invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z
    .line 20: move-result v3
    .line 21: const/4 v4, 1
    .line 22: if-eqz v3, :cond_26
    .line 24: move-object v3, v1
    .line 25: goto :goto_35
    .line 26: invoke-virtual {v2}, Ljava/lang/String;->length()I
    .line 29: move-result v3
    .line 30: add-int/2addr v3, v4
    .line 31: invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    .line 34: move-result-object v3
    .line 35: invoke-static {v3}, Landroidx/lifecycle/Lifecycling;->getAdapterName(Ljava/lang/String;)Ljava/lang/String;
    .line 38: move-result-object v3
    .line 39: invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z
    .line 42: move-result v5
    .line 43: if-eqz v5, :cond_47
    .line 45: move-object v5, v3
    .line 46: goto :goto_67
    .line 47: new-instance v5, Ljava/lang/StringBuilder;
    .line 49: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    .line 52: invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 55: const-string v6, "."
    .line 57: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 60: invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 63: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 66: move-result-object v5
    .line 67: invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    .line 70: move-result-object v5
    .line 71: new-array v6, v4, [Ljava/lang/Class;
    .line 73: const/4 v7, 0
    .line 74: aput-object v8, v6, v7
    .line 76: invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 79: move-result-object v6
    .line 80: invoke-virtual {v6}, Ljava/lang/reflect/Constructor;->isAccessible()Z
    .line 83: move-result v7
    .line 84: if-nez v7, :cond_89
    .line 86: invoke-virtual {v6, v4}, Ljava/lang/reflect/Constructor;->setAccessible(Z)V
    .line 89: return-object v6
    .line 90: move-exception v0
    .line 91: new-instance v1, Ljava/lang/RuntimeException;
    .line 93: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 96: throw v1
    .line 97: move-exception v0
    .line 98: const/4 v1, 0
    .line 99: return-object v1
.end method

# direct methods
.method public static getAdapterName(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/StringBuilder;
    .line 2: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 5: const-string v1, "."
    .line 7: const-string v2, "_"
    .line 9: invoke-virtual {v3, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    .line 12: move-result-object v1
    .line 13: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 16: const-string v1, "_LifecycleAdapter"
    .line 18: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 21: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 24: move-result-object v0
    .line 25: return-object v0
.end method

# direct methods
.method static getCallback(Ljava/lang/Object;)Landroidx/lifecycle/GenericLifecycleObserver;
    .registers 3

    .line 0: invoke-static {v2}, Landroidx/lifecycle/Lifecycling;->lifecycleEventObserver(Ljava/lang/Object;)Landroidx/lifecycle/LifecycleEventObserver;
    .line 3: move-result-object v0
    .line 4: new-instance v1, Landroidx/lifecycle/Lifecycling$1;
    .line 6: invoke-direct {v1, v0}, Landroidx/lifecycle/Lifecycling$1;-><init>(Landroidx/lifecycle/LifecycleEventObserver;)V
    .line 9: return-object v1
.end method

# direct methods
.method private static getObserverConstructorType(Ljava/lang/Class;)I
    .registers 5

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycling;->sCallbackCache:Ljava/util/Map;
    .line 2: invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ljava/lang/Integer;
    .line 8: if-eqz v0, :cond_15
    .line 10: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    .line 13: move-result v1
    .line 14: return v1
    .line 15: invoke-static {v4}, Landroidx/lifecycle/Lifecycling;->resolveObserverCallbackType(Ljava/lang/Class;)I
    .line 18: move-result v1
    .line 19: sget-object v2, Landroidx/lifecycle/Lifecycling;->sCallbackCache:Ljava/util/Map;
    .line 21: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 24: move-result-object v3
    .line 25: invoke-interface {v2, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: return v1
.end method

# direct methods
.method private static isLifecycleParent(Ljava/lang/Class;)Z
    .registers 2

    .line 0: if-eqz v1, :cond_12
    .line 2: const-class v0, Landroidx/lifecycle/LifecycleObserver;
    .line 4: invoke-virtual {v0, v1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 7: move-result v0
    .line 8: if-eqz v0, :cond_12
    .line 10: const/4 v0, 1
    .line 11: goto :goto_13
    .line 12: const/4 v0, 0
    .line 13: return v0
.end method

# direct methods
.method static lifecycleEventObserver(Ljava/lang/Object;)Landroidx/lifecycle/LifecycleEventObserver;
    .registers 9

    .line 0: instance-of v0, v8, Landroidx/lifecycle/LifecycleEventObserver;
    .line 2: instance-of v1, v8, Landroidx/lifecycle/FullLifecycleObserver;
    .line 4: if-eqz v0, :cond_20
    .line 6: if-eqz v1, :cond_20
    .line 8: new-instance v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;
    .line 10: move-object v3, v8
    .line 11: check-cast v3, Landroidx/lifecycle/FullLifecycleObserver;
    .line 13: move-object v4, v8
    .line 14: check-cast v4, Landroidx/lifecycle/LifecycleEventObserver;
    .line 16: invoke-direct {v2, v3, v4}, Landroidx/lifecycle/FullLifecycleObserverAdapter;-><init>(Landroidx/lifecycle/FullLifecycleObserver;Landroidx/lifecycle/LifecycleEventObserver;)V
    .line 19: return-object v2
    .line 20: if-eqz v1, :cond_32
    .line 22: new-instance v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;
    .line 24: move-object v3, v8
    .line 25: check-cast v3, Landroidx/lifecycle/FullLifecycleObserver;
    .line 27: const/4 v4, 0
    .line 28: invoke-direct {v2, v3, v4}, Landroidx/lifecycle/FullLifecycleObserverAdapter;-><init>(Landroidx/lifecycle/FullLifecycleObserver;Landroidx/lifecycle/LifecycleEventObserver;)V
    .line 31: return-object v2
    .line 32: if-eqz v0, :cond_38
    .line 34: move-object v2, v8
    .line 35: check-cast v2, Landroidx/lifecycle/LifecycleEventObserver;
    .line 37: return-object v2
    .line 38: invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 41: move-result-object v2
    .line 42: invoke-static {v2}, Landroidx/lifecycle/Lifecycling;->getObserverConstructorType(Ljava/lang/Class;)I
    .line 45: move-result v3
    .line 46: const/4 v4, 2
    .line 47: if-ne v3, v4, :cond_115
    .line 49: sget-object v4, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 51: invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 54: move-result-object v4
    .line 55: check-cast v4, Ljava/util/List;
    .line 57: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 60: move-result v5
    .line 61: const/4 v6, 1
    .line 62: if-ne v5, v6, :cond_81
    .line 64: const/4 v5, 0
    .line 65: invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 68: move-result-object v5
    .line 69: check-cast v5, Ljava/lang/reflect/Constructor;
    .line 71: invoke-static {v5, v8}, Landroidx/lifecycle/Lifecycling;->createGeneratedAdapter(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)Landroidx/lifecycle/GeneratedAdapter;
    .line 74: move-result-object v5
    .line 75: new-instance v6, Landroidx/lifecycle/SingleGeneratedAdapterObserver;
    .line 77: invoke-direct {v6, v5}, Landroidx/lifecycle/SingleGeneratedAdapterObserver;-><init>(Landroidx/lifecycle/GeneratedAdapter;)V
    .line 80: return-object v6
    .line 81: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 84: move-result v5
    .line 85: new-array v5, v5, [Landroidx/lifecycle/GeneratedAdapter;
    .line 87: const/4 v6, 0
    .line 88: invoke-interface {v4}, Ljava/util/List;->size()I
    .line 91: move-result v7
    .line 92: if-ge v6, v7, :cond_109
    .line 94: invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 97: move-result-object v7
    .line 98: check-cast v7, Ljava/lang/reflect/Constructor;
    .line 100: invoke-static {v7, v8}, Landroidx/lifecycle/Lifecycling;->createGeneratedAdapter(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)Landroidx/lifecycle/GeneratedAdapter;
    .line 103: move-result-object v7
    .line 104: aput-object v7, v5, v6
    .line 106: add-int/lit8 v6, v6, 1
    .line 108: goto :goto_88
    .line 109: new-instance v6, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;
    .line 111: invoke-direct {v6, v5}, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;-><init>([Landroidx/lifecycle/GeneratedAdapter;)V
    .line 114: return-object v6
    .line 115: new-instance v4, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;
    .line 117: invoke-direct {v4, v8}, Landroidx/lifecycle/ReflectiveGenericLifecycleObserver;-><init>(Ljava/lang/Object;)V
    .line 120: return-object v4
.end method

# direct methods
.method private static resolveObserverCallbackType(Ljava/lang/Class;)I
    .registers 12

    .line 0: invoke-virtual {v11}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 1
    .line 5: if-nez v0, :cond_8
    .line 7: return v1
    .line 8: invoke-static {v11}, Landroidx/lifecycle/Lifecycling;->generatedConstructor(Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 11: move-result-object v0
    .line 12: const/4 v2, 2
    .line 13: if-eqz v0, :cond_25
    .line 15: sget-object v1, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 17: invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;
    .line 20: move-result-object v3
    .line 21: invoke-interface {v1, v11, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 24: return v2
    .line 25: sget-object v3, Landroidx/lifecycle/ClassesInfoCache;->sInstance:Landroidx/lifecycle/ClassesInfoCache;
    .line 27: invoke-virtual {v3, v11}, Landroidx/lifecycle/ClassesInfoCache;->hasLifecycleMethods(Ljava/lang/Class;)Z
    .line 30: move-result v3
    .line 31: if-eqz v3, :cond_34
    .line 33: return v1
    .line 34: invoke-virtual {v11}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;
    .line 37: move-result-object v4
    .line 38: const/4 v5, 0
    .line 39: invoke-static {v4}, Landroidx/lifecycle/Lifecycling;->isLifecycleParent(Ljava/lang/Class;)Z
    .line 42: move-result v6
    .line 43: if-eqz v6, :cond_66
    .line 45: invoke-static {v4}, Landroidx/lifecycle/Lifecycling;->getObserverConstructorType(Ljava/lang/Class;)I
    .line 48: move-result v6
    .line 49: if-ne v6, v1, :cond_52
    .line 51: return v1
    .line 52: new-instance v6, Ljava/util/ArrayList;
    .line 54: sget-object v7, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 56: invoke-interface {v7, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 59: move-result-object v7
    .line 60: check-cast v7, Ljava/util/Collection;
    .line 62: invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    .line 65: move-object v5, v6
    .line 66: invoke-virtual {v11}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;
    .line 69: move-result-object v6
    .line 70: array-length v7, v6
    .line 71: const/4 v8, 0
    .line 72: if-ge v8, v7, :cond_112
    .line 74: aget-object v9, v6, v8
    .line 76: invoke-static {v9}, Landroidx/lifecycle/Lifecycling;->isLifecycleParent(Ljava/lang/Class;)Z
    .line 79: move-result v10
    .line 80: if-nez v10, :cond_83
    .line 82: goto :goto_109
    .line 83: invoke-static {v9}, Landroidx/lifecycle/Lifecycling;->getObserverConstructorType(Ljava/lang/Class;)I
    .line 86: move-result v10
    .line 87: if-ne v10, v1, :cond_90
    .line 89: return v1
    .line 90: if-nez v5, :cond_98
    .line 92: new-instance v10, Ljava/util/ArrayList;
    .line 94: invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V
    .line 97: move-object v5, v10
    .line 98: sget-object v10, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 100: invoke-interface {v10, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 103: move-result-object v10
    .line 104: check-cast v10, Ljava/util/Collection;
    .line 106: invoke-interface {v5, v10}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    .line 109: add-int/lit8 v8, v8, 1
    .line 111: goto :goto_72
    .line 112: if-eqz v5, :cond_120
    .line 114: sget-object v1, Landroidx/lifecycle/Lifecycling;->sClassToAdapters:Ljava/util/Map;
    .line 116: invoke-interface {v1, v11, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 119: return v2
    .line 120: return v1
.end method
