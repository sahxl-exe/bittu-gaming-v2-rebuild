.class public abstract interface Landroidx/lifecycle/GenericLifecycleObserver;
.super Ljava/lang/Object;
.source "GenericLifecycleObserver.java"
.implements Landroidx/lifecycle/LifecycleEventObserver;
