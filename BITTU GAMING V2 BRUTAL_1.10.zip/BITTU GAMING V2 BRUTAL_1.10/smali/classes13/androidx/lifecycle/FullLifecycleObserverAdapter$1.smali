.class synthetic Landroidx/lifecycle/FullLifecycleObserverAdapter$1;
.super Ljava/lang/Object;
.source "FullLifecycleObserverAdapter.java"

.field static final synthetic $SwitchMap$androidx$lifecycle$Lifecycle$Event:[I

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: invoke-static {}, Landroidx/lifecycle/Lifecycle$Event;->values()[Landroidx/lifecycle/Lifecycle$Event;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 9: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 11: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 14: move-result v1
    .line 15: const/4 v2, 1
    .line 16: aput v2, v0, v1
    .line 18: goto :goto_20
    .line 19: move-exception v0
    .line 20: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 22: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 24: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 27: move-result v1
    .line 28: const/4 v2, 2
    .line 29: aput v2, v0, v1
    .line 31: goto :goto_33
    .line 32: move-exception v0
    .line 33: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 35: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 37: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 40: move-result v1
    .line 41: const/4 v2, 3
    .line 42: aput v2, v0, v1
    .line 44: goto :goto_46
    .line 45: move-exception v0
    .line 46: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 48: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 50: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 53: move-result v1
    .line 54: const/4 v2, 4
    .line 55: aput v2, v0, v1
    .line 57: goto :goto_59
    .line 58: move-exception v0
    .line 59: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 61: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 63: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 66: move-result v1
    .line 67: const/4 v2, 5
    .line 68: aput v2, v0, v1
    .line 70: goto :goto_72
    .line 71: move-exception v0
    .line 72: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 74: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 76: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 79: move-result v1
    .line 80: const/4 v2, 6
    .line 81: aput v2, v0, v1
    .line 83: goto :goto_85
    .line 84: move-exception v0
    .line 85: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 87: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
    .line 89: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 92: move-result v1
    .line 93: const/4 v2, 7
    .line 94: aput v2, v0, v1
    .line 96: goto :goto_98
    .line 97: move-exception v0
    .line 98: return-void
.end method
