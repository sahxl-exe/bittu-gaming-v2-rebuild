.class  Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;
.super Ljava/lang/Object;
.source "ClassesInfoCache.java"

.field final mEventToHandlers:Ljava/util/Map;
.field final mHandlerToEvent:Ljava/util/Map;

# direct methods
.method constructor <init>(Ljava/util/Map;)V
    .registers 7

    .line 0: invoke-direct {v5}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v6, v5, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mHandlerToEvent:Ljava/util/Map;
    .line 5: new-instance v0, Ljava/util/HashMap;
    .line 7: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 10: iput-object v0, v5, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mEventToHandlers:Ljava/util/Map;
    .line 12: invoke-interface {v6}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 15: move-result-object v0
    .line 16: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 19: move-result-object v0
    .line 20: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 23: move-result v1
    .line 24: if-eqz v1, :cond_69
    .line 26: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 29: move-result-object v1
    .line 30: check-cast v1, Ljava/util/Map$Entry;
    .line 32: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 35: move-result-object v2
    .line 36: check-cast v2, Landroidx/lifecycle/Lifecycle$Event;
    .line 38: iget-object v3, v5, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mEventToHandlers:Ljava/util/Map;
    .line 40: invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 43: move-result-object v3
    .line 44: check-cast v3, Ljava/util/List;
    .line 46: if-nez v3, :cond_59
    .line 48: new-instance v4, Ljava/util/ArrayList;
    .line 50: invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V
    .line 53: move-object v3, v4
    .line 54: iget-object v4, v5, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mEventToHandlers:Ljava/util/Map;
    .line 56: invoke-interface {v4, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 59: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 62: move-result-object v4
    .line 63: check-cast v4, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 65: invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 68: goto :goto_20
    .line 69: return-void
.end method

# direct methods
.method private static invokeMethodsForEvent(Ljava/util/List;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .registers 6

    .line 0: if-eqz v2, :cond_22
    .line 2: invoke-interface {v2}, Ljava/util/List;->size()I
    .line 5: move-result v0
    .line 6: add-int/lit8 v0, v0, -1
    .line 8: if-ltz v0, :cond_22
    .line 10: invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 13: move-result-object v1
    .line 14: check-cast v1, Landroidx/lifecycle/ClassesInfoCache$MethodReference;
    .line 16: invoke-virtual {v1, v3, v4, v5}, Landroidx/lifecycle/ClassesInfoCache$MethodReference;->invokeCallback(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .line 19: add-int/lit8 v0, v0, -1
    .line 21: goto :goto_8
    .line 22: return-void
.end method

# virtual methods
.method  invokeCallbacks(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .registers 6

    .line 0: iget-object v0, v2, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mEventToHandlers:Ljava/util/Map;
    .line 2: invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Ljava/util/List;
    .line 8: invoke-static {v0, v3, v4, v5}, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->invokeMethodsForEvent(Ljava/util/List;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .line 11: iget-object v0, v2, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->mEventToHandlers:Ljava/util/Map;
    .line 13: sget-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
    .line 15: invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 18: move-result-object v0
    .line 19: check-cast v0, Ljava/util/List;
    .line 21: invoke-static {v0, v3, v4, v5}, Landroidx/lifecycle/ClassesInfoCache$CallbackInfo;->invokeMethodsForEvent(Ljava/util/List;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;Ljava/lang/Object;)V
    .line 24: return-void
.end method
