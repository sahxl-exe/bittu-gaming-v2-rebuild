.class synthetic Landroidx/lifecycle/Lifecycle$1;
.super Ljava/lang/Object;
.source "Lifecycle.java"

.field static final synthetic $SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
.field static final synthetic $SwitchMap$androidx$lifecycle$Lifecycle$State:[I

# direct methods
.method static constructor <clinit>()V
    .registers 8

    .line 0: invoke-static {}, Landroidx/lifecycle/Lifecycle$Event;->values()[Landroidx/lifecycle/Lifecycle$Event;
    .line 3: move-result-object v0
    .line 4: array-length v0, v0
    .line 5: new-array v0, v0, [I
    .line 7: sput-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 9: const/4 v1, 1
    .line 10: sget-object v2, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 12: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 15: move-result v2
    .line 16: aput v1, v0, v2
    .line 18: goto :goto_20
    .line 19: move-exception v0
    .line 20: const/4 v0, 2
    .line 21: sget-object v2, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 23: sget-object v3, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 25: invoke-virtual {v3}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 28: move-result v3
    .line 29: aput v0, v2, v3
    .line 31: goto :goto_33
    .line 32: move-exception v2
    .line 33: const/4 v2, 3
    .line 34: sget-object v3, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 36: sget-object v4, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 38: invoke-virtual {v4}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 41: move-result v4
    .line 42: aput v2, v3, v4
    .line 44: goto :goto_46
    .line 45: move-exception v3
    .line 46: const/4 v3, 4
    .line 47: sget-object v4, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 49: sget-object v5, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 51: invoke-virtual {v5}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 54: move-result v5
    .line 55: aput v3, v4, v5
    .line 57: goto :goto_59
    .line 58: move-exception v4
    .line 59: const/4 v4, 5
    .line 60: sget-object v5, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 62: sget-object v6, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 64: invoke-virtual {v6}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 67: move-result v6
    .line 68: aput v4, v5, v6
    .line 70: goto :goto_72
    .line 71: move-exception v5
    .line 72: sget-object v5, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 74: sget-object v6, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 76: invoke-virtual {v6}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 79: move-result v6
    .line 80: const/4 v7, 6
    .line 81: aput v7, v5, v6
    .line 83: goto :goto_85
    .line 84: move-exception v5
    .line 85: sget-object v5, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 87: sget-object v6, Landroidx/lifecycle/Lifecycle$Event;->ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
    .line 89: invoke-virtual {v6}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 92: move-result v6
    .line 93: const/4 v7, 7
    .line 94: aput v7, v5, v6
    .line 96: goto :goto_98
    .line 97: move-exception v5
    .line 98: invoke-static {}, Landroidx/lifecycle/Lifecycle$State;->values()[Landroidx/lifecycle/Lifecycle$State;
    .line 101: move-result-object v5
    .line 102: array-length v5, v5
    .line 103: new-array v5, v5, [I
    .line 105: sput-object v5, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 107: sget-object v6, Landroidx/lifecycle/Lifecycle$State;->CREATED:Landroidx/lifecycle/Lifecycle$State;
    .line 109: invoke-virtual {v6}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 112: move-result v6
    .line 113: aput v1, v5, v6
    .line 115: goto :goto_117
    .line 116: move-exception v1
    .line 117: sget-object v1, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 119: sget-object v5, Landroidx/lifecycle/Lifecycle$State;->STARTED:Landroidx/lifecycle/Lifecycle$State;
    .line 121: invoke-virtual {v5}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 124: move-result v5
    .line 125: aput v0, v1, v5
    .line 127: goto :goto_129
    .line 128: move-exception v0
    .line 129: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 131: sget-object v1, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;
    .line 133: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 136: move-result v1
    .line 137: aput v2, v0, v1
    .line 139: goto :goto_141
    .line 140: move-exception v0
    .line 141: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 143: sget-object v1, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;
    .line 145: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 148: move-result v1
    .line 149: aput v3, v0, v1
    .line 151: goto :goto_153
    .line 152: move-exception v0
    .line 153: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 155: sget-object v1, Landroidx/lifecycle/Lifecycle$State;->INITIALIZED:Landroidx/lifecycle/Lifecycle$State;
    .line 157: invoke-virtual {v1}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 160: move-result v1
    .line 161: aput v4, v0, v1
    .line 163: goto :goto_165
    .line 164: move-exception v0
    .line 165: return-void
.end method
