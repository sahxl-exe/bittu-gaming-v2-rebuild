.class  Landroidx/lifecycle/Lifecycling$1;
.super Ljava/lang/Object;
.source "Lifecycling.java"
.implements Landroidx/lifecycle/GenericLifecycleObserver;

.field final synthetic val$observer:Landroidx/lifecycle/LifecycleEventObserver;

# direct methods
.method constructor <init>(Landroidx/lifecycle/LifecycleEventObserver;)V
    .registers 2

    .line 0: iput-object v1, v0, Landroidx/lifecycle/Lifecycling$1;->val$observer:Landroidx/lifecycle/LifecycleEventObserver;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/lifecycle/Lifecycling$1;->val$observer:Landroidx/lifecycle/LifecycleEventObserver;
    .line 2: invoke-interface {v0, v2, v3}, Landroidx/lifecycle/LifecycleEventObserver;->onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method
