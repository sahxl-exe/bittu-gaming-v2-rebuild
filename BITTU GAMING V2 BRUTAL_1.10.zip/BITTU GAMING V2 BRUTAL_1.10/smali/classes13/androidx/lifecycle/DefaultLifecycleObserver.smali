.class public abstract interface Landroidx/lifecycle/DefaultLifecycleObserver;
.super Ljava/lang/Object;
.source "DefaultLifecycleObserver.java"
.implements Landroidx/lifecycle/FullLifecycleObserver;

# virtual methods
.method public abstract onCreate(Landroidx/lifecycle/LifecycleOwner;)V
.end method

# virtual methods
.method public abstract onDestroy(Landroidx/lifecycle/LifecycleOwner;)V
.end method

# virtual methods
.method public abstract onPause(Landroidx/lifecycle/LifecycleOwner;)V
.end method

# virtual methods
.method public abstract onResume(Landroidx/lifecycle/LifecycleOwner;)V
.end method

# virtual methods
.method public abstract onStart(Landroidx/lifecycle/LifecycleOwner;)V
.end method

# virtual methods
.method public abstract onStop(Landroidx/lifecycle/LifecycleOwner;)V
.end method
