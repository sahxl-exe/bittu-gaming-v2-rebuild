.class public final synthetic Landroidx/lifecycle/DefaultLifecycleObserver$-CC;
.super Ljava/lang/Object;
.source "DefaultLifecycleObserver.java"

# direct methods
.method public static $default$onCreate(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method

# direct methods
.method public static $default$onDestroy(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method

# direct methods
.method public static $default$onPause(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method

# direct methods
.method public static $default$onResume(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method

# direct methods
.method public static $default$onStart(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method

# direct methods
.method public static $default$onStop(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 2

    .line 0: return-void
.end method
