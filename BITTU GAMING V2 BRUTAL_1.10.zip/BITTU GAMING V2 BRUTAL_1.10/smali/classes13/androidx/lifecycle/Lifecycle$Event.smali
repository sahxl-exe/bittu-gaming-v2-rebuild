.class public final enum Landroidx/lifecycle/Lifecycle$Event;
.super Ljava/lang/Enum;
.source "Lifecycle.java"

.field private static final synthetic $VALUES:[Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_START:Landroidx/lifecycle/Lifecycle$Event;
.field public static final enum ON_STOP:Landroidx/lifecycle/Lifecycle$Event;

# direct methods
.method static constructor <clinit>()V
    .registers 15

    .line 0: new-instance v0, Landroidx/lifecycle/Lifecycle$Event;
    .line 2: const-string v1, "ON_CREATE"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 10: new-instance v1, Landroidx/lifecycle/Lifecycle$Event;
    .line 12: const-string v3, "ON_START"
    .line 14: const/4 v4, 1
    .line 15: invoke-direct {v1, v3, v4}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 20: new-instance v3, Landroidx/lifecycle/Lifecycle$Event;
    .line 22: const-string v5, "ON_RESUME"
    .line 24: const/4 v6, 2
    .line 25: invoke-direct {v3, v5, v6}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 28: sput-object v3, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 30: new-instance v5, Landroidx/lifecycle/Lifecycle$Event;
    .line 32: const-string v7, "ON_PAUSE"
    .line 34: const/4 v8, 3
    .line 35: invoke-direct {v5, v7, v8}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 38: sput-object v5, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 40: new-instance v7, Landroidx/lifecycle/Lifecycle$Event;
    .line 42: const-string v9, "ON_STOP"
    .line 44: const/4 v10, 4
    .line 45: invoke-direct {v7, v9, v10}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 48: sput-object v7, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 50: new-instance v9, Landroidx/lifecycle/Lifecycle$Event;
    .line 52: const-string v11, "ON_DESTROY"
    .line 54: const/4 v12, 5
    .line 55: invoke-direct {v9, v11, v12}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 58: sput-object v9, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 60: new-instance v11, Landroidx/lifecycle/Lifecycle$Event;
    .line 62: const-string v13, "ON_ANY"
    .line 64: const/4 v14, 6
    .line 65: invoke-direct {v11, v13, v14}, Landroidx/lifecycle/Lifecycle$Event;-><init>(Ljava/lang/String;I)V
    .line 68: sput-object v11, Landroidx/lifecycle/Lifecycle$Event;->ON_ANY:Landroidx/lifecycle/Lifecycle$Event;
    .line 70: const/4 v13, 7
    .line 71: new-array v13, v13, [Landroidx/lifecycle/Lifecycle$Event;
    .line 73: aput-object v0, v13, v2
    .line 75: aput-object v1, v13, v4
    .line 77: aput-object v3, v13, v6
    .line 79: aput-object v5, v13, v8
    .line 81: aput-object v7, v13, v10
    .line 83: aput-object v9, v13, v12
    .line 85: aput-object v11, v13, v14
    .line 87: sput-object v13, Landroidx/lifecycle/Lifecycle$Event;->$VALUES:[Landroidx/lifecycle/Lifecycle$Event;
    .line 89: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: return-void
.end method

# direct methods
.method public static downFrom(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 2: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_22
    .line 11: const/4 v0, 0
    .line 12: return-object v0
    .line 13: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 15: return-object v0
    .line 16: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 18: return-object v0
    .line 19: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 21: return-object v0
    .line 22: nop
    .line 23: move/16 v1, v0
    .line 26: move-result-wide v0
    .line 27: nop
    .line 28: move-object/from16 v0, v0
    .line 30: move-wide/from16 v0, v0
.end method

# direct methods
.method public static downTo(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 2: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_22
    .line 11: const/4 v0, 0
    .line 12: return-object v0
    .line 13: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 15: return-object v0
    .line 16: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 18: return-object v0
    .line 19: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 21: return-object v0
    .line 22: nop
    .line 23: move-wide v0, v0
    .line 24: move v0, v0
    .line 25: nop
    .line 26: move-result-wide v0
    .line 27: nop
    .line 28: move-object/from16 v0, v0
    .line 30: move/16 v0, v5
    .line 33: nop
.end method

# direct methods
.method public static upFrom(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 2: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_22
    .line 11: const/4 v0, 0
    .line 12: return-object v0
    .line 13: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 15: return-object v0
    .line 16: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 18: return-object v0
    .line 19: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 21: return-object v0
    .line 22: nop
    .line 23: move-wide/from16 v0, v1
    .line 25: nop
    .line 26: move-result-wide v0
    .line 27: nop
    .line 28: move-object/from16 v0, v0
    .line 30: move/16 v0, v3
    .line 33: nop
    .line 34: move-wide/from16 v0, v0
.end method

# direct methods
.method public static upTo(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$State:[I
    .line 2: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$State;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_22
    .line 11: const/4 v0, 0
    .line 12: return-object v0
    .line 13: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 15: return-object v0
    .line 16: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 18: return-object v0
    .line 19: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 21: return-object v0
    .line 22: nop
    .line 23: move/16 v1, v0
    .line 26: move-result-wide v0
    .line 27: nop
    .line 28: move-object/from16 v0, v0
    .line 30: move-wide/from16 v0, v0
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/Lifecycle$Event;
    .registers 2

    .line 0: const-class v0, Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/Lifecycle$Event;
    .line 8: return-object v0
.end method

# direct methods
.method public static values()[Landroidx/lifecycle/Lifecycle$Event;
    .registers 1

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->$VALUES:[Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-virtual {v0}, [Landroidx/lifecycle/Lifecycle$Event;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/lifecycle/Lifecycle$Event;
    .line 8: return-object v0
.end method

# virtual methods
.method public getTargetState()Landroidx/lifecycle/Lifecycle$State;
    .registers 4

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 2: invoke-virtual {v3}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_46
    .line 11: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 13: new-instance v1, Ljava/lang/StringBuilder;
    .line 15: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 18: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 21: const-string v2, " has no target state"
    .line 23: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v1
    .line 30: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 33: throw v0
    .line 34: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;
    .line 36: return-object v0
    .line 37: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;
    .line 39: return-object v0
    .line 40: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->STARTED:Landroidx/lifecycle/Lifecycle$State;
    .line 42: return-object v0
    .line 43: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->CREATED:Landroidx/lifecycle/Lifecycle$State;
    .line 45: return-object v0
    .line 46: nop
    .line 47: move-wide/16 v1, v0
    .line 50: new-array v0, v0, I
    .line 52: new-array v0, v0, I
    .line 54: instance-of v0, v0, I
    .line 56: instance-of v0, v0, I
    .line 58: monitor-enter v0
    .line 59: nop
    .line 60: const-string v0, ""
.end method
