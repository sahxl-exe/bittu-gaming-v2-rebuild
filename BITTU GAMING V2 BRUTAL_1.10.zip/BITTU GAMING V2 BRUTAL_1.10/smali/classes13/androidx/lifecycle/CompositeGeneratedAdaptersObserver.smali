.class  Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;
.super Ljava/lang/Object;
.source "CompositeGeneratedAdaptersObserver.java"
.implements Landroidx/lifecycle/LifecycleEventObserver;

.field private final mGeneratedAdapters:[Landroidx/lifecycle/GeneratedAdapter;

# direct methods
.method constructor <init>([Landroidx/lifecycle/GeneratedAdapter;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;->mGeneratedAdapters:[Landroidx/lifecycle/GeneratedAdapter;
    .line 5: return-void
.end method

# virtual methods
.method public onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 9

    .line 0: new-instance v0, Landroidx/lifecycle/MethodCallsLogger;
    .line 2: invoke-direct {v0}, Landroidx/lifecycle/MethodCallsLogger;-><init>()V
    .line 5: iget-object v1, v6, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;->mGeneratedAdapters:[Landroidx/lifecycle/GeneratedAdapter;
    .line 7: array-length v2, v1
    .line 8: const/4 v3, 0
    .line 9: const/4 v4, 0
    .line 10: if-ge v4, v2, :cond_20
    .line 12: aget-object v5, v1, v4
    .line 14: invoke-interface {v5, v7, v8, v3, v0}, Landroidx/lifecycle/GeneratedAdapter;->callMethods(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;ZLandroidx/lifecycle/MethodCallsLogger;)V
    .line 17: add-int/lit8 v4, v4, 1
    .line 19: goto :goto_10
    .line 20: iget-object v1, v6, Landroidx/lifecycle/CompositeGeneratedAdaptersObserver;->mGeneratedAdapters:[Landroidx/lifecycle/GeneratedAdapter;
    .line 22: array-length v2, v1
    .line 23: if-ge v3, v2, :cond_34
    .line 25: aget-object v4, v1, v3
    .line 27: const/4 v5, 1
    .line 28: invoke-interface {v4, v7, v8, v5, v0}, Landroidx/lifecycle/GeneratedAdapter;->callMethods(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;ZLandroidx/lifecycle/MethodCallsLogger;)V
    .line 31: add-int/lit8 v3, v3, 1
    .line 33: goto :goto_23
    .line 34: return-void
.end method
