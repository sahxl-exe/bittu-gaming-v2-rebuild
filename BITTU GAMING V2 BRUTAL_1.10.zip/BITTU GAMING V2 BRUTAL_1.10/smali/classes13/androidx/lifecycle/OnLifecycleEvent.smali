.class public abstract annotation interface Landroidx/lifecycle/OnLifecycleEvent;
.super Ljava/lang/Object;
.source "OnLifecycleEvent.java"
.implements Ljava/lang/annotation/Annotation;

# virtual methods
.method public abstract value()Landroidx/lifecycle/Lifecycle$Event;
.end method
