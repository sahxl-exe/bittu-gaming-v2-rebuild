.class  Landroidx/lifecycle/FullLifecycleObserverAdapter;
.super Ljava/lang/Object;
.source "FullLifecycleObserverAdapter.java"
.implements Landroidx/lifecycle/LifecycleEventObserver;

.field private final mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
.field private final mLifecycleEventObserver:Landroidx/lifecycle/LifecycleEventObserver;

# direct methods
.method constructor <init>(Landroidx/lifecycle/FullLifecycleObserver;Landroidx/lifecycle/LifecycleEventObserver;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 5: iput-object v2, v0, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mLifecycleEventObserver:Landroidx/lifecycle/LifecycleEventObserver;
    .line 7: return-void
.end method

# virtual methods
.method public onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 5

    .line 0: sget-object v0, Landroidx/lifecycle/FullLifecycleObserverAdapter$1;->$SwitchMap$androidx$lifecycle$Lifecycle$Event:[I
    .line 2: invoke-virtual {v4}, Landroidx/lifecycle/Lifecycle$Event;->ordinal()I
    .line 5: move-result v1
    .line 6: aget v0, v0, v1
    .line 8: packed-switch v0, :data_64
    .line 11: goto :goto_56
    .line 12: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 14: const-string v1, "ON_ANY must not been send by anybody"
    .line 16: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 19: throw v0
    .line 20: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 22: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onDestroy(Landroidx/lifecycle/LifecycleOwner;)V
    .line 25: goto :goto_56
    .line 26: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 28: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onStop(Landroidx/lifecycle/LifecycleOwner;)V
    .line 31: goto :goto_56
    .line 32: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 34: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onPause(Landroidx/lifecycle/LifecycleOwner;)V
    .line 37: goto :goto_56
    .line 38: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 40: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onResume(Landroidx/lifecycle/LifecycleOwner;)V
    .line 43: goto :goto_56
    .line 44: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 46: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onStart(Landroidx/lifecycle/LifecycleOwner;)V
    .line 49: goto :goto_56
    .line 50: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mFullLifecycleObserver:Landroidx/lifecycle/FullLifecycleObserver;
    .line 52: invoke-interface {v0, v3}, Landroidx/lifecycle/FullLifecycleObserver;->onCreate(Landroidx/lifecycle/LifecycleOwner;)V
    .line 55: nop
    .line 56: iget-object v0, v2, Landroidx/lifecycle/FullLifecycleObserverAdapter;->mLifecycleEventObserver:Landroidx/lifecycle/LifecycleEventObserver;
    .line 58: if-eqz v0, :cond_63
    .line 60: invoke-interface {v0, v3, v4}, Landroidx/lifecycle/LifecycleEventObserver;->onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 63: return-void
    .line 64: nop
    .line 65: move-object v0, v0
    .line 66: move v0, v0
    .line 67: nop
    .line 68: goto/32 :goto_2359364
    .line 71: nop
    .line 72: monitor-exit v0
    .line 73: nop
    .line 74: const-wide v0, 0xc0120
    .line 79: nop
    .line 80: move-wide v0, v0
    .line 81: nop
.end method
