.class public final enum Landroidx/lifecycle/Lifecycle$State;
.super Ljava/lang/Enum;
.source "Lifecycle.java"

.field private static final synthetic $VALUES:[Landroidx/lifecycle/Lifecycle$State;
.field public static final enum CREATED:Landroidx/lifecycle/Lifecycle$State;
.field public static final enum DESTROYED:Landroidx/lifecycle/Lifecycle$State;
.field public static final enum INITIALIZED:Landroidx/lifecycle/Lifecycle$State;
.field public static final enum RESUMED:Landroidx/lifecycle/Lifecycle$State;
.field public static final enum STARTED:Landroidx/lifecycle/Lifecycle$State;

# direct methods
.method static constructor <clinit>()V
    .registers 11

    .line 0: new-instance v0, Landroidx/lifecycle/Lifecycle$State;
    .line 2: const-string v1, "DESTROYED"
    .line 4: const/4 v2, 0
    .line 5: invoke-direct {v0, v1, v2}, Landroidx/lifecycle/Lifecycle$State;-><init>(Ljava/lang/String;I)V
    .line 8: sput-object v0, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;
    .line 10: new-instance v1, Landroidx/lifecycle/Lifecycle$State;
    .line 12: const-string v3, "INITIALIZED"
    .line 14: const/4 v4, 1
    .line 15: invoke-direct {v1, v3, v4}, Landroidx/lifecycle/Lifecycle$State;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v1, Landroidx/lifecycle/Lifecycle$State;->INITIALIZED:Landroidx/lifecycle/Lifecycle$State;
    .line 20: new-instance v3, Landroidx/lifecycle/Lifecycle$State;
    .line 22: const-string v5, "CREATED"
    .line 24: const/4 v6, 2
    .line 25: invoke-direct {v3, v5, v6}, Landroidx/lifecycle/Lifecycle$State;-><init>(Ljava/lang/String;I)V
    .line 28: sput-object v3, Landroidx/lifecycle/Lifecycle$State;->CREATED:Landroidx/lifecycle/Lifecycle$State;
    .line 30: new-instance v5, Landroidx/lifecycle/Lifecycle$State;
    .line 32: const-string v7, "STARTED"
    .line 34: const/4 v8, 3
    .line 35: invoke-direct {v5, v7, v8}, Landroidx/lifecycle/Lifecycle$State;-><init>(Ljava/lang/String;I)V
    .line 38: sput-object v5, Landroidx/lifecycle/Lifecycle$State;->STARTED:Landroidx/lifecycle/Lifecycle$State;
    .line 40: new-instance v7, Landroidx/lifecycle/Lifecycle$State;
    .line 42: const-string v9, "RESUMED"
    .line 44: const/4 v10, 4
    .line 45: invoke-direct {v7, v9, v10}, Landroidx/lifecycle/Lifecycle$State;-><init>(Ljava/lang/String;I)V
    .line 48: sput-object v7, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;
    .line 50: const/4 v9, 5
    .line 51: new-array v9, v9, [Landroidx/lifecycle/Lifecycle$State;
    .line 53: aput-object v0, v9, v2
    .line 55: aput-object v1, v9, v4
    .line 57: aput-object v3, v9, v6
    .line 59: aput-object v5, v9, v8
    .line 61: aput-object v7, v9, v10
    .line 63: sput-object v9, Landroidx/lifecycle/Lifecycle$State;->$VALUES:[Landroidx/lifecycle/Lifecycle$State;
    .line 65: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Landroidx/lifecycle/Lifecycle$State;
    .registers 2

    .line 0: const-class v0, Landroidx/lifecycle/Lifecycle$State;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/Lifecycle$State;
    .line 8: return-object v0
.end method

# direct methods
.method public static values()[Landroidx/lifecycle/Lifecycle$State;
    .registers 1

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->$VALUES:[Landroidx/lifecycle/Lifecycle$State;
    .line 2: invoke-virtual {v0}, [Landroidx/lifecycle/Lifecycle$State;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Landroidx/lifecycle/Lifecycle$State;
    .line 8: return-object v0
.end method

# virtual methods
.method public isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z
    .registers 3

    .line 0: invoke-virtual {v1, v2}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 3: move-result v0
    .line 4: if-ltz v0, :cond_8
    .line 6: const/4 v0, 1
    .line 7: goto :goto_9
    .line 8: const/4 v0, 0
    .line 9: return v0
.end method
