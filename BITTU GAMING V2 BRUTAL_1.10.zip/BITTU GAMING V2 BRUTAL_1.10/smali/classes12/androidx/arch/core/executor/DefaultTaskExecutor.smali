.class public Landroidx/arch/core/executor/DefaultTaskExecutor;
.super Landroidx/arch/core/executor/TaskExecutor;
.source "DefaultTaskExecutor.java"

.field private final mDiskIO:Ljava/util/concurrent/ExecutorService;
.field private final mLock:Ljava/lang/Object;
.field private volatile mMainHandler:Landroid/os/Handler;

# direct methods
.method public constructor <init>()V
    .registers 8

    .line 0: move-object v0, v7
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Landroidx/arch/core/executor/TaskExecutor;-><init>()V
    .line 5: move-object v1, v0
    .line 6: new-instance v2, Ljava/lang/Object;
    .line 8: move-object v6, v2
    .line 9: move-object v2, v6
    .line 10: move-object v3, v6
    .line 11: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 14: iput-object v2, v1, Landroidx/arch/core/executor/DefaultTaskExecutor;->mLock:Ljava/lang/Object;
    .line 16: move-object v1, v0
    .line 17: const/4 v2, 4
    .line 18: new-instance v3, Landroidx/arch/core/executor/DefaultTaskExecutor$1;
    .line 20: move-object v6, v3
    .line 21: move-object v3, v6
    .line 22: move-object v4, v6
    .line 23: move-object v5, v0
    .line 24: invoke-direct {v4, v5}, Landroidx/arch/core/executor/DefaultTaskExecutor$1;-><init>(Landroidx/arch/core/executor/DefaultTaskExecutor;)V
    .line 27: invoke-static {v2, v3}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;
    .line 30: move-result-object v2
    .line 31: iput-object v2, v1, Landroidx/arch/core/executor/DefaultTaskExecutor;->mDiskIO:Ljava/util/concurrent/ExecutorService;
    .line 33: return-void
.end method

# direct methods
.method private static createAsync(Landroid/os/Looper;)Landroid/os/Handler;
    .registers 9

    .line 0: move-object v0, v8
    .line 1: sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 3: const/16 v3, 28
    .line 5: if-lt v2, v3, :cond_14
    .line 7: move-object v2, v0
    .line 8: invoke-static {v2}, Landroid/os/Handler;->createAsync(Landroid/os/Looper;)Landroid/os/Handler;
    .line 11: move-result-object v2
    .line 12: move-object v0, v2
    .line 13: return-object v0
    .line 14: sget v2, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 16: const/16 v3, 16
    .line 18: if-lt v2, v3, :cond_91
    .line 20: const-class v2, Landroid/os/Handler;
    .line 22: const/4 v3, 3
    .line 23: new-array v3, v3, [Ljava/lang/Class;
    .line 25: move-object v7, v3
    .line 26: move-object v3, v7
    .line 27: move-object v4, v7
    .line 28: const/4 v5, 0
    .line 29: const-class v6, Landroid/os/Looper;
    .line 31: aput-object v6, v4, v5
    .line 33: move-object v7, v3
    .line 34: move-object v3, v7
    .line 35: move-object v4, v7
    .line 36: const/4 v5, 1
    .line 37: const-class v6, Landroid/os/Handler$Callback;
    .line 39: aput-object v6, v4, v5
    .line 41: move-object v7, v3
    .line 42: move-object v3, v7
    .line 43: move-object v4, v7
    .line 44: const/4 v5, 2
    .line 45: sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 47: aput-object v6, v4, v5
    .line 49: invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 52: move-result-object v2
    .line 53: const/4 v3, 3
    .line 54: new-array v3, v3, [Ljava/lang/Object;
    .line 56: move-object v7, v3
    .line 57: move-object v3, v7
    .line 58: move-object v4, v7
    .line 59: const/4 v5, 0
    .line 60: move-object v6, v0
    .line 61: aput-object v6, v4, v5
    .line 63: move-object v7, v3
    .line 64: move-object v3, v7
    .line 65: move-object v4, v7
    .line 66: const/4 v5, 1
    .line 67: const/4 v6, 0
    .line 68: aput-object v6, v4, v5
    .line 70: move-object v7, v3
    .line 71: move-object v3, v7
    .line 72: move-object v4, v7
    .line 73: const/4 v5, 2
    .line 74: const/4 v6, 1
    .line 75: invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 78: move-result-object v6
    .line 79: aput-object v6, v4, v5
    .line 81: invoke-virtual {v2, v3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 84: move-result-object v2
    .line 85: check-cast v2, Landroid/os/Handler;
    .line 87: move-object v0, v2
    .line 88: goto :goto_13
    .line 89: move-exception v2
    .line 90: move-object v1, v2
    .line 91: new-instance v2, Landroid/os/Handler;
    .line 93: move-object v7, v2
    .line 94: move-object v2, v7
    .line 95: move-object v3, v7
    .line 96: move-object v4, v0
    .line 97: invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 100: move-object v0, v2
    .line 101: goto :goto_13
    .line 102: move-exception v2
    .line 103: move-object v1, v2
    .line 104: goto :goto_91
    .line 105: move-exception v2
    .line 106: move-object v1, v2
    .line 107: goto :goto_91
    .line 108: move-exception v2
    .line 109: move-object v1, v2
    .line 110: new-instance v2, Landroid/os/Handler;
    .line 112: move-object v7, v2
    .line 113: move-object v2, v7
    .line 114: move-object v3, v7
    .line 115: move-object v4, v0
    .line 116: invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    .line 119: move-object v0, v2
    .line 120: goto :goto_13
.end method

# virtual methods
.method public executeOnDiskIO(Ljava/lang/Runnable;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/executor/DefaultTaskExecutor;->mDiskIO:Ljava/util/concurrent/ExecutorService;
    .line 5: move-object v3, v1
    .line 6: invoke-interface {v2, v3}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V
    .line 9: return-void
.end method

# virtual methods
.method public isMainThread()Z
    .registers 4

    .line 0: move-object v0, v3
    .line 1: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 4: move-result-object v1
    .line 5: invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;
    .line 8: move-result-object v1
    .line 9: invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;
    .line 12: move-result-object v2
    .line 13: if-ne v1, v2, :cond_18
    .line 15: const/4 v1, 1
    .line 16: move v0, v1
    .line 17: return v0
    .line 18: const/4 v1, 0
    .line 19: goto :goto_16
.end method

# virtual methods
.method public postToMainThread(Ljava/lang/Runnable;)V
    .registers 9

    .line 0: move-object v0, v7
    .line 1: move-object v1, v8
    .line 2: move-object v4, v0
    .line 3: iget-object v4, v4, Landroidx/arch/core/executor/DefaultTaskExecutor;->mMainHandler:Landroid/os/Handler;
    .line 5: if-nez v4, :cond_33
    .line 7: move-object v4, v0
    .line 8: iget-object v4, v4, Landroidx/arch/core/executor/DefaultTaskExecutor;->mLock:Ljava/lang/Object;
    .line 10: move-object v6, v4
    .line 11: move-object v4, v6
    .line 12: move-object v5, v6
    .line 13: move-object v2, v5
    .line 14: monitor-enter v4
    .line 15: move-object v4, v0
    .line 16: iget-object v4, v4, Landroidx/arch/core/executor/DefaultTaskExecutor;->mMainHandler:Landroid/os/Handler;
    .line 18: if-nez v4, :cond_31
    .line 20: move-object v4, v0
    .line 21: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    .line 24: move-result-object v5
    .line 25: invoke-static {v5}, Landroidx/arch/core/executor/DefaultTaskExecutor;->createAsync(Landroid/os/Looper;)Landroid/os/Handler;
    .line 28: move-result-object v5
    .line 29: iput-object v5, v4, Landroidx/arch/core/executor/DefaultTaskExecutor;->mMainHandler:Landroid/os/Handler;
    .line 31: move-object v4, v2
    .line 32: monitor-exit v4
    .line 33: move-object v4, v0
    .line 34: iget-object v4, v4, Landroidx/arch/core/executor/DefaultTaskExecutor;->mMainHandler:Landroid/os/Handler;
    .line 36: move-object v5, v1
    .line 37: invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    .line 40: move-result v4
    .line 41: return-void
    .line 42: move-exception v4
    .line 43: move-object v3, v4
    .line 44: move-object v4, v2
    .line 45: monitor-exit v4
    .line 46: move-object v4, v3
    .line 47: throw v4
.end method
