.class  Landroidx/arch/core/executor/DefaultTaskExecutor$1;
.super Ljava/lang/Object;
.source "DefaultTaskExecutor.java"
.implements Ljava/util/concurrent/ThreadFactory;

.field private static final THREAD_NAME_STEM:Ljava/lang/String;

.field private final mThreadId:Ljava/util/concurrent/atomic/AtomicInteger;
.field final synthetic this$0:Landroidx/arch/core/executor/DefaultTaskExecutor;

# direct methods
.method constructor <init>(Landroidx/arch/core/executor/DefaultTaskExecutor;)V
    .registers 9

    .line 0: move-object v0, v7
    .line 1: move-object v1, v8
    .line 2: move-object v2, v0
    .line 3: move-object v3, v1
    .line 4: iput-object v3, v2, Landroidx/arch/core/executor/DefaultTaskExecutor$1;->this$0:Landroidx/arch/core/executor/DefaultTaskExecutor;
    .line 6: move-object v2, v0
    .line 7: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 10: move-object v2, v0
    .line 11: new-instance v3, Ljava/util/concurrent/atomic/AtomicInteger;
    .line 13: move-object v6, v3
    .line 14: move-object v3, v6
    .line 15: move-object v4, v6
    .line 16: const/4 v5, 0
    .line 17: invoke-direct {v4, v5}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    .line 20: iput-object v3, v2, Landroidx/arch/core/executor/DefaultTaskExecutor$1;->mThreadId:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 22: return-void
.end method

# virtual methods
.method public newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .registers 12

    .line 0: move-object v0, v10
    .line 1: move-object v1, v11
    .line 2: new-instance v3, Ljava/lang/Thread;
    .line 4: move-object v9, v3
    .line 5: move-object v3, v9
    .line 6: move-object v4, v9
    .line 7: move-object v5, v1
    .line 8: invoke-direct {v4, v5}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V
    .line 11: move-object v2, v3
    .line 12: move-object v3, v2
    .line 13: const-string v4, "arch_disk_io_%d"
    .line 15: const/4 v5, 1
    .line 16: new-array v5, v5, [Ljava/lang/Object;
    .line 18: move-object v9, v5
    .line 19: move-object v5, v9
    .line 20: move-object v6, v9
    .line 21: const/4 v7, 0
    .line 22: move-object v8, v0
    .line 23: iget-object v8, v8, Landroidx/arch/core/executor/DefaultTaskExecutor$1;->mThreadId:Ljava/util/concurrent/atomic/AtomicInteger;
    .line 25: invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I
    .line 28: move-result v8
    .line 29: invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    .line 32: move-result-object v8
    .line 33: aput-object v8, v6, v7
    .line 35: invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 38: move-result-object v4
    .line 39: invoke-virtual {v3, v4}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V
    .line 42: move-object v3, v2
    .line 43: move-object v0, v3
    .line 44: return-object v0
.end method
