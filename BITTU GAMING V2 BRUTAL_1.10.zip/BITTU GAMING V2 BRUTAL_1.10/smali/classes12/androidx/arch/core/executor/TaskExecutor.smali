.class public abstract Landroidx/arch/core/executor/TaskExecutor;
.super Ljava/lang/Object;
.source "TaskExecutor.java"

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public abstract executeOnDiskIO(Ljava/lang/Runnable;)V
.end method

# virtual methods
.method public executeOnMainThread(Ljava/lang/Runnable;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: invoke-virtual {v2}, Landroidx/arch/core/executor/TaskExecutor;->isMainThread()Z
    .line 6: move-result v2
    .line 7: if-eqz v2, :cond_14
    .line 9: move-object v2, v1
    .line 10: invoke-interface {v2}, Ljava/lang/Runnable;->run()V
    .line 13: return-void
    .line 14: move-object v2, v0
    .line 15: move-object v3, v1
    .line 16: invoke-virtual {v2, v3}, Landroidx/arch/core/executor/TaskExecutor;->postToMainThread(Ljava/lang/Runnable;)V
    .line 19: goto :goto_13
.end method

# virtual methods
.method public abstract isMainThread()Z
.end method

# virtual methods
.method public abstract postToMainThread(Ljava/lang/Runnable;)V
.end method
