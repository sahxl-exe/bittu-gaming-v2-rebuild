.class public Landroidx/arch/core/executor/ArchTaskExecutor;
.super Landroidx/arch/core/executor/TaskExecutor;
.source "ArchTaskExecutor.java"

.field private static final sIOThreadExecutor:Ljava/util/concurrent/Executor;
.field private static volatile sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
.field private static final sMainThreadExecutor:Ljava/util/concurrent/Executor;

.field private mDefaultTaskExecutor:Landroidx/arch/core/executor/TaskExecutor;
.field private mDelegate:Landroidx/arch/core/executor/TaskExecutor;

# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 0: new-instance v0, Landroidx/arch/core/executor/ArchTaskExecutor$1;
    .line 2: move-object v2, v0
    .line 3: move-object v0, v2
    .line 4: move-object v1, v2
    .line 5: invoke-direct {v1}, Landroidx/arch/core/executor/ArchTaskExecutor$1;-><init>()V
    .line 8: sput-object v0, Landroidx/arch/core/executor/ArchTaskExecutor;->sMainThreadExecutor:Ljava/util/concurrent/Executor;
    .line 10: new-instance v0, Landroidx/arch/core/executor/ArchTaskExecutor$2;
    .line 12: move-object v2, v0
    .line 13: move-object v0, v2
    .line 14: move-object v1, v2
    .line 15: invoke-direct {v1}, Landroidx/arch/core/executor/ArchTaskExecutor$2;-><init>()V
    .line 18: sput-object v0, Landroidx/arch/core/executor/ArchTaskExecutor;->sIOThreadExecutor:Ljava/util/concurrent/Executor;
    .line 20: return-void
.end method

# direct methods
.method private constructor <init>()V
    .registers 6

    .line 0: move-object v0, v5
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Landroidx/arch/core/executor/TaskExecutor;-><init>()V
    .line 5: move-object v1, v0
    .line 6: new-instance v2, Landroidx/arch/core/executor/DefaultTaskExecutor;
    .line 8: move-object v4, v2
    .line 9: move-object v2, v4
    .line 10: move-object v3, v4
    .line 11: invoke-direct {v3}, Landroidx/arch/core/executor/DefaultTaskExecutor;-><init>()V
    .line 14: iput-object v2, v1, Landroidx/arch/core/executor/ArchTaskExecutor;->mDefaultTaskExecutor:Landroidx/arch/core/executor/TaskExecutor;
    .line 16: move-object v1, v0
    .line 17: move-object v2, v0
    .line 18: iget-object v2, v2, Landroidx/arch/core/executor/ArchTaskExecutor;->mDefaultTaskExecutor:Landroidx/arch/core/executor/TaskExecutor;
    .line 20: iput-object v2, v1, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Landroidx/arch/core/executor/TaskExecutor;
    .line 22: return-void
.end method

# direct methods
.method public static getIOThreadExecutor()Ljava/util/concurrent/Executor;
    .registers 1

    .line 0: sget-object v0, Landroidx/arch/core/executor/ArchTaskExecutor;->sIOThreadExecutor:Ljava/util/concurrent/Executor;
    .line 2: return-object v0
.end method

# direct methods
.method public static getInstance()Landroidx/arch/core/executor/ArchTaskExecutor;
    .registers 5

    .line 0: sget-object v2, Landroidx/arch/core/executor/ArchTaskExecutor;->sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 2: if-eqz v2, :cond_8
    .line 4: sget-object v2, Landroidx/arch/core/executor/ArchTaskExecutor;->sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 6: move-object v0, v2
    .line 7: return-object v0
    .line 8: const-class v2, Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 10: move-object v4, v2
    .line 11: move-object v2, v4
    .line 12: move-object v3, v4
    .line 13: move-object v0, v3
    .line 14: monitor-enter v2
    .line 15: sget-object v2, Landroidx/arch/core/executor/ArchTaskExecutor;->sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 17: if-nez v2, :cond_29
    .line 19: new-instance v2, Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 21: move-object v4, v2
    .line 22: move-object v2, v4
    .line 23: move-object v3, v4
    .line 24: invoke-direct {v3}, Landroidx/arch/core/executor/ArchTaskExecutor;-><init>()V
    .line 27: sput-object v2, Landroidx/arch/core/executor/ArchTaskExecutor;->sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 29: move-object v2, v0
    .line 30: monitor-exit v2
    .line 31: sget-object v2, Landroidx/arch/core/executor/ArchTaskExecutor;->sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 33: move-object v0, v2
    .line 34: goto :goto_7
    .line 35: move-exception v2
    .line 36: move-object v1, v2
    .line 37: move-object v2, v0
    .line 38: monitor-exit v2
    .line 39: move-object v2, v1
    .line 40: throw v2
.end method

# direct methods
.method public static getMainThreadExecutor()Ljava/util/concurrent/Executor;
    .registers 1

    .line 0: sget-object v0, Landroidx/arch/core/executor/ArchTaskExecutor;->sMainThreadExecutor:Ljava/util/concurrent/Executor;
    .line 2: return-object v0
.end method

# virtual methods
.method public executeOnDiskIO(Ljava/lang/Runnable;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Landroidx/arch/core/executor/TaskExecutor;
    .line 5: move-object v3, v1
    .line 6: invoke-virtual {v2, v3}, Landroidx/arch/core/executor/TaskExecutor;->executeOnDiskIO(Ljava/lang/Runnable;)V
    .line 9: return-void
.end method

# virtual methods
.method public isMainThread()Z
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Landroidx/arch/core/executor/TaskExecutor;
    .line 4: invoke-virtual {v1}, Landroidx/arch/core/executor/TaskExecutor;->isMainThread()Z
    .line 7: move-result v1
    .line 8: move v0, v1
    .line 9: return v0
.end method

# virtual methods
.method public postToMainThread(Ljava/lang/Runnable;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Landroidx/arch/core/executor/TaskExecutor;
    .line 5: move-object v3, v1
    .line 6: invoke-virtual {v2, v3}, Landroidx/arch/core/executor/TaskExecutor;->postToMainThread(Ljava/lang/Runnable;)V
    .line 9: return-void
.end method

# virtual methods
.method public setDelegate(Landroidx/arch/core/executor/TaskExecutor;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: move-object v3, v1
    .line 4: if-nez v3, :cond_12
    .line 6: move-object v3, v0
    .line 7: iget-object v3, v3, Landroidx/arch/core/executor/ArchTaskExecutor;->mDefaultTaskExecutor:Landroidx/arch/core/executor/TaskExecutor;
    .line 9: iput-object v3, v2, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Landroidx/arch/core/executor/TaskExecutor;
    .line 11: return-void
    .line 12: move-object v3, v1
    .line 13: goto :goto_9
.end method
