.class final Landroidx/arch/core/executor/ArchTaskExecutor$2;
.super Ljava/lang/Object;
.source "ArchTaskExecutor.java"
.implements Ljava/util/concurrent/Executor;

# direct methods
.method constructor <init>()V
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public execute(Ljava/lang/Runnable;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: invoke-static {}, Landroidx/arch/core/executor/ArchTaskExecutor;->getInstance()Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 5: move-result-object v2
    .line 6: move-object v3, v1
    .line 7: invoke-virtual {v2, v3}, Landroidx/arch/core/executor/ArchTaskExecutor;->executeOnDiskIO(Ljava/lang/Runnable;)V
    .line 10: return-void
.end method
