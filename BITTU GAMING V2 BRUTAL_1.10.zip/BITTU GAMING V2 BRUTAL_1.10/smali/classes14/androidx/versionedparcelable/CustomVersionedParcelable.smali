.class public abstract Landroidx/versionedparcelable/CustomVersionedParcelable;
.super Ljava/lang/Object;
.source "CustomVersionedParcelable.java"
.implements Landroidx/versionedparcelable/VersionedParcelable;

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public onPostParceling()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method public onPreParceling(Z)V
    .registers 2

    .line 0: return-void
.end method
