.class public Landroidx/versionedparcelable/ParcelUtils;
.super Ljava/lang/Object;
.source "ParcelUtils.java"

.field private static final INNER_BUNDLE_KEY:Ljava/lang/String;

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static fromInputStream(Ljava/io/InputStream;)Landroidx/versionedparcelable/VersionedParcelable;
    .registers 3

    .line 0: new-instance v0, Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v2, v1}, Landroidx/versionedparcelable/VersionedParcelStream;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .line 6: invoke-virtual {v0}, Landroidx/versionedparcelable/VersionedParcelStream;->readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .line 9: move-result-object v1
    .line 10: return-object v1
.end method

# direct methods
.method public static fromParcelable(Landroid/os/Parcelable;)Landroidx/versionedparcelable/VersionedParcelable;
    .registers 3

    .line 0: instance-of v0, v2, Landroidx/versionedparcelable/ParcelImpl;
    .line 2: if-eqz v0, :cond_12
    .line 4: move-object v0, v2
    .line 5: check-cast v0, Landroidx/versionedparcelable/ParcelImpl;
    .line 7: invoke-virtual {v0}, Landroidx/versionedparcelable/ParcelImpl;->getVersionedParcel()Landroidx/versionedparcelable/VersionedParcelable;
    .line 10: move-result-object v0
    .line 11: return-object v0
    .line 12: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 14: const-string v1, "Invalid parcel"
    .line 16: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 19: throw v0
.end method

# direct methods
.method public static getVersionedParcelable(Landroid/os/Bundle;Ljava/lang/String;)Landroidx/versionedparcelable/VersionedParcelable;
    .registers 5

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v3, v4}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    .line 4: move-result-object v1
    .line 5: check-cast v1, Landroid/os/Bundle;
    .line 7: if-nez v1, :cond_10
    .line 9: return-object v0
    .line 10: const-class v2, Landroidx/versionedparcelable/ParcelUtils;
    .line 12: invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 15: move-result-object v2
    .line 16: invoke-virtual {v1, v2}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    .line 19: const-string v2, "a"
    .line 21: invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    .line 24: move-result-object v2
    .line 25: invoke-static {v2}, Landroidx/versionedparcelable/ParcelUtils;->fromParcelable(Landroid/os/Parcelable;)Landroidx/versionedparcelable/VersionedParcelable;
    .line 28: move-result-object v0
    .line 29: return-object v0
    .line 30: move-exception v1
    .line 31: return-object v0
.end method

# direct methods
.method public static getVersionedParcelableList(Landroid/os/Bundle;Ljava/lang/String;)Ljava/util/List;
    .registers 8

    .line 0: new-instance v0, Ljava/util/ArrayList;
    .line 2: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 5: invoke-virtual {v6, v7}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    .line 8: move-result-object v1
    .line 9: check-cast v1, Landroid/os/Bundle;
    .line 11: const-class v2, Landroidx/versionedparcelable/ParcelUtils;
    .line 13: invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 16: move-result-object v2
    .line 17: invoke-virtual {v1, v2}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    .line 20: const-string v2, "a"
    .line 22: invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 25: move-result-object v2
    .line 26: invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    .line 29: move-result-object v3
    .line 30: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 33: move-result v4
    .line 34: if-eqz v4, :cond_51
    .line 36: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 39: move-result-object v4
    .line 40: check-cast v4, Landroid/os/Parcelable;
    .line 42: invoke-static {v4}, Landroidx/versionedparcelable/ParcelUtils;->fromParcelable(Landroid/os/Parcelable;)Landroidx/versionedparcelable/VersionedParcelable;
    .line 45: move-result-object v5
    .line 46: invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 49: nop
    .line 50: goto :goto_30
    .line 51: return-object v0
    .line 52: move-exception v1
    .line 53: const/4 v1, 0
    .line 54: return-object v1
.end method

# direct methods
.method public static putVersionedParcelable(Landroid/os/Bundle;Ljava/lang/String;Landroidx/versionedparcelable/VersionedParcelable;)V
    .registers 6

    .line 0: if-nez v5, :cond_3
    .line 2: return-void
    .line 3: new-instance v0, Landroid/os/Bundle;
    .line 5: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    .line 8: invoke-static {v5}, Landroidx/versionedparcelable/ParcelUtils;->toParcelable(Landroidx/versionedparcelable/VersionedParcelable;)Landroid/os/Parcelable;
    .line 11: move-result-object v1
    .line 12: const-string v2, "a"
    .line 14: invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 17: invoke-virtual {v3, v4, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 20: return-void
.end method

# direct methods
.method public static putVersionedParcelableList(Landroid/os/Bundle;Ljava/lang/String;Ljava/util/List;)V
    .registers 8

    .line 0: new-instance v0, Landroid/os/Bundle;
    .line 2: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    .line 5: new-instance v1, Ljava/util/ArrayList;
    .line 7: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 10: invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    .line 13: move-result-object v2
    .line 14: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 17: move-result v3
    .line 18: if-eqz v3, :cond_34
    .line 20: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 23: move-result-object v3
    .line 24: check-cast v3, Landroidx/versionedparcelable/VersionedParcelable;
    .line 26: invoke-static {v3}, Landroidx/versionedparcelable/ParcelUtils;->toParcelable(Landroidx/versionedparcelable/VersionedParcelable;)Landroid/os/Parcelable;
    .line 29: move-result-object v4
    .line 30: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 33: goto :goto_14
    .line 34: const-string v2, "a"
    .line 36: invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V
    .line 39: invoke-virtual {v5, v6, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 42: return-void
.end method

# direct methods
.method public static toOutputStream(Landroidx/versionedparcelable/VersionedParcelable;Ljava/io/OutputStream;)V
    .registers 4

    .line 0: new-instance v0, Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v1, v3}, Landroidx/versionedparcelable/VersionedParcelStream;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .line 6: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcelStream;->writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 9: invoke-virtual {v0}, Landroidx/versionedparcelable/VersionedParcelStream;->closeField()V
    .line 12: return-void
.end method

# direct methods
.method public static toParcelable(Landroidx/versionedparcelable/VersionedParcelable;)Landroid/os/Parcelable;
    .registers 2

    .line 0: new-instance v0, Landroidx/versionedparcelable/ParcelImpl;
    .line 2: invoke-direct {v0, v1}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 5: return-object v0
.end method
