.class final Landroidx/versionedparcelable/ParcelImpl$1;
.super Ljava/lang/Object;
.source "ParcelImpl.java"
.implements Landroid/os/Parcelable$Creator;

# direct methods
.method constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Landroidx/versionedparcelable/ParcelImpl;
    .registers 3

    .line 0: new-instance v0, Landroidx/versionedparcelable/ParcelImpl;
    .line 2: invoke-direct {v0, v2}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroid/os/Parcel;)V
    .line 5: return-object v0
.end method

# virtual methods
.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/ParcelImpl$1;->createFromParcel(Landroid/os/Parcel;)Landroidx/versionedparcelable/ParcelImpl;
    .line 3: move-result-object v1
    .line 4: return-object v1
.end method

# virtual methods
.method public newArray(I)[Landroidx/versionedparcelable/ParcelImpl;
    .registers 3

    .line 0: new-array v0, v2, [Landroidx/versionedparcelable/ParcelImpl;
    .line 2: return-object v0
.end method

# virtual methods
.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 2

    .line 0: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/ParcelImpl$1;->newArray(I)[Landroidx/versionedparcelable/ParcelImpl;
    .line 3: move-result-object v1
    .line 4: return-object v1
.end method
