.class  Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
.super Ljava/lang/Object;
.source "VersionedParcelStream.java"

.field final mDataStream:Ljava/io/DataOutputStream;
.field private final mFieldId:I
.field final mOutput:Ljava/io/ByteArrayOutputStream;
.field private final mTarget:Ljava/io/DataOutputStream;

# direct methods
.method constructor <init>(ILjava/io/DataOutputStream;)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/io/ByteArrayOutputStream;
    .line 5: invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    .line 8: iput-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mOutput:Ljava/io/ByteArrayOutputStream;
    .line 10: new-instance v1, Ljava/io/DataOutputStream;
    .line 12: invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    .line 15: iput-object v1, v2, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mDataStream:Ljava/io/DataOutputStream;
    .line 17: iput v3, v2, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mFieldId:I
    .line 19: iput-object v4, v2, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mTarget:Ljava/io/DataOutputStream;
    .line 21: return-void
.end method

# virtual methods
.method  flushField()V
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mDataStream:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataOutputStream;->flush()V
    .line 5: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mOutput:Ljava/io/ByteArrayOutputStream;
    .line 7: invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I
    .line 10: move-result v0
    .line 11: iget v1, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mFieldId:I
    .line 13: shl-int/lit8 v1, v1, 16
    .line 15: const v2, 0xffff
    .line 18: if-lt v0, v2, :cond_24
    .line 20: const v3, 0xffff
    .line 23: goto :goto_25
    .line 24: move v3, v0
    .line 25: or-int/2addr v1, v3
    .line 26: iget-object v3, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mTarget:Ljava/io/DataOutputStream;
    .line 28: invoke-virtual {v3, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 31: if-lt v0, v2, :cond_38
    .line 33: iget-object v2, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mTarget:Ljava/io/DataOutputStream;
    .line 35: invoke-virtual {v2, v0}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 38: iget-object v2, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mOutput:Ljava/io/ByteArrayOutputStream;
    .line 40: iget-object v3, v4, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mTarget:Ljava/io/DataOutputStream;
    .line 42: invoke-virtual {v2, v3}, Ljava/io/ByteArrayOutputStream;->writeTo(Ljava/io/OutputStream;)V
    .line 45: return-void
.end method
