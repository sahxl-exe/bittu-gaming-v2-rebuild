.class public abstract annotation interface Landroidx/versionedparcelable/NonParcelField;
.super Ljava/lang/Object;
.source "NonParcelField.java"
.implements Ljava/lang/annotation/Annotation;
