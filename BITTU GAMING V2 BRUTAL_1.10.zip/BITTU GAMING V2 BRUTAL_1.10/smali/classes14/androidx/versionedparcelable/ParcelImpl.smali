.class public Landroidx/versionedparcelable/ParcelImpl;
.super Ljava/lang/Object;
.source "ParcelImpl.java"
.implements Landroid/os/Parcelable;

.field public static final CREATOR:Landroid/os/Parcelable$Creator;

.field private final mParcel:Landroidx/versionedparcelable/VersionedParcelable;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: new-instance v0, Landroidx/versionedparcelable/ParcelImpl$1;
    .line 2: invoke-direct {v0}, Landroidx/versionedparcelable/ParcelImpl$1;-><init>()V
    .line 5: sput-object v0, Landroidx/versionedparcelable/ParcelImpl;->CREATOR:Landroid/os/Parcelable$Creator;
    .line 7: return-void
.end method

# direct methods
.method protected constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Landroidx/versionedparcelable/VersionedParcelParcel;
    .line 5: invoke-direct {v0, v2}, Landroidx/versionedparcelable/VersionedParcelParcel;-><init>(Landroid/os/Parcel;)V
    .line 8: invoke-virtual {v0}, Landroidx/versionedparcelable/VersionedParcelParcel;->readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .line 11: move-result-object v0
    .line 12: iput-object v0, v1, Landroidx/versionedparcelable/ParcelImpl;->mParcel:Landroidx/versionedparcelable/VersionedParcelable;
    .line 14: return-void
.end method

# direct methods
.method public constructor <init>(Landroidx/versionedparcelable/VersionedParcelable;)V
    .registers 2

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/versionedparcelable/ParcelImpl;->mParcel:Landroidx/versionedparcelable/VersionedParcelable;
    .line 5: return-void
.end method

# virtual methods
.method public describeContents()I
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

# virtual methods
.method public getVersionedParcel()Landroidx/versionedparcelable/VersionedParcelable;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/ParcelImpl;->mParcel:Landroidx/versionedparcelable/VersionedParcelable;
    .line 2: return-object v0
.end method

# virtual methods
.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 5

    .line 0: new-instance v0, Landroidx/versionedparcelable/VersionedParcelParcel;
    .line 2: invoke-direct {v0, v3}, Landroidx/versionedparcelable/VersionedParcelParcel;-><init>(Landroid/os/Parcel;)V
    .line 5: iget-object v1, v2, Landroidx/versionedparcelable/ParcelImpl;->mParcel:Landroidx/versionedparcelable/VersionedParcelable;
    .line 7: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcelParcel;->writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 10: return-void
.end method
