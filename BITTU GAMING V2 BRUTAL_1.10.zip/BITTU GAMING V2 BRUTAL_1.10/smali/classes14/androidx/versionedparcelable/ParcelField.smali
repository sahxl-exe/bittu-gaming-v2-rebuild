.class public abstract annotation interface Landroidx/versionedparcelable/ParcelField;
.super Ljava/lang/Object;
.source "ParcelField.java"
.implements Ljava/lang/annotation/Annotation;

# virtual methods
.method public abstract defaultValue()Ljava/lang/String;
.end method

# virtual methods
.method public abstract value()I
.end method
