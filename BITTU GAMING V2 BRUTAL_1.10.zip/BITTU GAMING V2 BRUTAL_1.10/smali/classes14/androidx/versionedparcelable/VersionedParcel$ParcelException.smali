.class public Landroidx/versionedparcelable/VersionedParcel$ParcelException;
.super Ljava/lang/RuntimeException;
.source "VersionedParcel.java"

# direct methods
.method public constructor <init>(Ljava/lang/Throwable;)V
    .registers 2

    .line 0: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 3: return-void
.end method
