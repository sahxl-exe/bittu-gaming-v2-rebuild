.class public abstract interface Landroidx/versionedparcelable/VersionedParcelable;
.super Ljava/lang/Object;
.source "VersionedParcelable.java"
