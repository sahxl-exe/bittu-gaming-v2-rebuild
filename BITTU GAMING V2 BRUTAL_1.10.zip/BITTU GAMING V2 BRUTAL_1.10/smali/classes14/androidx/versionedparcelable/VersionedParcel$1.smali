.class  Landroidx/versionedparcelable/VersionedParcel$1;
.super Ljava/io/ObjectInputStream;
.source "VersionedParcel.java"

.field final synthetic this$0:Landroidx/versionedparcelable/VersionedParcel;

# direct methods
.method constructor <init>(Landroidx/versionedparcelable/VersionedParcel;Ljava/io/InputStream;)V
    .registers 3

    .line 0: iput-object v1, v0, Landroidx/versionedparcelable/VersionedParcel$1;->this$0:Landroidx/versionedparcelable/VersionedParcel;
    .line 2: invoke-direct {v0, v2}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    .line 5: return-void
.end method

# virtual methods
.method protected resolveClass(Ljava/io/ObjectStreamClass;)Ljava/lang/Class;
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/io/ObjectStreamClass;->getName()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 7: move-result-object v1
    .line 8: invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 11: move-result-object v1
    .line 12: const/4 v2, 0
    .line 13: invoke-static {v0, v2, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    .line 16: move-result-object v0
    .line 17: if-eqz v0, :cond_20
    .line 19: return-object v0
    .line 20: invoke-super {v3, v4}, Ljava/io/ObjectInputStream;->resolveClass(Ljava/io/ObjectStreamClass;)Ljava/lang/Class;
    .line 23: move-result-object v1
    .line 24: return-object v1
.end method
