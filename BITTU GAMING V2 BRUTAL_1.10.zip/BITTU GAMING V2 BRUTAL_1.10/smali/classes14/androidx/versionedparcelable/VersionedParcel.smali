.class public abstract Landroidx/versionedparcelable/VersionedParcel;
.super Ljava/lang/Object;
.source "VersionedParcel.java"

.field private static final EX_BAD_PARCELABLE:I
.field private static final EX_ILLEGAL_ARGUMENT:I
.field private static final EX_ILLEGAL_STATE:I
.field private static final EX_NETWORK_MAIN_THREAD:I
.field private static final EX_NULL_POINTER:I
.field private static final EX_PARCELABLE:I
.field private static final EX_SECURITY:I
.field private static final EX_UNSUPPORTED_OPERATION:I
.field private static final TAG:Ljava/lang/String;
.field private static final TYPE_BINDER:I
.field private static final TYPE_FLOAT:I
.field private static final TYPE_INTEGER:I
.field private static final TYPE_PARCELABLE:I
.field private static final TYPE_SERIALIZABLE:I
.field private static final TYPE_STRING:I
.field private static final TYPE_VERSIONED_PARCELABLE:I

.field protected final mParcelizerCache:Landroidx/collection/ArrayMap;
.field protected final mReadCache:Landroidx/collection/ArrayMap;
.field protected final mWriteCache:Landroidx/collection/ArrayMap;

# direct methods
.method public constructor <init>(Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .registers 4

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/versionedparcelable/VersionedParcel;->mReadCache:Landroidx/collection/ArrayMap;
    .line 5: iput-object v2, v0, Landroidx/versionedparcelable/VersionedParcel;->mWriteCache:Landroidx/collection/ArrayMap;
    .line 7: iput-object v3, v0, Landroidx/versionedparcelable/VersionedParcel;->mParcelizerCache:Landroidx/collection/ArrayMap;
    .line 9: return-void
.end method

# direct methods
.method private createException(ILjava/lang/String;)Ljava/lang/Exception;
    .registers 6

    .line 0: packed-switch v4, :data_84
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: new-instance v1, Ljava/lang/StringBuilder;
    .line 7: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 10: const-string v2, "Unknown exception code: "
    .line 12: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 15: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 18: const-string v2, " msg "
    .line 20: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 26: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 29: move-result-object v1
    .line 30: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 33: return-object v0
    .line 34: new-instance v0, Ljava/lang/SecurityException;
    .line 36: invoke-direct {v0, v5}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V
    .line 39: return-object v0
    .line 40: new-instance v0, Landroid/os/BadParcelableException;
    .line 42: invoke-direct {v0, v5}, Landroid/os/BadParcelableException;-><init>(Ljava/lang/String;)V
    .line 45: return-object v0
    .line 46: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 48: invoke-direct {v0, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 51: return-object v0
    .line 52: new-instance v0, Ljava/lang/NullPointerException;
    .line 54: invoke-direct {v0, v5}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    .line 57: return-object v0
    .line 58: new-instance v0, Ljava/lang/IllegalStateException;
    .line 60: invoke-direct {v0, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 63: return-object v0
    .line 64: new-instance v0, Landroid/os/NetworkOnMainThreadException;
    .line 66: invoke-direct {v0}, Landroid/os/NetworkOnMainThreadException;-><init>()V
    .line 69: return-object v0
    .line 70: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 72: invoke-direct {v0, v5}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 75: return-object v0
    .line 76: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readParcelable()Landroid/os/Parcelable;
    .line 79: move-result-object v0
    .line 80: check-cast v0, Ljava/lang/Exception;
    .line 82: return-object v0
    .line 83: nop
    .line 84: nop
    .line 85: move-object/16 v65527, v65535
    .line 88: aput-wide v0, v0, v0
    .line 90: move/16 v0, v70
    .line 93: nop
    .line 94: 0x40 ; unknown opcode
    .line 95: nop
    .line 96: if-ltz v0, :cond_96
    .line 98: if-lt v0, v0, :cond_98
    .line 100: cmpg-float v0, v0, v0
    .line 102: goto :goto_102
    .line 103: nop
    .line 104: new-instance v0, B
.end method

# direct methods
.method private findParcelClass(Ljava/lang/Class;)Ljava/lang/Class;
    .registers 8

    .line 0: iget-object v0, v6, Landroidx/versionedparcelable/VersionedParcel;->mParcelizerCache:Landroidx/collection/ArrayMap;
    .line 2: invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v0, v1}, Landroidx/collection/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Ljava/lang/Class;
    .line 12: if-nez v0, :cond_58
    .line 14: invoke-virtual {v7}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;
    .line 17: move-result-object v1
    .line 18: invoke-virtual {v1}, Ljava/lang/Package;->getName()Ljava/lang/String;
    .line 21: move-result-object v1
    .line 22: const/4 v2, 2
    .line 23: new-array v2, v2, [Ljava/lang/Object;
    .line 25: const/4 v3, 0
    .line 26: aput-object v1, v2, v3
    .line 28: const/4 v4, 1
    .line 29: invoke-virtual {v7}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 32: move-result-object v5
    .line 33: aput-object v5, v2, v4
    .line 35: const-string v4, "%s.%sParcelizer"
    .line 37: invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .line 40: move-result-object v2
    .line 41: invoke-virtual {v7}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 44: move-result-object v4
    .line 45: invoke-static {v2, v3, v4}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    .line 48: move-result-object v0
    .line 49: iget-object v3, v6, Landroidx/versionedparcelable/VersionedParcel;->mParcelizerCache:Landroidx/collection/ArrayMap;
    .line 51: invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 54: move-result-object v4
    .line 55: invoke-virtual {v3, v4, v0}, Landroidx/collection/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 58: return-object v0
.end method

# direct methods
.method private getReadMethod(Ljava/lang/String;)Ljava/lang/reflect/Method;
    .registers 9

    .line 0: const-class v0, Landroidx/versionedparcelable/VersionedParcel;
    .line 2: iget-object v1, v7, Landroidx/versionedparcelable/VersionedParcel;->mReadCache:Landroidx/collection/ArrayMap;
    .line 4: invoke-virtual {v1, v8}, Landroidx/collection/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 7: move-result-object v1
    .line 8: check-cast v1, Ljava/lang/reflect/Method;
    .line 10: if-nez v1, :cond_41
    .line 12: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 15: move-result-wide v2
    .line 16: invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 19: move-result-object v4
    .line 20: const/4 v5, 1
    .line 21: invoke-static {v8, v5, v4}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    .line 24: move-result-object v4
    .line 25: new-array v5, v5, [Ljava/lang/Class;
    .line 27: const/4 v6, 0
    .line 28: aput-object v0, v5, v6
    .line 30: const-string v0, "read"
    .line 32: invoke-virtual {v4, v0, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 35: move-result-object v1
    .line 36: iget-object v0, v7, Landroidx/versionedparcelable/VersionedParcel;->mReadCache:Landroidx/collection/ArrayMap;
    .line 38: invoke-virtual {v0, v8, v1}, Landroidx/collection/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 41: return-object v1
.end method

# direct methods
.method protected static getRootCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    .registers 2

    .line 0: invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_11
    .line 6: invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;
    .line 9: move-result-object v1
    .line 10: goto :goto_0
    .line 11: return-object v1
.end method

# direct methods
.method private getType(Ljava/lang/Object;)I
    .registers 5

    .line 0: instance-of v0, v4, Ljava/lang/String;
    .line 2: if-eqz v0, :cond_6
    .line 4: const/4 v0, 4
    .line 5: return v0
    .line 6: instance-of v0, v4, Landroid/os/Parcelable;
    .line 8: if-eqz v0, :cond_12
    .line 10: const/4 v0, 2
    .line 11: return v0
    .line 12: instance-of v0, v4, Landroidx/versionedparcelable/VersionedParcelable;
    .line 14: if-eqz v0, :cond_18
    .line 16: const/4 v0, 1
    .line 17: return v0
    .line 18: instance-of v0, v4, Ljava/io/Serializable;
    .line 20: if-eqz v0, :cond_24
    .line 22: const/4 v0, 3
    .line 23: return v0
    .line 24: instance-of v0, v4, Landroid/os/IBinder;
    .line 26: if-eqz v0, :cond_30
    .line 28: const/4 v0, 5
    .line 29: return v0
    .line 30: instance-of v0, v4, Ljava/lang/Integer;
    .line 32: if-eqz v0, :cond_36
    .line 34: const/4 v0, 7
    .line 35: return v0
    .line 36: instance-of v0, v4, Ljava/lang/Float;
    .line 38: if-eqz v0, :cond_43
    .line 40: const/16 v0, 8
    .line 42: return v0
    .line 43: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 45: new-instance v1, Ljava/lang/StringBuilder;
    .line 47: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 50: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 53: move-result-object v2
    .line 54: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 57: move-result-object v2
    .line 58: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 61: const-string v2, " cannot be VersionedParcelled"
    .line 63: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 66: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 69: move-result-object v1
    .line 70: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 73: throw v0
.end method

# direct methods
.method private getWriteMethod(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .registers 9

    .line 0: iget-object v0, v7, Landroidx/versionedparcelable/VersionedParcel;->mWriteCache:Landroidx/collection/ArrayMap;
    .line 2: invoke-virtual {v8}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v0, v1}, Landroidx/collection/ArrayMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Ljava/lang/reflect/Method;
    .line 12: if-nez v0, :cond_48
    .line 14: invoke-direct {v7, v8}, Landroidx/versionedparcelable/VersionedParcel;->findParcelClass(Ljava/lang/Class;)Ljava/lang/Class;
    .line 17: move-result-object v1
    .line 18: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    .line 21: move-result-wide v2
    .line 22: const/4 v4, 2
    .line 23: new-array v4, v4, [Ljava/lang/Class;
    .line 25: const/4 v5, 0
    .line 26: aput-object v8, v4, v5
    .line 28: const/4 v5, 1
    .line 29: const-class v6, Landroidx/versionedparcelable/VersionedParcel;
    .line 31: aput-object v6, v4, v5
    .line 33: const-string v5, "write"
    .line 35: invoke-virtual {v1, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 38: move-result-object v0
    .line 39: iget-object v4, v7, Landroidx/versionedparcelable/VersionedParcel;->mWriteCache:Landroidx/collection/ArrayMap;
    .line 41: invoke-virtual {v8}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 44: move-result-object v5
    .line 45: invoke-virtual {v4, v5, v0}, Landroidx/collection/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 48: return-object v0
.end method

# direct methods
.method private readCollection(Ljava/util/Collection;)Ljava/util/Collection;
    .registers 5

    .line 0: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: const/4 v1, 0
    .line 5: if-gez v0, :cond_8
    .line 7: return-object v1
    .line 8: if-eqz v0, :cond_81
    .line 10: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 13: move-result v2
    .line 14: if-gez v0, :cond_17
    .line 16: return-object v1
    .line 17: packed-switch v2, :data_82
    .line 20: goto :goto_81
    .line 21: if-lez v0, :cond_81
    .line 23: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readStrongBinder()Landroid/os/IBinder;
    .line 26: move-result-object v1
    .line 27: invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 30: add-int/lit8 v0, v0, -1
    .line 32: goto :goto_21
    .line 33: if-lez v0, :cond_81
    .line 35: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 38: move-result-object v1
    .line 39: invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 42: add-int/lit8 v0, v0, -1
    .line 44: goto :goto_33
    .line 45: if-lez v0, :cond_81
    .line 47: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readSerializable()Ljava/io/Serializable;
    .line 50: move-result-object v1
    .line 51: invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 54: add-int/lit8 v0, v0, -1
    .line 56: goto :goto_45
    .line 57: if-lez v0, :cond_81
    .line 59: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readParcelable()Landroid/os/Parcelable;
    .line 62: move-result-object v1
    .line 63: invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 66: add-int/lit8 v0, v0, -1
    .line 68: goto :goto_57
    .line 69: if-lez v0, :cond_81
    .line 71: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .line 74: move-result-object v1
    .line 75: invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    .line 78: add-int/lit8 v0, v0, -1
    .line 80: goto :goto_69
    .line 81: return-object v4
    .line 82: nop
    .line 83: move-wide/from16 v0, v1
    .line 85: nop
    .line 86: if-lt v0, v0, :cond_86
    .line 88: goto :goto_88
    .line 89: nop
    .line 90: const-class v0, B
    .line 92: return-wide v0
    .line 93: nop
    .line 94: move-wide v0, v0
    .line 95: nop
.end method

# direct methods
.method private readException(ILjava/lang/String;)Ljava/lang/Exception;
    .registers 4

    .line 0: invoke-direct {v1, v2, v3}, Landroidx/versionedparcelable/VersionedParcel;->createException(ILjava/lang/String;)Ljava/lang/Exception;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method

# direct methods
.method private readExceptionCode()I
    .registers 2

    .line 0: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: return v0
.end method

# direct methods
.method private writeCollection(Ljava/util/Collection;)V
    .registers 7

    .line 0: if-nez v6, :cond_7
    .line 2: const/4 v0, -1
    .line 3: invoke-virtual {v5, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: return-void
    .line 7: invoke-interface {v6}, Ljava/util/Collection;->size()I
    .line 10: move-result v0
    .line 11: invoke-virtual {v5, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 14: if-lez v0, :cond_197
    .line 16: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 19: move-result-object v1
    .line 20: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 23: move-result-object v1
    .line 24: invoke-direct {v5, v1}, Landroidx/versionedparcelable/VersionedParcel;->getType(Ljava/lang/Object;)I
    .line 27: move-result v1
    .line 28: invoke-virtual {v5, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 31: packed-switch v1, :data_198
    .line 34: goto/16 :goto_197
    .line 36: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 39: move-result-object v2
    .line 40: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 43: move-result v3
    .line 44: if-eqz v3, :cond_197
    .line 46: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 49: move-result-object v3
    .line 50: move-object v4, v3
    .line 51: check-cast v4, Ljava/lang/Float;
    .line 53: invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F
    .line 56: move-result v4
    .line 57: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeFloat(F)V
    .line 60: goto :goto_40
    .line 61: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 64: move-result-object v2
    .line 65: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 68: move-result v3
    .line 69: if-eqz v3, :cond_86
    .line 71: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 74: move-result-object v3
    .line 75: move-object v4, v3
    .line 76: check-cast v4, Ljava/lang/Integer;
    .line 78: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    .line 81: move-result v4
    .line 82: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 85: goto :goto_65
    .line 86: goto/16 :goto_197
    .line 88: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 91: move-result-object v2
    .line 92: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 95: move-result v3
    .line 96: if-eqz v3, :cond_109
    .line 98: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 101: move-result-object v3
    .line 102: move-object v4, v3
    .line 103: check-cast v4, Landroid/os/IBinder;
    .line 105: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeStrongBinder(Landroid/os/IBinder;)V
    .line 108: goto :goto_92
    .line 109: goto :goto_197
    .line 110: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 113: move-result-object v2
    .line 114: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 117: move-result v3
    .line 118: if-eqz v3, :cond_131
    .line 120: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 123: move-result-object v3
    .line 124: move-object v4, v3
    .line 125: check-cast v4, Ljava/lang/String;
    .line 127: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 130: goto :goto_114
    .line 131: goto :goto_197
    .line 132: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 135: move-result-object v2
    .line 136: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 139: move-result v3
    .line 140: if-eqz v3, :cond_153
    .line 142: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 145: move-result-object v3
    .line 146: move-object v4, v3
    .line 147: check-cast v4, Ljava/io/Serializable;
    .line 149: invoke-direct {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeSerializable(Ljava/io/Serializable;)V
    .line 152: goto :goto_136
    .line 153: goto :goto_197
    .line 154: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 157: move-result-object v2
    .line 158: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 161: move-result v3
    .line 162: if-eqz v3, :cond_175
    .line 164: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 167: move-result-object v3
    .line 168: move-object v4, v3
    .line 169: check-cast v4, Landroid/os/Parcelable;
    .line 171: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeParcelable(Landroid/os/Parcelable;)V
    .line 174: goto :goto_158
    .line 175: goto :goto_197
    .line 176: invoke-interface {v6}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 179: move-result-object v2
    .line 180: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    .line 183: move-result v3
    .line 184: if-eqz v3, :cond_197
    .line 186: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 189: move-result-object v3
    .line 190: move-object v4, v3
    .line 191: check-cast v4, Landroidx/versionedparcelable/VersionedParcelable;
    .line 193: invoke-virtual {v5, v4}, Landroidx/versionedparcelable/VersionedParcel;->writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 196: goto :goto_180
    .line 197: return-void
    .line 198: nop
    .line 199: move-object/from16 v0, v1
    .line 201: nop
    .line 202: sub-int v0, v0, v0
    .line 204: neg-int v0, v0
    .line 205: nop
    .line 206: sget-char v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 208: aput-byte v0, v0, v0
    .line 210: if-nez v0, :cond_210
    .line 212: move/16 v0, v30
    .line 215: nop
    .line 216: move-wide/from16 v0, v0
.end method

# direct methods
.method private writeCollection(Ljava/util/Collection;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-direct {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeCollection(Ljava/util/Collection;)V
    .line 6: return-void
.end method

# direct methods
.method private writeSerializable(Ljava/io/Serializable;)V
    .registers 8

    .line 0: if-nez v7, :cond_7
    .line 2: const/4 v0, 0
    .line 3: invoke-virtual {v6, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 6: return-void
    .line 7: invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 10: move-result-object v0
    .line 11: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 14: move-result-object v0
    .line 15: invoke-virtual {v6, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 18: new-instance v1, Ljava/io/ByteArrayOutputStream;
    .line 20: invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    .line 23: new-instance v2, Ljava/io/ObjectOutputStream;
    .line 25: invoke-direct {v2, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    .line 28: invoke-virtual {v2, v7}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V
    .line 31: invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V
    .line 34: invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    .line 37: move-result-object v3
    .line 38: invoke-virtual {v6, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeByteArray([B)V
    .line 41: nop
    .line 42: return-void
    .line 43: move-exception v2
    .line 44: new-instance v3, Ljava/lang/RuntimeException;
    .line 46: new-instance v4, Ljava/lang/StringBuilder;
    .line 48: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 51: const-string v5, "VersionedParcelable encountered IOException writing serializable object (name = "
    .line 53: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 56: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 59: const-string v5, ")"
    .line 61: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 64: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 67: move-result-object v4
    .line 68: invoke-direct {v3, v4, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 71: throw v3
.end method

# direct methods
.method private writeVersionedParcelableCreator(Landroidx/versionedparcelable/VersionedParcelable;)V
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 4: move-result-object v1
    .line 5: invoke-direct {v5, v1}, Landroidx/versionedparcelable/VersionedParcel;->findParcelClass(Ljava/lang/Class;)Ljava/lang/Class;
    .line 8: move-result-object v1
    .line 9: move-object v0, v1
    .line 10: nop
    .line 11: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    .line 14: move-result-object v1
    .line 15: invoke-virtual {v5, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 18: return-void
    .line 19: move-exception v1
    .line 20: new-instance v2, Ljava/lang/RuntimeException;
    .line 22: new-instance v3, Ljava/lang/StringBuilder;
    .line 24: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 27: invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 30: move-result-object v4
    .line 31: invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    .line 34: move-result-object v4
    .line 35: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 38: const-string v4, " does not have a Parcelizer"
    .line 40: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 43: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 46: move-result-object v3
    .line 47: invoke-direct {v2, v3, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 50: throw v2
.end method

# virtual methods
.method protected abstract closeField()V
.end method

# virtual methods
.method protected abstract createSubParcel()Landroidx/versionedparcelable/VersionedParcel;
.end method

# virtual methods
.method public isStream()Z
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return v0
.end method

# virtual methods
.method protected readArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 6

    .line 0: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: const/4 v1, 0
    .line 5: if-gez v0, :cond_8
    .line 7: return-object v1
    .line 8: new-instance v2, Ljava/util/ArrayList;
    .line 10: invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V
    .line 13: if-eqz v0, :cond_86
    .line 15: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 18: move-result v3
    .line 19: if-gez v0, :cond_22
    .line 21: return-object v1
    .line 22: packed-switch v3, :data_92
    .line 25: goto :goto_86
    .line 26: if-lez v0, :cond_86
    .line 28: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readStrongBinder()Landroid/os/IBinder;
    .line 31: move-result-object v1
    .line 32: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 35: add-int/lit8 v0, v0, -1
    .line 37: goto :goto_26
    .line 38: if-lez v0, :cond_86
    .line 40: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 43: move-result-object v1
    .line 44: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 47: add-int/lit8 v0, v0, -1
    .line 49: goto :goto_38
    .line 50: if-lez v0, :cond_86
    .line 52: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readSerializable()Ljava/io/Serializable;
    .line 55: move-result-object v1
    .line 56: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 59: add-int/lit8 v0, v0, -1
    .line 61: goto :goto_50
    .line 62: if-lez v0, :cond_86
    .line 64: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readParcelable()Landroid/os/Parcelable;
    .line 67: move-result-object v1
    .line 68: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 71: add-int/lit8 v0, v0, -1
    .line 73: goto :goto_62
    .line 74: if-lez v0, :cond_86
    .line 76: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .line 79: move-result-object v1
    .line 80: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 83: add-int/lit8 v0, v0, -1
    .line 85: goto :goto_74
    .line 86: invoke-virtual {v2, v5}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 89: move-result-object v1
    .line 90: return-object v1
    .line 91: nop
    .line 92: nop
    .line 93: move-wide/from16 v0, v1
    .line 95: nop
    .line 96: if-lt v0, v0, :cond_96
    .line 98: goto :goto_98
    .line 99: nop
    .line 100: const-class v0, B
    .line 102: return-wide v0
    .line 103: nop
    .line 104: move-wide v0, v0
    .line 105: nop
.end method

# virtual methods
.method public readArray([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->readArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected abstract readBoolean()Z
.end method

# virtual methods
.method public readBoolean(ZI)Z
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readBoolean()Z
    .line 10: move-result v0
    .line 11: return v0
.end method

# virtual methods
.method protected readBooleanArray()[Z
    .registers 5

    .line 0: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-array v1, v0, [Z
    .line 10: const/4 v2, 0
    .line 11: if-ge v2, v0, :cond_27
    .line 13: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 16: move-result v3
    .line 17: if-eqz v3, :cond_21
    .line 19: const/4 v3, 1
    .line 20: goto :goto_22
    .line 21: const/4 v3, 0
    .line 22: aput-boolean v3, v1, v2
    .line 24: add-int/lit8 v2, v2, 1
    .line 26: goto :goto_11
    .line 27: return-object v1
.end method

# virtual methods
.method public readBooleanArray([ZI)[Z
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readBooleanArray()[Z
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected abstract readBundle()Landroid/os/Bundle;
.end method

# virtual methods
.method public readBundle(Landroid/os/Bundle;I)Landroid/os/Bundle;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readBundle()Landroid/os/Bundle;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public readByte(BI)B
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 10: move-result v0
    .line 11: and-int/lit16 v0, v0, 255
    .line 13: int-to-byte v0, v0
    .line 14: return v0
.end method

# virtual methods
.method protected abstract readByteArray()[B
.end method

# virtual methods
.method public readByteArray([BI)[B
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readByteArray()[B
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public readCharArray([CI)[C
    .registers 7

    .line 0: invoke-virtual {v4, v6}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v5
    .line 7: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 10: move-result v0
    .line 11: if-gez v0, :cond_15
    .line 13: const/4 v1, 0
    .line 14: return-object v1
    .line 15: new-array v1, v0, [C
    .line 17: const/4 v2, 0
    .line 18: if-ge v2, v0, :cond_30
    .line 20: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 23: move-result v3
    .line 24: int-to-char v3, v3
    .line 25: aput-char v3, v1, v2
    .line 27: add-int/lit8 v2, v2, 1
    .line 29: goto :goto_18
    .line 30: return-object v1
.end method

# virtual methods
.method protected abstract readCharSequence()Ljava/lang/CharSequence;
.end method

# virtual methods
.method public readCharSequence(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readCharSequence()Ljava/lang/CharSequence;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected abstract readDouble()D
.end method

# virtual methods
.method public readDouble(DI)D
    .registers 6

    .line 0: invoke-virtual {v2, v5}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-wide v3
    .line 7: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcel;->readDouble()D
    .line 10: move-result-wide v0
    .line 11: return-wide v0
.end method

# virtual methods
.method protected readDoubleArray()[D
    .registers 6

    .line 0: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-array v1, v0, [D
    .line 10: const/4 v2, 0
    .line 11: if-ge v2, v0, :cond_22
    .line 13: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readDouble()D
    .line 16: move-result-wide v3
    .line 17: aput-wide v3, v1, v2
    .line 19: add-int/lit8 v2, v2, 1
    .line 21: goto :goto_11
    .line 22: return-object v1
.end method

# virtual methods
.method public readDoubleArray([DI)[D
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readDoubleArray()[D
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public readException(Ljava/lang/Exception;I)Ljava/lang/Exception;
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v4
    .line 7: invoke-direct {v3}, Landroidx/versionedparcelable/VersionedParcel;->readExceptionCode()I
    .line 10: move-result v0
    .line 11: if-eqz v0, :cond_22
    .line 13: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 16: move-result-object v1
    .line 17: invoke-direct {v3, v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->readException(ILjava/lang/String;)Ljava/lang/Exception;
    .line 20: move-result-object v2
    .line 21: return-object v2
    .line 22: return-object v4
.end method

# virtual methods
.method protected abstract readField(I)Z
.end method

# virtual methods
.method protected abstract readFloat()F
.end method

# virtual methods
.method public readFloat(FI)F
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readFloat()F
    .line 10: move-result v0
    .line 11: return v0
.end method

# virtual methods
.method protected readFloatArray()[F
    .registers 5

    .line 0: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-array v1, v0, [F
    .line 10: const/4 v2, 0
    .line 11: if-ge v2, v0, :cond_22
    .line 13: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readFloat()F
    .line 16: move-result v3
    .line 17: aput v3, v1, v2
    .line 19: add-int/lit8 v2, v2, 1
    .line 21: goto :goto_11
    .line 22: return-object v1
.end method

# virtual methods
.method public readFloatArray([FI)[F
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readFloatArray()[F
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected readFromParcel(Ljava/lang/String;Landroidx/versionedparcelable/VersionedParcel;)Landroidx/versionedparcelable/VersionedParcelable;
    .registers 7

    .line 0: invoke-direct {v4, v5}, Landroidx/versionedparcelable/VersionedParcel;->getReadMethod(Ljava/lang/String;)Ljava/lang/reflect/Method;
    .line 3: move-result-object v0
    .line 4: const/4 v1, 0
    .line 5: const/4 v2, 1
    .line 6: new-array v2, v2, [Ljava/lang/Object;
    .line 8: const/4 v3, 0
    .line 9: aput-object v6, v2, v3
    .line 11: invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 14: move-result-object v1
    .line 15: check-cast v1, Landroidx/versionedparcelable/VersionedParcelable;
    .line 17: return-object v1
    .line 18: move-exception v0
    .line 19: new-instance v1, Ljava/lang/RuntimeException;
    .line 21: const-string v2, "VersionedParcel encountered ClassNotFoundException"
    .line 23: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 26: throw v1
    .line 27: move-exception v0
    .line 28: new-instance v1, Ljava/lang/RuntimeException;
    .line 30: const-string v2, "VersionedParcel encountered NoSuchMethodException"
    .line 32: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 35: throw v1
    .line 36: move-exception v0
    .line 37: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 40: move-result-object v1
    .line 41: instance-of v1, v1, Ljava/lang/RuntimeException;
    .line 43: if-eqz v1, :cond_52
    .line 45: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 48: move-result-object v1
    .line 49: check-cast v1, Ljava/lang/RuntimeException;
    .line 51: throw v1
    .line 52: new-instance v1, Ljava/lang/RuntimeException;
    .line 54: const-string v2, "VersionedParcel encountered InvocationTargetException"
    .line 56: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 59: throw v1
    .line 60: move-exception v0
    .line 61: new-instance v1, Ljava/lang/RuntimeException;
    .line 63: const-string v2, "VersionedParcel encountered IllegalAccessException"
    .line 65: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 68: throw v1
.end method

# virtual methods
.method protected abstract readInt()I
.end method

# virtual methods
.method public readInt(II)I
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 10: move-result v0
    .line 11: return v0
.end method

# virtual methods
.method protected readIntArray()[I
    .registers 5

    .line 0: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-array v1, v0, [I
    .line 10: const/4 v2, 0
    .line 11: if-ge v2, v0, :cond_22
    .line 13: invoke-virtual {v4}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 16: move-result v3
    .line 17: aput v3, v1, v2
    .line 19: add-int/lit8 v2, v2, 1
    .line 21: goto :goto_11
    .line 22: return-object v1
.end method

# virtual methods
.method public readIntArray([II)[I
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readIntArray()[I
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public readList(Ljava/util/List;I)Ljava/util/List;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: new-instance v0, Ljava/util/ArrayList;
    .line 9: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 12: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->readCollection(Ljava/util/Collection;)Ljava/util/Collection;
    .line 15: move-result-object v0
    .line 16: check-cast v0, Ljava/util/List;
    .line 18: return-object v0
.end method

# virtual methods
.method protected abstract readLong()J
.end method

# virtual methods
.method public readLong(JI)J
    .registers 6

    .line 0: invoke-virtual {v2, v5}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-wide v3
    .line 7: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcel;->readLong()J
    .line 10: move-result-wide v0
    .line 11: return-wide v0
.end method

# virtual methods
.method protected readLongArray()[J
    .registers 6

    .line 0: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-array v1, v0, [J
    .line 10: const/4 v2, 0
    .line 11: if-ge v2, v0, :cond_22
    .line 13: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readLong()J
    .line 16: move-result-wide v3
    .line 17: aput-wide v3, v1, v2
    .line 19: add-int/lit8 v2, v2, 1
    .line 21: goto :goto_11
    .line 22: return-object v1
.end method

# virtual methods
.method public readLongArray([JI)[J
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readLongArray()[J
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method public readMap(Ljava/util/Map;I)Ljava/util/Map;
    .registers 10

    .line 0: invoke-virtual {v7, v9}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v8
    .line 7: invoke-virtual {v7}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 10: move-result v0
    .line 11: if-gez v0, :cond_15
    .line 13: const/4 v1, 0
    .line 14: return-object v1
    .line 15: new-instance v1, Landroidx/collection/ArrayMap;
    .line 17: invoke-direct {v1}, Landroidx/collection/ArrayMap;-><init>()V
    .line 20: if-nez v0, :cond_23
    .line 22: return-object v1
    .line 23: new-instance v2, Ljava/util/ArrayList;
    .line 25: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 28: new-instance v3, Ljava/util/ArrayList;
    .line 30: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    .line 33: invoke-direct {v7, v2}, Landroidx/versionedparcelable/VersionedParcel;->readCollection(Ljava/util/Collection;)Ljava/util/Collection;
    .line 36: invoke-direct {v7, v3}, Landroidx/versionedparcelable/VersionedParcel;->readCollection(Ljava/util/Collection;)Ljava/util/Collection;
    .line 39: const/4 v4, 0
    .line 40: if-ge v4, v0, :cond_56
    .line 42: invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 45: move-result-object v5
    .line 46: invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    .line 49: move-result-object v6
    .line 50: invoke-interface {v1, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 53: add-int/lit8 v4, v4, 1
    .line 55: goto :goto_40
    .line 56: return-object v1
.end method

# virtual methods
.method protected abstract readParcelable()Landroid/os/Parcelable;
.end method

# virtual methods
.method public readParcelable(Landroid/os/Parcelable;I)Landroid/os/Parcelable;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readParcelable()Landroid/os/Parcelable;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected readSerializable()Ljava/io/Serializable;
    .registers 9

    .line 0: const-string v0, ")"
    .line 2: invoke-virtual {v8}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 5: move-result-object v1
    .line 6: if-nez v1, :cond_10
    .line 8: const/4 v0, 0
    .line 9: return-object v0
    .line 10: invoke-virtual {v8}, Landroidx/versionedparcelable/VersionedParcel;->readByteArray()[B
    .line 13: move-result-object v2
    .line 14: new-instance v3, Ljava/io/ByteArrayInputStream;
    .line 16: invoke-direct {v3, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    .line 19: new-instance v4, Landroidx/versionedparcelable/VersionedParcel$1;
    .line 21: invoke-direct {v4, v8, v3}, Landroidx/versionedparcelable/VersionedParcel$1;-><init>(Landroidx/versionedparcelable/VersionedParcel;Ljava/io/InputStream;)V
    .line 24: invoke-virtual {v4}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;
    .line 27: move-result-object v5
    .line 28: check-cast v5, Ljava/io/Serializable;
    .line 30: return-object v5
    .line 31: move-exception v4
    .line 32: new-instance v5, Ljava/lang/RuntimeException;
    .line 34: new-instance v6, Ljava/lang/StringBuilder;
    .line 36: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    .line 39: const-string v7, "VersionedParcelable encountered ClassNotFoundException reading a Serializable object (name = "
    .line 41: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 44: invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 47: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 50: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 53: move-result-object v0
    .line 54: invoke-direct {v5, v0, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 57: throw v5
    .line 58: move-exception v4
    .line 59: new-instance v5, Ljava/lang/RuntimeException;
    .line 61: new-instance v6, Ljava/lang/StringBuilder;
    .line 63: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    .line 66: const-string v7, "VersionedParcelable encountered IOException reading a Serializable object (name = "
    .line 68: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 71: invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 74: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 77: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 80: move-result-object v0
    .line 81: invoke-direct {v5, v0, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 84: throw v5
.end method

# virtual methods
.method public readSet(Ljava/util/Set;I)Ljava/util/Set;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: new-instance v0, Landroidx/collection/ArraySet;
    .line 9: invoke-direct {v0}, Landroidx/collection/ArraySet;-><init>()V
    .line 12: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->readCollection(Ljava/util/Collection;)Ljava/util/Collection;
    .line 15: move-result-object v0
    .line 16: check-cast v0, Ljava/util/Set;
    .line 18: return-object v0
.end method

# virtual methods
.method public readSize(Landroid/util/Size;I)Landroid/util/Size;
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v4
    .line 7: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readBoolean()Z
    .line 10: move-result v0
    .line 11: if-eqz v0, :cond_27
    .line 13: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 16: move-result v0
    .line 17: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 20: move-result v1
    .line 21: new-instance v2, Landroid/util/Size;
    .line 23: invoke-direct {v2, v0, v1}, Landroid/util/Size;-><init>(II)V
    .line 26: return-object v2
    .line 27: const/4 v0, 0
    .line 28: return-object v0
.end method

# virtual methods
.method public readSizeF(Landroid/util/SizeF;I)Landroid/util/SizeF;
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v4
    .line 7: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readBoolean()Z
    .line 10: move-result v0
    .line 11: if-eqz v0, :cond_27
    .line 13: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readFloat()F
    .line 16: move-result v0
    .line 17: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->readFloat()F
    .line 20: move-result v1
    .line 21: new-instance v2, Landroid/util/SizeF;
    .line 23: invoke-direct {v2, v0, v1}, Landroid/util/SizeF;-><init>(FF)V
    .line 26: return-object v2
    .line 27: const/4 v0, 0
    .line 28: return-object v0
.end method

# virtual methods
.method public readSparseBooleanArray(Landroid/util/SparseBooleanArray;I)Landroid/util/SparseBooleanArray;
    .registers 8

    .line 0: invoke-virtual {v5, v7}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v6
    .line 7: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 10: move-result v0
    .line 11: if-gez v0, :cond_15
    .line 13: const/4 v1, 0
    .line 14: return-object v1
    .line 15: new-instance v1, Landroid/util/SparseBooleanArray;
    .line 17: invoke-direct {v1, v0}, Landroid/util/SparseBooleanArray;-><init>(I)V
    .line 20: const/4 v2, 0
    .line 21: if-ge v2, v0, :cond_37
    .line 23: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readInt()I
    .line 26: move-result v3
    .line 27: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcel;->readBoolean()Z
    .line 30: move-result v4
    .line 31: invoke-virtual {v1, v3, v4}, Landroid/util/SparseBooleanArray;->put(IZ)V
    .line 34: add-int/lit8 v2, v2, 1
    .line 36: goto :goto_21
    .line 37: return-object v1
.end method

# virtual methods
.method protected abstract readString()Ljava/lang/String;
.end method

# virtual methods
.method public readString(Ljava/lang/String;I)Ljava/lang/String;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected abstract readStrongBinder()Landroid/os/IBinder;
.end method

# virtual methods
.method public readStrongBinder(Landroid/os/IBinder;I)Landroid/os/IBinder;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readStrongBinder()Landroid/os/IBinder;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .registers 3

    .line 0: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcel;->readString()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: if-nez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcel;->createSubParcel()Landroidx/versionedparcelable/VersionedParcel;
    .line 11: move-result-object v1
    .line 12: invoke-virtual {v2, v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->readFromParcel(Ljava/lang/String;Landroidx/versionedparcelable/VersionedParcel;)Landroidx/versionedparcelable/VersionedParcelable;
    .line 15: move-result-object v1
    .line 16: return-object v1
.end method

# virtual methods
.method public readVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;I)Landroidx/versionedparcelable/VersionedParcelable;
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->readField(I)Z
    .line 3: move-result v0
    .line 4: if-nez v0, :cond_7
    .line 6: return-object v2
    .line 7: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->readVersionedParcelable()Landroidx/versionedparcelable/VersionedParcelable;
    .line 10: move-result-object v0
    .line 11: return-object v0
.end method

# virtual methods
.method protected abstract setOutputField(I)V
.end method

# virtual methods
.method public setSerializationFlags(ZZ)V
    .registers 3

    .line 0: return-void
.end method

# virtual methods
.method protected writeArray([Ljava/lang/Object;)V
    .registers 6

    .line 0: if-nez v5, :cond_7
    .line 2: const/4 v0, -1
    .line 3: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: return-void
    .line 7: array-length v0, v5
    .line 8: const/4 v1, 0
    .line 9: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 12: if-lez v0, :cond_88
    .line 14: const/4 v2, 0
    .line 15: aget-object v2, v5, v2
    .line 17: invoke-direct {v4, v2}, Landroidx/versionedparcelable/VersionedParcel;->getType(Ljava/lang/Object;)I
    .line 20: move-result v2
    .line 21: invoke-virtual {v4, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 24: packed-switch v2, :data_90
    .line 27: goto :goto_88
    .line 28: if-ge v1, v0, :cond_88
    .line 30: aget-object v3, v5, v1
    .line 32: check-cast v3, Landroid/os/IBinder;
    .line 34: invoke-virtual {v4, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeStrongBinder(Landroid/os/IBinder;)V
    .line 37: add-int/lit8 v1, v1, 1
    .line 39: goto :goto_28
    .line 40: if-ge v1, v0, :cond_88
    .line 42: aget-object v3, v5, v1
    .line 44: check-cast v3, Ljava/lang/String;
    .line 46: invoke-virtual {v4, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 49: add-int/lit8 v1, v1, 1
    .line 51: goto :goto_40
    .line 52: if-ge v1, v0, :cond_88
    .line 54: aget-object v3, v5, v1
    .line 56: check-cast v3, Ljava/io/Serializable;
    .line 58: invoke-direct {v4, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeSerializable(Ljava/io/Serializable;)V
    .line 61: add-int/lit8 v1, v1, 1
    .line 63: goto :goto_52
    .line 64: if-ge v1, v0, :cond_88
    .line 66: aget-object v3, v5, v1
    .line 68: check-cast v3, Landroid/os/Parcelable;
    .line 70: invoke-virtual {v4, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeParcelable(Landroid/os/Parcelable;)V
    .line 73: add-int/lit8 v1, v1, 1
    .line 75: goto :goto_64
    .line 76: if-ge v1, v0, :cond_88
    .line 78: aget-object v3, v5, v1
    .line 80: check-cast v3, Landroidx/versionedparcelable/VersionedParcelable;
    .line 82: invoke-virtual {v4, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 85: add-int/lit8 v1, v1, 1
    .line 87: goto :goto_76
    .line 88: return-void
    .line 89: nop
    .line 90: nop
    .line 91: move-wide/from16 v0, v1
    .line 93: nop
    .line 94: if-lt v0, v0, :cond_94
    .line 96: goto :goto_96
    .line 97: nop
    .line 98: const-class v0, B
    .line 100: return-wide v0
    .line 101: nop
    .line 102: move-wide v0, v0
    .line 103: nop
.end method

# virtual methods
.method public writeArray([Ljava/lang/Object;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeArray([Ljava/lang/Object;)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeBoolean(Z)V
.end method

# virtual methods
.method public writeBoolean(ZI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeBoolean(Z)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeBooleanArray([Z)V
    .registers 5

    .line 0: if-eqz v4, :cond_18
    .line 2: array-length v0, v4
    .line 3: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: const/4 v1, 0
    .line 7: if-ge v1, v0, :cond_17
    .line 9: aget-boolean v2, v4, v1
    .line 11: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 14: add-int/lit8 v1, v1, 1
    .line 16: goto :goto_7
    .line 17: goto :goto_22
    .line 18: const/4 v0, -1
    .line 19: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 22: return-void
.end method

# virtual methods
.method public writeBooleanArray([ZI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeBooleanArray([Z)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeBundle(Landroid/os/Bundle;)V
.end method

# virtual methods
.method public writeBundle(Landroid/os/Bundle;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeBundle(Landroid/os/Bundle;)V
    .line 6: return-void
.end method

# virtual methods
.method public writeByte(BI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeByteArray([B)V
.end method

# virtual methods
.method public writeByteArray([BI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeByteArray([B)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeByteArray([BII)V
.end method

# virtual methods
.method public writeByteArray([BIII)V
    .registers 5

    .line 0: invoke-virtual {v0, v4}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1, v2, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeByteArray([BII)V
    .line 6: return-void
.end method

# virtual methods
.method public writeCharArray([CI)V
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-eqz v4, :cond_21
    .line 5: array-length v0, v4
    .line 6: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 9: const/4 v1, 0
    .line 10: if-ge v1, v0, :cond_20
    .line 12: aget-char v2, v4, v1
    .line 14: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 17: add-int/lit8 v1, v1, 1
    .line 19: goto :goto_10
    .line 20: goto :goto_25
    .line 21: const/4 v0, -1
    .line 22: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 25: return-void
.end method

# virtual methods
.method protected abstract writeCharSequence(Ljava/lang/CharSequence;)V
.end method

# virtual methods
.method public writeCharSequence(Ljava/lang/CharSequence;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeCharSequence(Ljava/lang/CharSequence;)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeDouble(D)V
.end method

# virtual methods
.method public writeDouble(DI)V
    .registers 4

    .line 0: invoke-virtual {v0, v3}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeDouble(D)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeDoubleArray([D)V
    .registers 6

    .line 0: if-eqz v5, :cond_18
    .line 2: array-length v0, v5
    .line 3: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: const/4 v1, 0
    .line 7: if-ge v1, v0, :cond_17
    .line 9: aget-wide v2, v5, v1
    .line 11: invoke-virtual {v4, v2, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeDouble(D)V
    .line 14: add-int/lit8 v1, v1, 1
    .line 16: goto :goto_7
    .line 17: goto :goto_22
    .line 18: const/4 v0, -1
    .line 19: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 22: return-void
.end method

# virtual methods
.method public writeDoubleArray([DI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeDoubleArray([D)V
    .line 6: return-void
.end method

# virtual methods
.method public writeException(Ljava/lang/Exception;I)V
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-nez v4, :cond_9
    .line 5: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcel;->writeNoException()V
    .line 8: return-void
    .line 9: const/4 v0, 0
    .line 10: instance-of v1, v4, Landroid/os/Parcelable;
    .line 12: if-eqz v1, :cond_33
    .line 14: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 17: move-result-object v1
    .line 18: invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 21: move-result-object v1
    .line 22: const-class v2, Landroid/os/Parcelable;
    .line 24: invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 27: move-result-object v2
    .line 28: if-ne v1, v2, :cond_33
    .line 30: const/16 v0, -9
    .line 32: goto :goto_74
    .line 33: instance-of v1, v4, Ljava/lang/SecurityException;
    .line 35: if-eqz v1, :cond_39
    .line 37: const/4 v0, -1
    .line 38: goto :goto_74
    .line 39: instance-of v1, v4, Landroid/os/BadParcelableException;
    .line 41: if-eqz v1, :cond_45
    .line 43: const/4 v0, -2
    .line 44: goto :goto_74
    .line 45: instance-of v1, v4, Ljava/lang/IllegalArgumentException;
    .line 47: if-eqz v1, :cond_51
    .line 49: const/4 v0, -3
    .line 50: goto :goto_74
    .line 51: instance-of v1, v4, Ljava/lang/NullPointerException;
    .line 53: if-eqz v1, :cond_57
    .line 55: const/4 v0, -4
    .line 56: goto :goto_74
    .line 57: instance-of v1, v4, Ljava/lang/IllegalStateException;
    .line 59: if-eqz v1, :cond_63
    .line 61: const/4 v0, -5
    .line 62: goto :goto_74
    .line 63: instance-of v1, v4, Landroid/os/NetworkOnMainThreadException;
    .line 65: if-eqz v1, :cond_69
    .line 67: const/4 v0, -6
    .line 68: goto :goto_74
    .line 69: instance-of v1, v4, Ljava/lang/UnsupportedOperationException;
    .line 71: if-eqz v1, :cond_74
    .line 73: const/4 v0, -7
    .line 74: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 77: if-nez v0, :cond_93
    .line 79: instance-of v1, v4, Ljava/lang/RuntimeException;
    .line 81: if-eqz v1, :cond_87
    .line 83: move-object v1, v4
    .line 84: check-cast v1, Ljava/lang/RuntimeException;
    .line 86: throw v1
    .line 87: new-instance v1, Ljava/lang/RuntimeException;
    .line 89: invoke-direct {v1, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 92: throw v1
    .line 93: invoke-virtual {v4}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;
    .line 96: move-result-object v1
    .line 97: invoke-virtual {v3, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 100: packed-switch v0, :data_112
    .line 103: goto :goto_110
    .line 104: move-object v1, v4
    .line 105: check-cast v1, Landroid/os/Parcelable;
    .line 107: invoke-virtual {v3, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeParcelable(Landroid/os/Parcelable;)V
    .line 110: return-void
    .line 111: nop
    .line 112: nop
    .line 113: move v0, v0
    .line 114: 0xf7 ; unknown opcode
    .line 115: 0xff ; unknown opcode
    .line 116: move-wide v0, v0
    .line 117: nop
.end method

# virtual methods
.method protected abstract writeFloat(F)V
.end method

# virtual methods
.method public writeFloat(FI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeFloat(F)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeFloatArray([F)V
    .registers 5

    .line 0: if-eqz v4, :cond_18
    .line 2: array-length v0, v4
    .line 3: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: const/4 v1, 0
    .line 7: if-ge v1, v0, :cond_17
    .line 9: aget v2, v4, v1
    .line 11: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeFloat(F)V
    .line 14: add-int/lit8 v1, v1, 1
    .line 16: goto :goto_7
    .line 17: goto :goto_22
    .line 18: const/4 v0, -1
    .line 19: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 22: return-void
.end method

# virtual methods
.method public writeFloatArray([FI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeFloatArray([F)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeInt(I)V
.end method

# virtual methods
.method public writeInt(II)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeIntArray([I)V
    .registers 5

    .line 0: if-eqz v4, :cond_18
    .line 2: array-length v0, v4
    .line 3: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: const/4 v1, 0
    .line 7: if-ge v1, v0, :cond_17
    .line 9: aget v2, v4, v1
    .line 11: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 14: add-int/lit8 v1, v1, 1
    .line 16: goto :goto_7
    .line 17: goto :goto_22
    .line 18: const/4 v0, -1
    .line 19: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 22: return-void
.end method

# virtual methods
.method public writeIntArray([II)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeIntArray([I)V
    .line 6: return-void
.end method

# virtual methods
.method public writeList(Ljava/util/List;I)V
    .registers 3

    .line 0: invoke-direct {v0, v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeCollection(Ljava/util/Collection;I)V
    .line 3: return-void
.end method

# virtual methods
.method protected abstract writeLong(J)V
.end method

# virtual methods
.method public writeLong(JI)V
    .registers 4

    .line 0: invoke-virtual {v0, v3}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeLong(J)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeLongArray([J)V
    .registers 6

    .line 0: if-eqz v5, :cond_18
    .line 2: array-length v0, v5
    .line 3: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 6: const/4 v1, 0
    .line 7: if-ge v1, v0, :cond_17
    .line 9: aget-wide v2, v5, v1
    .line 11: invoke-virtual {v4, v2, v3}, Landroidx/versionedparcelable/VersionedParcel;->writeLong(J)V
    .line 14: add-int/lit8 v1, v1, 1
    .line 16: goto :goto_7
    .line 17: goto :goto_22
    .line 18: const/4 v0, -1
    .line 19: invoke-virtual {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 22: return-void
.end method

# virtual methods
.method public writeLongArray([JI)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeLongArray([J)V
    .line 6: return-void
.end method

# virtual methods
.method public writeMap(Ljava/util/Map;I)V
    .registers 9

    .line 0: invoke-virtual {v6, v8}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-nez v7, :cond_10
    .line 5: const/4 v0, -1
    .line 6: invoke-virtual {v6, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 9: return-void
    .line 10: invoke-interface {v7}, Ljava/util/Map;->size()I
    .line 13: move-result v0
    .line 14: invoke-virtual {v6, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 17: if-nez v0, :cond_20
    .line 19: return-void
    .line 20: new-instance v1, Ljava/util/ArrayList;
    .line 22: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    .line 25: new-instance v2, Ljava/util/ArrayList;
    .line 27: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    .line 30: invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 33: move-result-object v3
    .line 34: invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 37: move-result-object v3
    .line 38: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 41: move-result v4
    .line 42: if-eqz v4, :cond_65
    .line 44: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 47: move-result-object v4
    .line 48: check-cast v4, Ljava/util/Map$Entry;
    .line 50: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 53: move-result-object v5
    .line 54: invoke-interface {v1, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 57: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 60: move-result-object v5
    .line 61: invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    .line 64: goto :goto_38
    .line 65: invoke-direct {v6, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeCollection(Ljava/util/Collection;)V
    .line 68: invoke-direct {v6, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeCollection(Ljava/util/Collection;)V
    .line 71: return-void
.end method

# virtual methods
.method protected writeNoException()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 4: return-void
.end method

# virtual methods
.method protected abstract writeParcelable(Landroid/os/Parcelable;)V
.end method

# virtual methods
.method public writeParcelable(Landroid/os/Parcelable;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeParcelable(Landroid/os/Parcelable;)V
    .line 6: return-void
.end method

# virtual methods
.method public writeSerializable(Ljava/io/Serializable;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-direct {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeSerializable(Ljava/io/Serializable;)V
    .line 6: return-void
.end method

# virtual methods
.method public writeSet(Ljava/util/Set;I)V
    .registers 3

    .line 0: invoke-direct {v0, v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeCollection(Ljava/util/Collection;I)V
    .line 3: return-void
.end method

# virtual methods
.method public writeSize(Landroid/util/Size;I)V
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-eqz v2, :cond_7
    .line 5: const/4 v0, 1
    .line 6: goto :goto_8
    .line 7: const/4 v0, 0
    .line 8: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeBoolean(Z)V
    .line 11: if-eqz v2, :cond_27
    .line 13: invoke-virtual {v2}, Landroid/util/Size;->getWidth()I
    .line 16: move-result v0
    .line 17: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 20: invoke-virtual {v2}, Landroid/util/Size;->getHeight()I
    .line 23: move-result v0
    .line 24: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 27: return-void
.end method

# virtual methods
.method public writeSizeF(Landroid/util/SizeF;I)V
    .registers 4

    .line 0: invoke-virtual {v1, v3}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-eqz v2, :cond_7
    .line 5: const/4 v0, 1
    .line 6: goto :goto_8
    .line 7: const/4 v0, 0
    .line 8: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeBoolean(Z)V
    .line 11: if-eqz v2, :cond_27
    .line 13: invoke-virtual {v2}, Landroid/util/SizeF;->getWidth()F
    .line 16: move-result v0
    .line 17: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeFloat(F)V
    .line 20: invoke-virtual {v2}, Landroid/util/SizeF;->getHeight()F
    .line 23: move-result v0
    .line 24: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeFloat(F)V
    .line 27: return-void
.end method

# virtual methods
.method public writeSparseBooleanArray(Landroid/util/SparseBooleanArray;I)V
    .registers 6

    .line 0: invoke-virtual {v3, v5}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: if-nez v4, :cond_10
    .line 5: const/4 v0, -1
    .line 6: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 9: return-void
    .line 10: invoke-virtual {v4}, Landroid/util/SparseBooleanArray;->size()I
    .line 13: move-result v0
    .line 14: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 17: const/4 v1, 0
    .line 18: if-ge v1, v0, :cond_37
    .line 20: invoke-virtual {v4, v1}, Landroid/util/SparseBooleanArray;->keyAt(I)I
    .line 23: move-result v2
    .line 24: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeInt(I)V
    .line 27: invoke-virtual {v4, v1}, Landroid/util/SparseBooleanArray;->valueAt(I)Z
    .line 30: move-result v2
    .line 31: invoke-virtual {v3, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeBoolean(Z)V
    .line 34: add-int/lit8 v1, v1, 1
    .line 36: goto :goto_18
    .line 37: return-void
.end method

# virtual methods
.method protected abstract writeString(Ljava/lang/String;)V
.end method

# virtual methods
.method public writeString(Ljava/lang/String;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeStrongBinder(Landroid/os/IBinder;)V
.end method

# virtual methods
.method public writeStrongBinder(Landroid/os/IBinder;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeStrongBinder(Landroid/os/IBinder;)V
    .line 6: return-void
.end method

# virtual methods
.method protected abstract writeStrongInterface(Landroid/os/IInterface;)V
.end method

# virtual methods
.method public writeStrongInterface(Landroid/os/IInterface;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeStrongInterface(Landroid/os/IInterface;)V
    .line 6: return-void
.end method

# virtual methods
.method protected writeToParcel(Landroidx/versionedparcelable/VersionedParcelable;Landroidx/versionedparcelable/VersionedParcel;)V
    .registers 7

    .line 0: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 3: move-result-object v0
    .line 4: invoke-direct {v4, v0}, Landroidx/versionedparcelable/VersionedParcel;->getWriteMethod(Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .line 7: move-result-object v0
    .line 8: const/4 v1, 0
    .line 9: const/4 v2, 2
    .line 10: new-array v2, v2, [Ljava/lang/Object;
    .line 12: const/4 v3, 0
    .line 13: aput-object v5, v2, v3
    .line 15: const/4 v3, 1
    .line 16: aput-object v6, v2, v3
    .line 18: invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    .line 21: nop
    .line 22: return-void
    .line 23: move-exception v0
    .line 24: new-instance v1, Ljava/lang/RuntimeException;
    .line 26: const-string v2, "VersionedParcel encountered ClassNotFoundException"
    .line 28: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 31: throw v1
    .line 32: move-exception v0
    .line 33: new-instance v1, Ljava/lang/RuntimeException;
    .line 35: const-string v2, "VersionedParcel encountered NoSuchMethodException"
    .line 37: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 40: throw v1
    .line 41: move-exception v0
    .line 42: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 45: move-result-object v1
    .line 46: instance-of v1, v1, Ljava/lang/RuntimeException;
    .line 48: if-eqz v1, :cond_57
    .line 50: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    .line 53: move-result-object v1
    .line 54: check-cast v1, Ljava/lang/RuntimeException;
    .line 56: throw v1
    .line 57: new-instance v1, Ljava/lang/RuntimeException;
    .line 59: const-string v2, "VersionedParcel encountered InvocationTargetException"
    .line 61: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 64: throw v1
    .line 65: move-exception v0
    .line 66: new-instance v1, Ljava/lang/RuntimeException;
    .line 68: const-string v2, "VersionedParcel encountered IllegalAccessException"
    .line 70: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 73: throw v1
.end method

# virtual methods
.method protected writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .registers 3

    .line 0: if-nez v2, :cond_7
    .line 2: const/4 v0, 0
    .line 3: invoke-virtual {v1, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeString(Ljava/lang/String;)V
    .line 6: return-void
    .line 7: invoke-direct {v1, v2}, Landroidx/versionedparcelable/VersionedParcel;->writeVersionedParcelableCreator(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 10: invoke-virtual {v1}, Landroidx/versionedparcelable/VersionedParcel;->createSubParcel()Landroidx/versionedparcelable/VersionedParcel;
    .line 13: move-result-object v0
    .line 14: invoke-virtual {v1, v2, v0}, Landroidx/versionedparcelable/VersionedParcel;->writeToParcel(Landroidx/versionedparcelable/VersionedParcelable;Landroidx/versionedparcelable/VersionedParcel;)V
    .line 17: invoke-virtual {v0}, Landroidx/versionedparcelable/VersionedParcel;->closeField()V
    .line 20: return-void
.end method

# virtual methods
.method public writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;I)V
    .registers 3

    .line 0: invoke-virtual {v0, v2}, Landroidx/versionedparcelable/VersionedParcel;->setOutputField(I)V
    .line 3: invoke-virtual {v0, v1}, Landroidx/versionedparcelable/VersionedParcel;->writeVersionedParcelable(Landroidx/versionedparcelable/VersionedParcelable;)V
    .line 6: return-void
.end method
