.class  Landroidx/versionedparcelable/VersionedParcelStream$1;
.super Ljava/io/FilterInputStream;
.source "VersionedParcelStream.java"

.field final synthetic this$0:Landroidx/versionedparcelable/VersionedParcelStream;

# direct methods
.method constructor <init>(Landroidx/versionedparcelable/VersionedParcelStream;Ljava/io/InputStream;)V
    .registers 3

    .line 0: iput-object v1, v0, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: invoke-direct {v0, v2}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V
    .line 5: return-void
.end method

# virtual methods
.method public read()I
    .registers 4

    .line 0: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 4: const/4 v1, -1
    .line 5: if-eq v0, v1, :cond_24
    .line 7: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 9: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 11: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 13: iget v1, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 15: if-ge v0, v1, :cond_18
    .line 17: goto :goto_24
    .line 18: new-instance v0, Ljava/io/IOException;
    .line 20: invoke-direct {v0}, Ljava/io/IOException;-><init>()V
    .line 23: throw v0
    .line 24: invoke-super {v3}, Ljava/io/FilterInputStream;->read()I
    .line 27: move-result v0
    .line 28: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 30: iget v2, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 32: add-int/lit8 v2, v2, 1
    .line 34: iput v2, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 36: return v0
.end method

# virtual methods
.method public read([BII)I
    .registers 7

    .line 0: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 4: const/4 v1, -1
    .line 5: if-eq v0, v1, :cond_24
    .line 7: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 9: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 11: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 13: iget v1, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 15: if-ge v0, v1, :cond_18
    .line 17: goto :goto_24
    .line 18: new-instance v0, Ljava/io/IOException;
    .line 20: invoke-direct {v0}, Ljava/io/IOException;-><init>()V
    .line 23: throw v0
    .line 24: invoke-super {v3, v4, v5, v6}, Ljava/io/FilterInputStream;->read([BII)I
    .line 27: move-result v0
    .line 28: if-lez v0, :cond_37
    .line 30: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 32: iget v2, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 34: add-int/2addr v2, v0
    .line 35: iput v2, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 37: return v0
.end method

# virtual methods
.method public skip(J)J
    .registers 8

    .line 0: iget-object v0, v5, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 4: const/4 v1, -1
    .line 5: if-eq v0, v1, :cond_24
    .line 7: iget-object v0, v5, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 9: iget v0, v0, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 11: iget-object v1, v5, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 13: iget v1, v1, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 15: if-ge v0, v1, :cond_18
    .line 17: goto :goto_24
    .line 18: new-instance v0, Ljava/io/IOException;
    .line 20: invoke-direct {v0}, Ljava/io/IOException;-><init>()V
    .line 23: throw v0
    .line 24: invoke-super {v5, v6, v7}, Ljava/io/FilterInputStream;->skip(J)J
    .line 27: move-result-wide v0
    .line 28: const-wide/16 v2, 0
    .line 30: cmp-long v4, v0, v2
    .line 32: if-lez v4, :cond_42
    .line 34: iget-object v2, v5, Landroidx/versionedparcelable/VersionedParcelStream$1;->this$0:Landroidx/versionedparcelable/VersionedParcelStream;
    .line 36: iget v3, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 38: long-to-int v4, v0
    .line 39: add-int/2addr v3, v4
    .line 40: iput v3, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 42: return-wide v0
.end method
