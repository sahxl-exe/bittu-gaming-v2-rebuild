.class  Landroidx/versionedparcelable/VersionedParcelStream;
.super Landroidx/versionedparcelable/VersionedParcel;
.source "VersionedParcelStream.java"

.field private static final TYPE_BOOLEAN:I
.field private static final TYPE_BOOLEAN_ARRAY:I
.field private static final TYPE_DOUBLE:I
.field private static final TYPE_DOUBLE_ARRAY:I
.field private static final TYPE_FLOAT:I
.field private static final TYPE_FLOAT_ARRAY:I
.field private static final TYPE_INT:I
.field private static final TYPE_INT_ARRAY:I
.field private static final TYPE_LONG:I
.field private static final TYPE_LONG_ARRAY:I
.field private static final TYPE_NULL:I
.field private static final TYPE_STRING:I
.field private static final TYPE_STRING_ARRAY:I
.field private static final TYPE_SUB_BUNDLE:I
.field private static final TYPE_SUB_PERSISTABLE_BUNDLE:I
.field private static final UTF_16:Ljava/nio/charset/Charset;

.field  mCount:I
.field private mCurrentInput:Ljava/io/DataInputStream;
.field private mCurrentOutput:Ljava/io/DataOutputStream;
.field private mFieldBuffer:Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
.field private mFieldId:I
.field  mFieldSize:I
.field private mIgnoreParcelables:Z
.field private final mMasterInput:Ljava/io/DataInputStream;
.field private final mMasterOutput:Ljava/io/DataOutputStream;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const-string v0, "UTF-16"
    .line 2: invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;
    .line 5: move-result-object v0
    .line 6: sput-object v0, Landroidx/versionedparcelable/VersionedParcelStream;->UTF_16:Ljava/nio/charset/Charset;
    .line 8: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    .registers 9

    .line 0: new-instance v3, Landroidx/collection/ArrayMap;
    .line 2: invoke-direct {v3}, Landroidx/collection/ArrayMap;-><init>()V
    .line 5: new-instance v4, Landroidx/collection/ArrayMap;
    .line 7: invoke-direct {v4}, Landroidx/collection/ArrayMap;-><init>()V
    .line 10: new-instance v5, Landroidx/collection/ArrayMap;
    .line 12: invoke-direct {v5}, Landroidx/collection/ArrayMap;-><init>()V
    .line 15: move-object v0, v6
    .line 16: move-object v1, v7
    .line 17: move-object v2, v8
    .line 18: invoke-direct/range {v0 .. v5}, Landroidx/versionedparcelable/VersionedParcelStream;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 21: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .registers 9

    .line 0: invoke-direct {v3, v6, v7, v8}, Landroidx/versionedparcelable/VersionedParcel;-><init>(Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 3: const/4 v0, 0
    .line 4: iput v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 6: const/4 v0, -1
    .line 7: iput v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldId:I
    .line 9: iput v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 11: const/4 v0, 0
    .line 12: if-eqz v4, :cond_25
    .line 14: new-instance v1, Ljava/io/DataInputStream;
    .line 16: new-instance v2, Landroidx/versionedparcelable/VersionedParcelStream$1;
    .line 18: invoke-direct {v2, v3, v4}, Landroidx/versionedparcelable/VersionedParcelStream$1;-><init>(Landroidx/versionedparcelable/VersionedParcelStream;Ljava/io/InputStream;)V
    .line 21: invoke-direct {v1, v2}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    .line 24: goto :goto_26
    .line 25: move-object v1, v0
    .line 26: iput-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterInput:Ljava/io/DataInputStream;
    .line 28: if-eqz v5, :cond_35
    .line 30: new-instance v0, Ljava/io/DataOutputStream;
    .line 32: invoke-direct {v0, v5}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    .line 35: iput-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterOutput:Ljava/io/DataOutputStream;
    .line 37: iput-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 39: iput-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 41: return-void
.end method

# direct methods
.method private readObject(ILjava/lang/String;Landroid/os/Bundle;)V
    .registers 7

    .line 0: packed-switch v4, :data_152
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: new-instance v1, Ljava/lang/StringBuilder;
    .line 7: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 10: const-string v2, "Unknown type "
    .line 12: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 15: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    .line 18: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 21: move-result-object v1
    .line 22: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 25: throw v0
    .line 26: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readFloatArray()[F
    .line 29: move-result-object v0
    .line 30: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putFloatArray(Ljava/lang/String;[F)V
    .line 33: goto/16 :goto_150
    .line 35: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readFloat()F
    .line 38: move-result v0
    .line 39: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V
    .line 42: goto/16 :goto_150
    .line 44: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readLongArray()[J
    .line 47: move-result-object v0
    .line 48: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putLongArray(Ljava/lang/String;[J)V
    .line 51: goto :goto_150
    .line 52: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readLong()J
    .line 55: move-result-wide v0
    .line 56: invoke-virtual {v6, v5, v0, v1}, Landroid/os/Bundle;->putLong(Ljava/lang/String;J)V
    .line 59: goto :goto_150
    .line 60: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readIntArray()[I
    .line 63: move-result-object v0
    .line 64: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putIntArray(Ljava/lang/String;[I)V
    .line 67: goto :goto_150
    .line 68: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readInt()I
    .line 71: move-result v0
    .line 72: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    .line 75: goto :goto_150
    .line 76: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readDoubleArray()[D
    .line 79: move-result-object v0
    .line 80: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putDoubleArray(Ljava/lang/String;[D)V
    .line 83: goto :goto_150
    .line 84: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readDouble()D
    .line 87: move-result-wide v0
    .line 88: invoke-virtual {v6, v5, v0, v1}, Landroid/os/Bundle;->putDouble(Ljava/lang/String;D)V
    .line 91: goto :goto_150
    .line 92: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readBooleanArray()[Z
    .line 95: move-result-object v0
    .line 96: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putBooleanArray(Ljava/lang/String;[Z)V
    .line 99: goto :goto_150
    .line 100: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readBoolean()Z
    .line 103: move-result v0
    .line 104: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V
    .line 107: goto :goto_150
    .line 108: const/4 v0, 0
    .line 109: new-array v0, v0, [Ljava/lang/String;
    .line 111: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->readArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .line 114: move-result-object v0
    .line 115: check-cast v0, [Ljava/lang/String;
    .line 117: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V
    .line 120: goto :goto_150
    .line 121: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readString()Ljava/lang/String;
    .line 124: move-result-object v0
    .line 125: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    .line 128: goto :goto_150
    .line 129: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readBundle()Landroid/os/Bundle;
    .line 132: move-result-object v0
    .line 133: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    .line 136: goto :goto_150
    .line 137: invoke-virtual {v3}, Landroidx/versionedparcelable/VersionedParcelStream;->readBundle()Landroid/os/Bundle;
    .line 140: move-result-object v0
    .line 141: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    .line 144: goto :goto_150
    .line 145: const/4 v0, 0
    .line 146: invoke-virtual {v6, v5, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    .line 149: nop
    .line 150: return-void
    .line 151: nop
    .line 152: nop
    .line 153: return v0
    .line 154: nop
    .line 155: nop
    .line 156: sub-int v0, v0, v0
    .line 158: float-to-double v0, v0
    .line 159: nop
    .line 160: int-to-long v0, v0
    .line 161: nop
    .line 162: 0x79 ; unknown opcode
    .line 163: nop
    .line 164: sput-char v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 166: sget-byte v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 168: iput-boolean v0, v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 170: iget-object v0, v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 172: aput-wide v0, v0, v0
    .line 174: aget v0, v0, v0
    .line 176: if-gtz v0, :cond_176
    .line 178: if-lt v0, v0, :cond_178
    .line 180: sparse-switch v0, :data_2293940
    .line 183: nop
    .line 184: const-string v0, ""
.end method

# direct methods
.method private writeObject(Ljava/lang/Object;)V
    .registers 5

    .line 0: if-nez v4, :cond_8
    .line 2: const/4 v0, 0
    .line 3: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 6: goto/16 :goto_248
    .line 8: instance-of v0, v4, Landroid/os/Bundle;
    .line 10: if-eqz v0, :cond_24
    .line 12: const/4 v0, 1
    .line 13: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 16: move-object v0, v4
    .line 17: check-cast v0, Landroid/os/Bundle;
    .line 19: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeBundle(Landroid/os/Bundle;)V
    .line 22: goto/16 :goto_248
    .line 24: instance-of v0, v4, Ljava/lang/String;
    .line 26: if-eqz v0, :cond_40
    .line 28: const/4 v0, 3
    .line 29: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 32: move-object v0, v4
    .line 33: check-cast v0, Ljava/lang/String;
    .line 35: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeString(Ljava/lang/String;)V
    .line 38: goto/16 :goto_248
    .line 40: instance-of v0, v4, [Ljava/lang/String;
    .line 42: if-eqz v0, :cond_58
    .line 44: const/4 v0, 4
    .line 45: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 48: move-object v0, v4
    .line 49: check-cast v0, [Ljava/lang/String;
    .line 51: check-cast v0, [Ljava/lang/String;
    .line 53: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeArray([Ljava/lang/Object;)V
    .line 56: goto/16 :goto_248
    .line 58: instance-of v0, v4, Ljava/lang/Boolean;
    .line 60: if-eqz v0, :cond_78
    .line 62: const/4 v0, 5
    .line 63: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 66: move-object v0, v4
    .line 67: check-cast v0, Ljava/lang/Boolean;
    .line 69: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    .line 72: move-result v0
    .line 73: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeBoolean(Z)V
    .line 76: goto/16 :goto_248
    .line 78: instance-of v0, v4, [Z
    .line 80: if-eqz v0, :cond_96
    .line 82: const/4 v0, 6
    .line 83: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 86: move-object v0, v4
    .line 87: check-cast v0, [Z
    .line 89: check-cast v0, [Z
    .line 91: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeBooleanArray([Z)V
    .line 94: goto/16 :goto_248
    .line 96: instance-of v0, v4, Ljava/lang/Double;
    .line 98: if-eqz v0, :cond_116
    .line 100: const/4 v0, 7
    .line 101: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 104: move-object v0, v4
    .line 105: check-cast v0, Ljava/lang/Double;
    .line 107: invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D
    .line 110: move-result-wide v0
    .line 111: invoke-virtual {v3, v0, v1}, Landroidx/versionedparcelable/VersionedParcelStream;->writeDouble(D)V
    .line 114: goto/16 :goto_248
    .line 116: instance-of v0, v4, [D
    .line 118: if-eqz v0, :cond_135
    .line 120: const/16 v0, 8
    .line 122: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 125: move-object v0, v4
    .line 126: check-cast v0, [D
    .line 128: check-cast v0, [D
    .line 130: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeDoubleArray([D)V
    .line 133: goto/16 :goto_248
    .line 135: instance-of v0, v4, Ljava/lang/Integer;
    .line 137: if-eqz v0, :cond_155
    .line 139: const/16 v0, 9
    .line 141: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 144: move-object v0, v4
    .line 145: check-cast v0, Ljava/lang/Integer;
    .line 147: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    .line 150: move-result v0
    .line 151: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 154: goto :goto_248
    .line 155: instance-of v0, v4, [I
    .line 157: if-eqz v0, :cond_173
    .line 159: const/16 v0, 10
    .line 161: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 164: move-object v0, v4
    .line 165: check-cast v0, [I
    .line 167: check-cast v0, [I
    .line 169: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeIntArray([I)V
    .line 172: goto :goto_248
    .line 173: instance-of v0, v4, Ljava/lang/Long;
    .line 175: if-eqz v0, :cond_193
    .line 177: const/16 v0, 11
    .line 179: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 182: move-object v0, v4
    .line 183: check-cast v0, Ljava/lang/Long;
    .line 185: invoke-virtual {v0}, Ljava/lang/Long;->longValue()J
    .line 188: move-result-wide v0
    .line 189: invoke-virtual {v3, v0, v1}, Landroidx/versionedparcelable/VersionedParcelStream;->writeLong(J)V
    .line 192: goto :goto_248
    .line 193: instance-of v0, v4, [J
    .line 195: if-eqz v0, :cond_211
    .line 197: const/16 v0, 12
    .line 199: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 202: move-object v0, v4
    .line 203: check-cast v0, [J
    .line 205: check-cast v0, [J
    .line 207: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeLongArray([J)V
    .line 210: goto :goto_248
    .line 211: instance-of v0, v4, Ljava/lang/Float;
    .line 213: if-eqz v0, :cond_231
    .line 215: const/16 v0, 13
    .line 217: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 220: move-object v0, v4
    .line 221: check-cast v0, Ljava/lang/Float;
    .line 223: invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F
    .line 226: move-result v0
    .line 227: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeFloat(F)V
    .line 230: goto :goto_248
    .line 231: instance-of v0, v4, [F
    .line 233: if-eqz v0, :cond_249
    .line 235: const/16 v0, 14
    .line 237: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeInt(I)V
    .line 240: move-object v0, v4
    .line 241: check-cast v0, [F
    .line 243: check-cast v0, [F
    .line 245: invoke-virtual {v3, v0}, Landroidx/versionedparcelable/VersionedParcelStream;->writeFloatArray([F)V
    .line 248: return-void
    .line 249: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 251: new-instance v1, Ljava/lang/StringBuilder;
    .line 253: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 256: const-string v2, "Unsupported type "
    .line 258: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 261: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 264: move-result-object v2
    .line 265: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 268: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 271: move-result-object v1
    .line 272: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 275: throw v0
.end method

# virtual methods
.method public closeField()V
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldBuffer:Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
    .line 2: if-eqz v0, :cond_29
    .line 4: iget-object v0, v0, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mOutput:Ljava/io/ByteArrayOutputStream;
    .line 6: invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I
    .line 9: move-result v0
    .line 10: if-eqz v0, :cond_17
    .line 12: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldBuffer:Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
    .line 14: invoke-virtual {v0}, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->flushField()V
    .line 17: nop
    .line 18: const/4 v0, 0
    .line 19: iput-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldBuffer:Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
    .line 21: goto :goto_29
    .line 22: move-exception v0
    .line 23: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 25: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 28: throw v1
    .line 29: return-void
.end method

# virtual methods
.method protected createSubParcel()Landroidx/versionedparcelable/VersionedParcel;
    .registers 8

    .line 0: new-instance v6, Landroidx/versionedparcelable/VersionedParcelStream;
    .line 2: iget-object v1, v7, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 4: iget-object v2, v7, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 6: iget-object v3, v7, Landroidx/versionedparcelable/VersionedParcelStream;->mReadCache:Landroidx/collection/ArrayMap;
    .line 8: iget-object v4, v7, Landroidx/versionedparcelable/VersionedParcelStream;->mWriteCache:Landroidx/collection/ArrayMap;
    .line 10: iget-object v5, v7, Landroidx/versionedparcelable/VersionedParcelStream;->mParcelizerCache:Landroidx/collection/ArrayMap;
    .line 12: move-object v0, v6
    .line 13: invoke-direct/range {v0 .. v5}, Landroidx/versionedparcelable/VersionedParcelStream;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 16: return-object v6
.end method

# virtual methods
.method public isStream()Z
    .registers 2

    .line 0: const/4 v0, 1
    .line 1: return v0
.end method

# virtual methods
.method public readBoolean()Z
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readBoolean()Z
    .line 5: move-result v0
    .line 6: return v0
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public readBundle()Landroid/os/Bundle;
    .registers 6

    .line 0: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcelStream;->readInt()I
    .line 3: move-result v0
    .line 4: if-gez v0, :cond_8
    .line 6: const/4 v1, 0
    .line 7: return-object v1
    .line 8: new-instance v1, Landroid/os/Bundle;
    .line 10: invoke-direct {v1}, Landroid/os/Bundle;-><init>()V
    .line 13: const/4 v2, 0
    .line 14: if-ge v2, v0, :cond_30
    .line 16: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcelStream;->readString()Ljava/lang/String;
    .line 19: move-result-object v3
    .line 20: invoke-virtual {v5}, Landroidx/versionedparcelable/VersionedParcelStream;->readInt()I
    .line 23: move-result v4
    .line 24: invoke-direct {v5, v4, v3, v1}, Landroidx/versionedparcelable/VersionedParcelStream;->readObject(ILjava/lang/String;Landroid/os/Bundle;)V
    .line 27: add-int/lit8 v2, v2, 1
    .line 29: goto :goto_14
    .line 30: return-object v1
.end method

# virtual methods
.method public readByteArray()[B
    .registers 4

    .line 0: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I
    .line 5: move-result v0
    .line 6: if-lez v0, :cond_16
    .line 8: new-array v1, v0, [B
    .line 10: iget-object v2, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 12: invoke-virtual {v2, v1}, Ljava/io/DataInputStream;->readFully([B)V
    .line 15: return-object v1
    .line 16: const/4 v1, 0
    .line 17: return-object v1
    .line 18: move-exception v0
    .line 19: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 21: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 24: throw v1
.end method

# virtual methods
.method protected readCharSequence()Ljava/lang/CharSequence;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return-object v0
.end method

# virtual methods
.method public readDouble()D
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readDouble()D
    .line 5: move-result-wide v0
    .line 6: return-wide v0
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public readField(I)Z
    .registers 7

    .line 0: const/4 v0, 0
    .line 1: iget v1, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldId:I
    .line 3: if-ne v1, v6, :cond_7
    .line 5: const/4 v0, 1
    .line 6: return v0
    .line 7: invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 10: move-result-object v1
    .line 11: invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 14: move-result-object v2
    .line 15: invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    .line 18: move-result v1
    .line 19: if-lez v1, :cond_22
    .line 21: return v0
    .line 22: iget v1, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 24: iget v2, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 26: if-ge v1, v2, :cond_35
    .line 28: iget-object v3, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterInput:Ljava/io/DataInputStream;
    .line 30: sub-int/2addr v2, v1
    .line 31: int-to-long v1, v2
    .line 32: invoke-virtual {v3, v1, v2}, Ljava/io/DataInputStream;->skip(J)J
    .line 35: const/4 v1, -1
    .line 36: iput v1, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 38: iget-object v1, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterInput:Ljava/io/DataInputStream;
    .line 40: invoke-virtual {v1}, Ljava/io/DataInputStream;->readInt()I
    .line 43: move-result v1
    .line 44: iput v0, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mCount:I
    .line 46: const v2, 0xffff
    .line 49: and-int v3, v1, v2
    .line 51: if-ne v3, v2, :cond_60
    .line 53: iget-object v4, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterInput:Ljava/io/DataInputStream;
    .line 55: invoke-virtual {v4}, Ljava/io/DataInputStream;->readInt()I
    .line 58: move-result v4
    .line 59: move v3, v4
    .line 60: shr-int/lit8 v4, v1, 16
    .line 62: and-int/2addr v2, v4
    .line 63: iput v2, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldId:I
    .line 65: iput v3, v5, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldSize:I
    .line 67: goto :goto_0
    .line 68: move-exception v1
    .line 69: return v0
.end method

# virtual methods
.method public readFloat()F
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readFloat()F
    .line 5: move-result v0
    .line 6: return v0
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public readInt()I
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I
    .line 5: move-result v0
    .line 6: return v0
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public readLong()J
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readLong()J
    .line 5: move-result-wide v0
    .line 6: return-wide v0
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public readParcelable()Landroid/os/Parcelable;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return-object v0
.end method

# virtual methods
.method public readString()Ljava/lang/String;
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 2: invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I
    .line 5: move-result v0
    .line 6: if-lez v0, :cond_23
    .line 8: new-array v1, v0, [B
    .line 10: iget-object v2, v4, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentInput:Ljava/io/DataInputStream;
    .line 12: invoke-virtual {v2, v1}, Ljava/io/DataInputStream;->readFully([B)V
    .line 15: new-instance v2, Ljava/lang/String;
    .line 17: sget-object v3, Landroidx/versionedparcelable/VersionedParcelStream;->UTF_16:Ljava/nio/charset/Charset;
    .line 19: invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    .line 22: return-object v2
    .line 23: const/4 v1, 0
    .line 24: return-object v1
    .line 25: move-exception v0
    .line 26: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 28: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 31: throw v1
.end method

# virtual methods
.method public readStrongBinder()Landroid/os/IBinder;
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: return-object v0
.end method

# virtual methods
.method public setOutputField(I)V
    .registers 4

    .line 0: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcelStream;->closeField()V
    .line 3: new-instance v0, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
    .line 5: iget-object v1, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mMasterOutput:Ljava/io/DataOutputStream;
    .line 7: invoke-direct {v0, v3, v1}, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;-><init>(ILjava/io/DataOutputStream;)V
    .line 10: iput-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mFieldBuffer:Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;
    .line 12: iget-object v0, v0, Landroidx/versionedparcelable/VersionedParcelStream$FieldBuffer;->mDataStream:Ljava/io/DataOutputStream;
    .line 14: iput-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 16: return-void
.end method

# virtual methods
.method public setSerializationFlags(ZZ)V
    .registers 5

    .line 0: if-eqz v3, :cond_5
    .line 2: iput-boolean v4, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mIgnoreParcelables:Z
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/RuntimeException;
    .line 7: const-string v1, "Serialization of this object is not allowed"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# virtual methods
.method public writeBoolean(Z)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeBoolean(Z)V
    .line 5: nop
    .line 6: return-void
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public writeBundle(Landroid/os/Bundle;)V
    .registers 6

    .line 0: if-eqz v5, :cond_43
    .line 2: invoke-virtual {v5}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    .line 5: move-result-object v0
    .line 6: iget-object v1, v4, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 8: invoke-interface {v0}, Ljava/util/Set;->size()I
    .line 11: move-result v2
    .line 12: invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 15: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 18: move-result-object v1
    .line 19: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 22: move-result v2
    .line 23: if-eqz v2, :cond_42
    .line 25: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 28: move-result-object v2
    .line 29: check-cast v2, Ljava/lang/String;
    .line 31: invoke-virtual {v4, v2}, Landroidx/versionedparcelable/VersionedParcelStream;->writeString(Ljava/lang/String;)V
    .line 34: invoke-virtual {v5, v2}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;
    .line 37: move-result-object v3
    .line 38: invoke-direct {v4, v3}, Landroidx/versionedparcelable/VersionedParcelStream;->writeObject(Ljava/lang/Object;)V
    .line 41: goto :goto_19
    .line 42: goto :goto_49
    .line 43: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 45: const/4 v1, -1
    .line 46: invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 49: nop
    .line 50: return-void
    .line 51: move-exception v0
    .line 52: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 54: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 57: goto :goto_59
    .line 58: throw v1
    .line 59: goto :goto_58
.end method

# virtual methods
.method public writeByteArray([B)V
    .registers 4

    .line 0: if-eqz v3, :cond_14
    .line 2: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 4: array-length v1, v3
    .line 5: invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 8: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 10: invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->write([B)V
    .line 13: goto :goto_20
    .line 14: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 16: const/4 v1, -1
    .line 17: invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 20: nop
    .line 21: return-void
    .line 22: move-exception v0
    .line 23: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 25: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 28: throw v1
.end method

# virtual methods
.method public writeByteArray([BII)V
    .registers 6

    .line 0: if-eqz v3, :cond_13
    .line 2: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 4: invoke-virtual {v0, v5}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 7: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 9: invoke-virtual {v0, v3, v4, v5}, Ljava/io/DataOutputStream;->write([BII)V
    .line 12: goto :goto_19
    .line 13: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 15: const/4 v1, -1
    .line 16: invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 19: nop
    .line 20: return-void
    .line 21: move-exception v0
    .line 22: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 24: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 27: throw v1
.end method

# virtual methods
.method protected writeCharSequence(Ljava/lang/CharSequence;)V
    .registers 4

    .line 0: iget-boolean v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mIgnoreParcelables:Z
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/RuntimeException;
    .line 7: const-string v1, "CharSequence cannot be written to an OutputStream"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# virtual methods
.method public writeDouble(D)V
    .registers 5

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0, v3, v4}, Ljava/io/DataOutputStream;->writeDouble(D)V
    .line 5: nop
    .line 6: return-void
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public writeFloat(F)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeFloat(F)V
    .line 5: nop
    .line 6: return-void
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public writeInt(I)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 5: nop
    .line 6: return-void
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public writeLong(J)V
    .registers 5

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 2: invoke-virtual {v0, v3, v4}, Ljava/io/DataOutputStream;->writeLong(J)V
    .line 5: nop
    .line 6: return-void
    .line 7: move-exception v0
    .line 8: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 10: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 13: throw v1
.end method

# virtual methods
.method public writeParcelable(Landroid/os/Parcelable;)V
    .registers 4

    .line 0: iget-boolean v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mIgnoreParcelables:Z
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/RuntimeException;
    .line 7: const-string v1, "Parcelables cannot be written to an OutputStream"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# virtual methods
.method public writeString(Ljava/lang/String;)V
    .registers 5

    .line 0: if-eqz v4, :cond_20
    .line 2: sget-object v0, Landroidx/versionedparcelable/VersionedParcelStream;->UTF_16:Ljava/nio/charset/Charset;
    .line 4: invoke-virtual {v4, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B
    .line 7: move-result-object v0
    .line 8: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 10: array-length v2, v0
    .line 11: invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 14: iget-object v1, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 16: invoke-virtual {v1, v0}, Ljava/io/DataOutputStream;->write([B)V
    .line 19: goto :goto_26
    .line 20: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelStream;->mCurrentOutput:Ljava/io/DataOutputStream;
    .line 22: const/4 v1, -1
    .line 23: invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->writeInt(I)V
    .line 26: nop
    .line 27: return-void
    .line 28: move-exception v0
    .line 29: new-instance v1, Landroidx/versionedparcelable/VersionedParcel$ParcelException;
    .line 31: invoke-direct {v1, v0}, Landroidx/versionedparcelable/VersionedParcel$ParcelException;-><init>(Ljava/lang/Throwable;)V
    .line 34: throw v1
.end method

# virtual methods
.method public writeStrongBinder(Landroid/os/IBinder;)V
    .registers 4

    .line 0: iget-boolean v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mIgnoreParcelables:Z
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/RuntimeException;
    .line 7: const-string v1, "Binders cannot be written to an OutputStream"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method

# virtual methods
.method public writeStrongInterface(Landroid/os/IInterface;)V
    .registers 4

    .line 0: iget-boolean v0, v2, Landroidx/versionedparcelable/VersionedParcelStream;->mIgnoreParcelables:Z
    .line 2: if-eqz v0, :cond_5
    .line 4: return-void
    .line 5: new-instance v0, Ljava/lang/RuntimeException;
    .line 7: const-string v1, "Binders cannot be written to an OutputStream"
    .line 9: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 12: throw v0
.end method
