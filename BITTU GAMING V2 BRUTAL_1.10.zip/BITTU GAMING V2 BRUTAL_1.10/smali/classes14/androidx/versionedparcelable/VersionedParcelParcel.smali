.class  Landroidx/versionedparcelable/VersionedParcelParcel;
.super Landroidx/versionedparcelable/VersionedParcel;
.source "VersionedParcelParcel.java"

.field private static final DEBUG:Z
.field private static final TAG:Ljava/lang/String;

.field private mCurrentField:I
.field private final mEnd:I
.field private mFieldId:I
.field private mNextRead:I
.field private final mOffset:I
.field private final mParcel:Landroid/os/Parcel;
.field private final mPositionLookup:Landroid/util/SparseIntArray;
.field private final mPrefix:Ljava/lang/String;

# direct methods
.method constructor <init>(Landroid/os/Parcel;)V
    .registers 10

    .line 0: invoke-virtual {v9}, Landroid/os/Parcel;->dataPosition()I
    .line 3: move-result v2
    .line 4: invoke-virtual {v9}, Landroid/os/Parcel;->dataSize()I
    .line 7: move-result v3
    .line 8: new-instance v5, Landroidx/collection/ArrayMap;
    .line 10: invoke-direct {v5}, Landroidx/collection/ArrayMap;-><init>()V
    .line 13: new-instance v6, Landroidx/collection/ArrayMap;
    .line 15: invoke-direct {v6}, Landroidx/collection/ArrayMap;-><init>()V
    .line 18: new-instance v7, Landroidx/collection/ArrayMap;
    .line 20: invoke-direct {v7}, Landroidx/collection/ArrayMap;-><init>()V
    .line 23: const-string v4, ""
    .line 25: move-object v0, v8
    .line 26: move-object v1, v9
    .line 27: invoke-direct/range {v0 .. v7}, Landroidx/versionedparcelable/VersionedParcelParcel;-><init>(Landroid/os/Parcel;IILjava/lang/String;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 30: return-void
.end method

# direct methods
.method private constructor <init>(Landroid/os/Parcel;IILjava/lang/String;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .registers 10

    .line 0: invoke-direct {v2, v7, v8, v9}, Landroidx/versionedparcelable/VersionedParcel;-><init>(Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 3: new-instance v0, Landroid/util/SparseIntArray;
    .line 5: invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V
    .line 8: iput-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mPositionLookup:Landroid/util/SparseIntArray;
    .line 10: const/4 v0, -1
    .line 11: iput v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mCurrentField:I
    .line 13: const/4 v1, 0
    .line 14: iput v1, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 16: iput v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mFieldId:I
    .line 18: iput-object v3, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 20: iput v4, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mOffset:I
    .line 22: iput v5, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mEnd:I
    .line 24: iput v4, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 26: iput-object v6, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mPrefix:Ljava/lang/String;
    .line 28: return-void
.end method

# virtual methods
.method public closeField()V
    .registers 5

    .line 0: iget v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mCurrentField:I
    .line 2: if-ltz v0, :cond_33
    .line 4: iget-object v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mPositionLookup:Landroid/util/SparseIntArray;
    .line 6: invoke-virtual {v1, v0}, Landroid/util/SparseIntArray;->get(I)I
    .line 9: move-result v0
    .line 10: iget-object v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 12: invoke-virtual {v1}, Landroid/os/Parcel;->dataPosition()I
    .line 15: move-result v1
    .line 16: sub-int v2, v1, v0
    .line 18: iget-object v3, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 20: invoke-virtual {v3, v0}, Landroid/os/Parcel;->setDataPosition(I)V
    .line 23: iget-object v3, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 25: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInt(I)V
    .line 28: iget-object v3, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 30: invoke-virtual {v3, v1}, Landroid/os/Parcel;->setDataPosition(I)V
    .line 33: return-void
.end method

# virtual methods
.method protected createSubParcel()Landroidx/versionedparcelable/VersionedParcel;
    .registers 10

    .line 0: new-instance v8, Landroidx/versionedparcelable/VersionedParcelParcel;
    .line 2: iget-object v1, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 4: invoke-virtual {v1}, Landroid/os/Parcel;->dataPosition()I
    .line 7: move-result v2
    .line 8: iget v0, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 10: iget v3, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mOffset:I
    .line 12: if-ne v0, v3, :cond_16
    .line 14: iget v0, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mEnd:I
    .line 16: move v3, v0
    .line 17: new-instance v0, Ljava/lang/StringBuilder;
    .line 19: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    .line 22: iget-object v4, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mPrefix:Ljava/lang/String;
    .line 24: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: const-string v4, "  "
    .line 29: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 32: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 35: move-result-object v4
    .line 36: iget-object v5, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mReadCache:Landroidx/collection/ArrayMap;
    .line 38: iget-object v6, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mWriteCache:Landroidx/collection/ArrayMap;
    .line 40: iget-object v7, v9, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcelizerCache:Landroidx/collection/ArrayMap;
    .line 42: move-object v0, v8
    .line 43: invoke-direct/range {v0 .. v7}, Landroidx/versionedparcelable/VersionedParcelParcel;-><init>(Landroid/os/Parcel;IILjava/lang/String;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;Landroidx/collection/ArrayMap;)V
    .line 46: return-object v8
.end method

# virtual methods
.method public readBoolean()Z
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I
    .line 5: move-result v0
    .line 6: if-eqz v0, :cond_10
    .line 8: const/4 v0, 1
    .line 9: goto :goto_11
    .line 10: const/4 v0, 0
    .line 11: return v0
.end method

# virtual methods
.method public readBundle()Landroid/os/Bundle;
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 9: move-result-object v1
    .line 10: invoke-virtual {v0, v1}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;
    .line 13: move-result-object v0
    .line 14: return-object v0
.end method

# virtual methods
.method public readByteArray()[B
    .registers 4

    .line 0: iget-object v0, v3, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I
    .line 5: move-result v0
    .line 6: if-gez v0, :cond_10
    .line 8: const/4 v1, 0
    .line 9: return-object v1
    .line 10: new-array v1, v0, [B
    .line 12: iget-object v2, v3, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 14: invoke-virtual {v2, v1}, Landroid/os/Parcel;->readByteArray([B)V
    .line 17: return-object v1
.end method

# virtual methods
.method protected readCharSequence()Ljava/lang/CharSequence;
    .registers 3

    .line 0: sget-object v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    .line 2: iget-object v1, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 4: invoke-interface {v0, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .line 7: move-result-object v0
    .line 8: check-cast v0, Ljava/lang/CharSequence;
    .line 10: return-object v0
.end method

# virtual methods
.method public readDouble()D
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readDouble()D
    .line 5: move-result-wide v0
    .line 6: return-wide v0
.end method

# virtual methods
.method public readField(I)Z
    .registers 6

    .line 0: iget v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 2: iget v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mEnd:I
    .line 4: const/4 v2, 1
    .line 5: const/4 v3, 0
    .line 6: if-ge v0, v1, :cond_55
    .line 8: iget v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mFieldId:I
    .line 10: if-ne v0, v5, :cond_13
    .line 12: return v2
    .line 13: invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 16: move-result-object v0
    .line 17: invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    .line 20: move-result-object v1
    .line 21: invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I
    .line 24: move-result v0
    .line 25: if-lez v0, :cond_28
    .line 27: return v3
    .line 28: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 30: iget v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 32: invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V
    .line 35: iget-object v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 37: invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I
    .line 40: move-result v0
    .line 41: iget-object v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 43: invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I
    .line 46: move-result v1
    .line 47: iput v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mFieldId:I
    .line 49: iget v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 51: add-int/2addr v1, v0
    .line 52: iput v1, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mNextRead:I
    .line 54: goto :goto_0
    .line 55: iget v0, v4, Landroidx/versionedparcelable/VersionedParcelParcel;->mFieldId:I
    .line 57: if-ne v0, v5, :cond_60
    .line 59: goto :goto_61
    .line 60: const/4 v2, 0
    .line 61: return v2
.end method

# virtual methods
.method public readFloat()F
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public readInt()I
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public readLong()J
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readLong()J
    .line 5: move-result-wide v0
    .line 6: return-wide v0
.end method

# virtual methods
.method public readParcelable()Landroid/os/Parcelable;
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 5: move-result-object v1
    .line 6: invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    .line 9: move-result-object v1
    .line 10: invoke-virtual {v0, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;
    .line 13: move-result-object v0
    .line 14: return-object v0
.end method

# virtual methods
.method public readString()Ljava/lang/String;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public readStrongBinder()Landroid/os/IBinder;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public setOutputField(I)V
    .registers 4

    .line 0: invoke-virtual {v2}, Landroidx/versionedparcelable/VersionedParcelParcel;->closeField()V
    .line 3: iput v3, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mCurrentField:I
    .line 5: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mPositionLookup:Landroid/util/SparseIntArray;
    .line 7: iget-object v1, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 9: invoke-virtual {v1}, Landroid/os/Parcel;->dataPosition()I
    .line 12: move-result v1
    .line 13: invoke-virtual {v0, v3, v1}, Landroid/util/SparseIntArray;->put(II)V
    .line 16: const/4 v0, 0
    .line 17: invoke-virtual {v2, v0}, Landroidx/versionedparcelable/VersionedParcelParcel;->writeInt(I)V
    .line 20: invoke-virtual {v2, v3}, Landroidx/versionedparcelable/VersionedParcelParcel;->writeInt(I)V
    .line 23: return-void
.end method

# virtual methods
.method public writeBoolean(Z)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInt(I)V
    .line 5: return-void
.end method

# virtual methods
.method public writeBundle(Landroid/os/Bundle;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V
    .line 5: return-void
.end method

# virtual methods
.method public writeByteArray([B)V
    .registers 4

    .line 0: if-eqz v3, :cond_14
    .line 2: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 4: array-length v1, v3
    .line 5: invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V
    .line 8: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 10: invoke-virtual {v0, v3}, Landroid/os/Parcel;->writeByteArray([B)V
    .line 13: goto :goto_20
    .line 14: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 16: const/4 v1, -1
    .line 17: invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V
    .line 20: return-void
.end method

# virtual methods
.method public writeByteArray([BII)V
    .registers 6

    .line 0: if-eqz v3, :cond_14
    .line 2: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 4: array-length v1, v3
    .line 5: invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V
    .line 8: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 10: invoke-virtual {v0, v3, v4, v5}, Landroid/os/Parcel;->writeByteArray([BII)V
    .line 13: goto :goto_20
    .line 14: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 16: const/4 v1, -1
    .line 17: invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V
    .line 20: return-void
.end method

# virtual methods
.method protected writeCharSequence(Ljava/lang/CharSequence;)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: const/4 v1, 0
    .line 3: invoke-static {v3, v0, v1}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V
    .line 6: return-void
.end method

# virtual methods
.method public writeDouble(D)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2, v3}, Landroid/os/Parcel;->writeDouble(D)V
    .line 5: return-void
.end method

# virtual methods
.method public writeFloat(F)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeFloat(F)V
    .line 5: return-void
.end method

# virtual methods
.method public writeInt(I)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInt(I)V
    .line 5: return-void
.end method

# virtual methods
.method public writeLong(J)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2, v3}, Landroid/os/Parcel;->writeLong(J)V
    .line 5: return-void
.end method

# virtual methods
.method public writeParcelable(Landroid/os/Parcelable;)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: const/4 v1, 0
    .line 3: invoke-virtual {v0, v3, v1}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V
    .line 6: return-void
.end method

# virtual methods
.method public writeString(Ljava/lang/String;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    .line 5: return-void
.end method

# virtual methods
.method public writeStrongBinder(Landroid/os/IBinder;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    .line 5: return-void
.end method

# virtual methods
.method public writeStrongInterface(Landroid/os/IInterface;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/versionedparcelable/VersionedParcelParcel;->mParcel:Landroid/os/Parcel;
    .line 2: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeStrongInterface(Landroid/os/IInterface;)V
    .line 5: return-void
.end method
