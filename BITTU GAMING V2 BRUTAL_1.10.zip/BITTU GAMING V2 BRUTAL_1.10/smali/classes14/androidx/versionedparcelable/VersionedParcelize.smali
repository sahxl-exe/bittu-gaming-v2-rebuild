.class public abstract annotation interface Landroidx/versionedparcelable/VersionedParcelize;
.super Ljava/lang/Object;
.source "VersionedParcelize.java"
.implements Ljava/lang/annotation/Annotation;

# virtual methods
.method public abstract allowSerialization()Z
.end method

# virtual methods
.method public abstract deprecatedIds()[I
.end method

# virtual methods
.method public abstract factory()Ljava/lang/Class;
.end method

# virtual methods
.method public abstract ignoreParcelables()Z
.end method

# virtual methods
.method public abstract isCustom()Z
.end method

# virtual methods
.method public abstract jetifyAs()Ljava/lang/String;
.end method
