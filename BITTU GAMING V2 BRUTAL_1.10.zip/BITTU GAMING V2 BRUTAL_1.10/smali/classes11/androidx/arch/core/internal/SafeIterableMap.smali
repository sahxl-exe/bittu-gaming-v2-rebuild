.class public Landroidx/arch/core/internal/SafeIterableMap;
.super Ljava/lang/Object;
.source "SafeIterableMap.java"
.implements Ljava/lang/Iterable;

.field private mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
.field private mIterators:Ljava/util/WeakHashMap;
.field private mSize:I
.field  mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;

# direct methods
.method public constructor <init>()V
    .registers 6

    .line 0: move-object v0, v5
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 5: move-object v1, v0
    .line 6: new-instance v2, Ljava/util/WeakHashMap;
    .line 8: move-object v4, v2
    .line 9: move-object v2, v4
    .line 10: move-object v3, v4
    .line 11: invoke-direct {v3}, Ljava/util/WeakHashMap;-><init>()V
    .line 14: iput-object v2, v1, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 16: move-object v1, v0
    .line 17: const/4 v2, 0
    .line 18: iput v2, v1, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 20: return-void
.end method

# virtual methods
.method public descendingIterator()Ljava/util/Iterator;
    .registers 8

    .line 0: move-object v0, v7
    .line 1: new-instance v2, Landroidx/arch/core/internal/SafeIterableMap$DescendingIterator;
    .line 3: move-object v6, v2
    .line 4: move-object v2, v6
    .line 5: move-object v3, v6
    .line 6: move-object v4, v0
    .line 7: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 9: move-object v5, v0
    .line 10: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: invoke-direct {v3, v4, v5}, Landroidx/arch/core/internal/SafeIterableMap$DescendingIterator;-><init>(Landroidx/arch/core/internal/SafeIterableMap$Entry;Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .line 15: move-object v1, v2
    .line 16: move-object v2, v0
    .line 17: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 19: move-object v3, v1
    .line 20: const/4 v4, 0
    .line 21: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 24: move-result-object v4
    .line 25: invoke-virtual {v2, v3, v4}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: move-result-object v2
    .line 29: move-object v2, v1
    .line 30: move-object v0, v2
    .line 31: return-object v0
.end method

# virtual methods
.method public eldest()Ljava/util/Map$Entry;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 4: move-object v0, v1
    .line 5: return-object v0
.end method

# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 11

    .line 0: move-object v0, v9
    .line 1: move-object v1, v10
    .line 2: move-object v7, v1
    .line 3: move-object v8, v0
    .line 4: if-ne v7, v8, :cond_9
    .line 6: const/4 v7, 1
    .line 7: move v0, v7
    .line 8: return v0
    .line 9: move-object v7, v1
    .line 10: instance-of v7, v7, Landroidx/arch/core/internal/SafeIterableMap;
    .line 12: if-nez v7, :cond_17
    .line 14: const/4 v7, 0
    .line 15: move v0, v7
    .line 16: goto :goto_8
    .line 17: move-object v7, v1
    .line 18: check-cast v7, Landroidx/arch/core/internal/SafeIterableMap;
    .line 20: move-object v2, v7
    .line 21: move-object v7, v0
    .line 22: invoke-virtual {v7}, Landroidx/arch/core/internal/SafeIterableMap;->size()I
    .line 25: move-result v7
    .line 26: move-object v8, v2
    .line 27: invoke-virtual {v8}, Landroidx/arch/core/internal/SafeIterableMap;->size()I
    .line 30: move-result v8
    .line 31: if-eq v7, v8, :cond_36
    .line 33: const/4 v7, 0
    .line 34: move v0, v7
    .line 35: goto :goto_8
    .line 36: move-object v7, v0
    .line 37: invoke-virtual {v7}, Landroidx/arch/core/internal/SafeIterableMap;->iterator()Ljava/util/Iterator;
    .line 40: move-result-object v7
    .line 41: move-object v3, v7
    .line 42: move-object v7, v2
    .line 43: invoke-virtual {v7}, Landroidx/arch/core/internal/SafeIterableMap;->iterator()Ljava/util/Iterator;
    .line 46: move-result-object v7
    .line 47: move-object v4, v7
    .line 48: move-object v7, v3
    .line 49: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 52: move-result v7
    .line 53: if-eqz v7, :cond_97
    .line 55: move-object v7, v4
    .line 56: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 59: move-result v7
    .line 60: if-eqz v7, :cond_97
    .line 62: move-object v7, v3
    .line 63: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 66: move-result-object v7
    .line 67: check-cast v7, Ljava/util/Map$Entry;
    .line 69: move-object v5, v7
    .line 70: move-object v7, v4
    .line 71: invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 74: move-result-object v7
    .line 75: move-object v6, v7
    .line 76: move-object v7, v5
    .line 77: if-nez v7, :cond_82
    .line 79: move-object v7, v6
    .line 80: if-nez v7, :cond_93
    .line 82: move-object v7, v5
    .line 83: if-eqz v7, :cond_96
    .line 85: move-object v7, v5
    .line 86: move-object v8, v6
    .line 87: invoke-interface {v7, v8}, Ljava/util/Map$Entry;->equals(Ljava/lang/Object;)Z
    .line 90: move-result v7
    .line 91: if-nez v7, :cond_96
    .line 93: const/4 v7, 0
    .line 94: move v0, v7
    .line 95: goto :goto_8
    .line 96: goto :goto_48
    .line 97: move-object v7, v3
    .line 98: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 101: move-result v7
    .line 102: if-nez v7, :cond_114
    .line 104: move-object v7, v4
    .line 105: invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z
    .line 108: move-result v7
    .line 109: if-nez v7, :cond_114
    .line 111: const/4 v7, 1
    .line 112: move v0, v7
    .line 113: goto :goto_8
    .line 114: const/4 v7, 0
    .line 115: goto :goto_112
.end method

# virtual methods
.method protected get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 7

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v3, v0
    .line 3: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 5: move-object v2, v3
    .line 6: move-object v3, v2
    .line 7: if-eqz v3, :cond_19
    .line 9: move-object v3, v2
    .line 10: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 12: move-object v4, v1
    .line 13: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 16: move-result v3
    .line 17: if-eqz v3, :cond_22
    .line 19: move-object v3, v2
    .line 20: move-object v0, v3
    .line 21: return-object v0
    .line 22: move-object v3, v2
    .line 23: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 25: move-object v2, v3
    .line 26: goto :goto_6
.end method

# virtual methods
.method public hashCode()I
    .registers 6

    .line 0: move-object v0, v5
    .line 1: const/4 v3, 0
    .line 2: move v1, v3
    .line 3: move-object v3, v0
    .line 4: invoke-virtual {v3}, Landroidx/arch/core/internal/SafeIterableMap;->iterator()Ljava/util/Iterator;
    .line 7: move-result-object v3
    .line 8: move-object v2, v3
    .line 9: move-object v3, v2
    .line 10: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 13: move-result v3
    .line 14: if-eqz v3, :cond_31
    .line 16: move v3, v1
    .line 17: move-object v4, v2
    .line 18: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 21: move-result-object v4
    .line 22: check-cast v4, Ljava/util/Map$Entry;
    .line 24: invoke-interface {v4}, Ljava/util/Map$Entry;->hashCode()I
    .line 27: move-result v4
    .line 28: add-int/2addr v3, v4
    .line 29: move v1, v3
    .line 30: goto :goto_9
    .line 31: move v3, v1
    .line 32: move v0, v3
    .line 33: return v0
.end method

# virtual methods
.method public iterator()Ljava/util/Iterator;
    .registers 8

    .line 0: move-object v0, v7
    .line 1: new-instance v2, Landroidx/arch/core/internal/SafeIterableMap$AscendingIterator;
    .line 3: move-object v6, v2
    .line 4: move-object v2, v6
    .line 5: move-object v3, v6
    .line 6: move-object v4, v0
    .line 7: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 9: move-object v5, v0
    .line 10: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: invoke-direct {v3, v4, v5}, Landroidx/arch/core/internal/SafeIterableMap$AscendingIterator;-><init>(Landroidx/arch/core/internal/SafeIterableMap$Entry;Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .line 15: move-object v1, v2
    .line 16: move-object v2, v0
    .line 17: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 19: move-object v3, v1
    .line 20: const/4 v4, 0
    .line 21: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 24: move-result-object v4
    .line 25: invoke-virtual {v2, v3, v4}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 28: move-result-object v2
    .line 29: move-object v2, v1
    .line 30: move-object v0, v2
    .line 31: return-object v0
.end method

# virtual methods
.method public iteratorWithAdditions()Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;
    .registers 7

    .line 0: move-object v0, v6
    .line 1: new-instance v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;
    .line 3: move-object v5, v2
    .line 4: move-object v2, v5
    .line 5: move-object v3, v5
    .line 6: move-object v4, v0
    .line 7: invoke-direct {v3, v4}, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;-><init>(Landroidx/arch/core/internal/SafeIterableMap;)V
    .line 10: move-object v1, v2
    .line 11: move-object v2, v0
    .line 12: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 14: move-object v3, v1
    .line 15: const/4 v4, 0
    .line 16: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    .line 19: move-result-object v4
    .line 20: invoke-virtual {v2, v3, v4}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: move-result-object v2
    .line 24: move-object v2, v1
    .line 25: move-object v0, v2
    .line 26: return-object v0
.end method

# virtual methods
.method public newest()Ljava/util/Map$Entry;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 4: move-object v0, v1
    .line 5: return-object v0
.end method

# virtual methods
.method protected put(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 12

    .line 0: move-object v0, v9
    .line 1: move-object v1, v10
    .line 2: move-object v2, v11
    .line 3: new-instance v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 5: move-object v8, v4
    .line 6: move-object v4, v8
    .line 7: move-object v5, v8
    .line 8: move-object v6, v1
    .line 9: move-object v7, v2
    .line 10: invoke-direct {v5, v6, v7}, Landroidx/arch/core/internal/SafeIterableMap$Entry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .line 13: move-object v3, v4
    .line 14: move-object v4, v0
    .line 15: move-object v8, v4
    .line 16: move-object v4, v8
    .line 17: move-object v5, v8
    .line 18: iget v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 20: const/4 v6, 1
    .line 21: add-int/lit8 v5, v5, 1
    .line 23: iput v5, v4, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 25: move-object v4, v0
    .line 26: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 28: if-nez v4, :cond_43
    .line 30: move-object v4, v0
    .line 31: move-object v5, v3
    .line 32: iput-object v5, v4, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 34: move-object v4, v0
    .line 35: move-object v5, v0
    .line 36: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 38: iput-object v5, v4, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 40: move-object v4, v3
    .line 41: move-object v0, v4
    .line 42: return-object v0
    .line 43: move-object v4, v0
    .line 44: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 46: move-object v5, v3
    .line 47: iput-object v5, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 49: move-object v4, v3
    .line 50: move-object v5, v0
    .line 51: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 53: iput-object v5, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 55: move-object v4, v0
    .line 56: move-object v5, v3
    .line 57: iput-object v5, v4, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 59: move-object v4, v3
    .line 60: move-object v0, v4
    .line 61: goto :goto_42
.end method

# virtual methods
.method public putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0: move-object v0, v7
    .line 1: move-object v1, v8
    .line 2: move-object v2, v9
    .line 3: move-object v4, v0
    .line 4: move-object v5, v1
    .line 5: invoke-virtual {v4, v5}, Landroidx/arch/core/internal/SafeIterableMap;->get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 8: move-result-object v4
    .line 9: move-object v3, v4
    .line 10: move-object v4, v3
    .line 11: if-eqz v4, :cond_18
    .line 13: move-object v4, v3
    .line 14: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 16: move-object v0, v4
    .line 17: return-object v0
    .line 18: move-object v4, v0
    .line 19: move-object v5, v1
    .line 20: move-object v6, v2
    .line 21: invoke-virtual {v4, v5, v6}, Landroidx/arch/core/internal/SafeIterableMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 24: move-result-object v4
    .line 25: const/4 v4, 0
    .line 26: move-object v0, v4
    .line 27: goto :goto_17
.end method

# virtual methods
.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0: move-object v0, v9
    .line 1: move-object v1, v10
    .line 2: move-object v5, v0
    .line 3: move-object v6, v1
    .line 4: invoke-virtual {v5, v6}, Landroidx/arch/core/internal/SafeIterableMap;->get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 7: move-result-object v5
    .line 8: move-object v2, v5
    .line 9: move-object v5, v2
    .line 10: if-nez v5, :cond_15
    .line 12: const/4 v5, 0
    .line 13: move-object v0, v5
    .line 14: return-object v0
    .line 15: move-object v5, v0
    .line 16: move-object v8, v5
    .line 17: move-object v5, v8
    .line 18: move-object v6, v8
    .line 19: iget v6, v6, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 21: const/4 v7, 1
    .line 22: add-int/lit8 v6, v6, -1
    .line 24: iput v6, v5, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 26: move-object v5, v0
    .line 27: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 29: invoke-virtual {v5}, Ljava/util/WeakHashMap;->isEmpty()Z
    .line 32: move-result v5
    .line 33: if-nez v5, :cond_68
    .line 35: move-object v5, v0
    .line 36: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap;->mIterators:Ljava/util/WeakHashMap;
    .line 38: invoke-virtual {v5}, Ljava/util/WeakHashMap;->keySet()Ljava/util/Set;
    .line 41: move-result-object v5
    .line 42: invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 45: move-result-object v5
    .line 46: move-object v3, v5
    .line 47: move-object v5, v3
    .line 48: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    .line 51: move-result v5
    .line 52: if-eqz v5, :cond_68
    .line 54: move-object v5, v3
    .line 55: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 58: move-result-object v5
    .line 59: check-cast v5, Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;
    .line 61: move-object v4, v5
    .line 62: move-object v5, v4
    .line 63: move-object v6, v2
    .line 64: invoke-interface {v5, v6}, Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;->supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .line 67: goto :goto_47
    .line 68: move-object v5, v2
    .line 69: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 71: if-eqz v5, :cond_107
    .line 73: move-object v5, v2
    .line 74: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 76: move-object v6, v2
    .line 77: iget-object v6, v6, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 79: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 81: move-object v5, v2
    .line 82: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 84: if-eqz v5, :cond_114
    .line 86: move-object v5, v2
    .line 87: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 89: move-object v6, v2
    .line 90: iget-object v6, v6, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 92: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 94: move-object v5, v2
    .line 95: const/4 v6, 0
    .line 96: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 98: move-object v5, v2
    .line 99: const/4 v6, 0
    .line 100: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 102: move-object v5, v2
    .line 103: iget-object v5, v5, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 105: move-object v0, v5
    .line 106: goto :goto_14
    .line 107: move-object v5, v0
    .line 108: move-object v6, v2
    .line 109: iget-object v6, v6, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 111: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 113: goto :goto_81
    .line 114: move-object v5, v0
    .line 115: move-object v6, v2
    .line 116: iget-object v6, v6, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 118: iput-object v6, v5, Landroidx/arch/core/internal/SafeIterableMap;->mEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 120: goto :goto_94
.end method

# virtual methods
.method public size()I
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget v1, v1, Landroidx/arch/core/internal/SafeIterableMap;->mSize:I
    .line 4: move v0, v1
    .line 5: return v0
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 7

    .line 0: move-object v0, v6
    .line 1: new-instance v3, Ljava/lang/StringBuilder;
    .line 3: move-object v5, v3
    .line 4: move-object v3, v5
    .line 5: move-object v4, v5
    .line 6: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    .line 9: move-object v1, v3
    .line 10: move-object v3, v1
    .line 11: const-string v4, "["
    .line 13: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 16: move-result-object v3
    .line 17: move-object v3, v0
    .line 18: invoke-virtual {v3}, Landroidx/arch/core/internal/SafeIterableMap;->iterator()Ljava/util/Iterator;
    .line 21: move-result-object v3
    .line 22: move-object v2, v3
    .line 23: move-object v3, v2
    .line 24: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 27: move-result v3
    .line 28: if-eqz v3, :cond_61
    .line 30: move-object v3, v1
    .line 31: move-object v4, v2
    .line 32: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 35: move-result-object v4
    .line 36: check-cast v4, Ljava/util/Map$Entry;
    .line 38: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    .line 41: move-result-object v4
    .line 42: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 45: move-result-object v3
    .line 46: move-object v3, v2
    .line 47: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    .line 50: move-result v3
    .line 51: if-eqz v3, :cond_23
    .line 53: move-object v3, v1
    .line 54: const-string v4, ", "
    .line 56: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 59: move-result-object v3
    .line 60: goto :goto_23
    .line 61: move-object v3, v1
    .line 62: const-string v4, "]"
    .line 64: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 67: move-result-object v3
    .line 68: move-object v3, v1
    .line 69: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 72: move-result-object v3
    .line 73: move-object v0, v3
    .line 74: return-object v0
.end method
