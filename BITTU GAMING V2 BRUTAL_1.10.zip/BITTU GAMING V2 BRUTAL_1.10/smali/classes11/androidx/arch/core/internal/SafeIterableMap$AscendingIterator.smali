.class  Landroidx/arch/core/internal/SafeIterableMap$AscendingIterator;
.super Landroidx/arch/core/internal/SafeIterableMap$ListIterator;
.source "SafeIterableMap.java"

# direct methods
.method constructor <init>(Landroidx/arch/core/internal/SafeIterableMap$Entry;Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .registers 9

    .line 0: move-object v0, v6
    .line 1: move-object v1, v7
    .line 2: move-object v2, v8
    .line 3: move-object v3, v0
    .line 4: move-object v4, v1
    .line 5: move-object v5, v2
    .line 6: invoke-direct {v3, v4, v5}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;-><init>(Landroidx/arch/core/internal/SafeIterableMap$Entry;Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .line 9: return-void
.end method

# virtual methods
.method  backward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 5

    .line 0: move-object v0, v3
    .line 1: move-object v1, v4
    .line 2: move-object v2, v1
    .line 3: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 5: move-object v0, v2
    .line 6: return-object v0
.end method

# virtual methods
.method  forward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 5

    .line 0: move-object v0, v3
    .line 1: move-object v1, v4
    .line 2: move-object v2, v1
    .line 3: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 5: move-object v0, v2
    .line 6: return-object v0
.end method
