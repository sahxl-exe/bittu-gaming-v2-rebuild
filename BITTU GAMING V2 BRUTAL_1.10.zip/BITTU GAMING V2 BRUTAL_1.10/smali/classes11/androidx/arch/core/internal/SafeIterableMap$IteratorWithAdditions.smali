.class  Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;
.super Ljava/lang/Object;
.source "SafeIterableMap.java"
.implements Ljava/util/Iterator;
.implements Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;

.field private mBeforeStart:Z
.field private mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
.field final synthetic this$0:Landroidx/arch/core/internal/SafeIterableMap;

# direct methods
.method constructor <init>(Landroidx/arch/core/internal/SafeIterableMap;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: move-object v3, v1
    .line 4: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->this$0:Landroidx/arch/core/internal/SafeIterableMap;
    .line 6: move-object v2, v0
    .line 7: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 10: move-object v2, v0
    .line 11: const/4 v3, 1
    .line 12: iput-boolean v3, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mBeforeStart:Z
    .line 14: return-void
.end method

# virtual methods
.method public hasNext()Z
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-boolean v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mBeforeStart:Z
    .line 4: if-eqz v1, :cond_18
    .line 6: move-object v1, v0
    .line 7: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->this$0:Landroidx/arch/core/internal/SafeIterableMap;
    .line 9: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 11: if-eqz v1, :cond_16
    .line 13: const/4 v1, 1
    .line 14: move v0, v1
    .line 15: return v0
    .line 16: const/4 v1, 0
    .line 17: goto :goto_14
    .line 18: move-object v1, v0
    .line 19: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 21: if-eqz v1, :cond_33
    .line 23: move-object v1, v0
    .line 24: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 26: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 28: if-eqz v1, :cond_33
    .line 30: const/4 v1, 1
    .line 31: move v0, v1
    .line 32: goto :goto_15
    .line 33: const/4 v1, 0
    .line 34: goto :goto_31
.end method

# virtual methods
.method public bridge synthetic next()Ljava/lang/Object;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: invoke-virtual {v1}, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->next()Ljava/util/Map$Entry;
    .line 5: move-result-object v1
    .line 6: move-object v0, v1
    .line 7: return-object v0
.end method

# virtual methods
.method public next()Ljava/util/Map$Entry;
    .registers 4

    .line 0: move-object v0, v3
    .line 1: move-object v1, v0
    .line 2: iget-boolean v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mBeforeStart:Z
    .line 4: if-eqz v1, :cond_23
    .line 6: move-object v1, v0
    .line 7: const/4 v2, 0
    .line 8: iput-boolean v2, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mBeforeStart:Z
    .line 10: move-object v1, v0
    .line 11: move-object v2, v0
    .line 12: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->this$0:Landroidx/arch/core/internal/SafeIterableMap;
    .line 14: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap;->mStart:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 16: iput-object v2, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 18: move-object v1, v0
    .line 19: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 21: move-object v0, v1
    .line 22: return-object v0
    .line 23: move-object v1, v0
    .line 24: move-object v2, v0
    .line 25: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 27: if-eqz v2, :cond_37
    .line 29: move-object v2, v0
    .line 30: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 32: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 34: iput-object v2, v1, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 36: goto :goto_18
    .line 37: const/4 v2, 0
    .line 38: goto :goto_34
.end method

# virtual methods
.method public supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v1
    .line 3: move-object v3, v0
    .line 4: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 6: if-ne v2, v3, :cond_25
    .line 8: move-object v2, v0
    .line 9: move-object v3, v0
    .line 10: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 14: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 16: move-object v2, v0
    .line 17: move-object v3, v0
    .line 18: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mCurrent:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 20: if-nez v3, :cond_26
    .line 22: const/4 v3, 1
    .line 23: iput-boolean v3, v2, Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;->mBeforeStart:Z
    .line 25: return-void
    .line 26: const/4 v3, 0
    .line 27: goto :goto_23
.end method
