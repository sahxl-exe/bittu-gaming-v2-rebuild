.class  Landroidx/arch/core/internal/SafeIterableMap$Entry;
.super Ljava/lang/Object;
.source "SafeIterableMap.java"
.implements Ljava/util/Map$Entry;

.field final mKey:Ljava/lang/Object;
.field  mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
.field  mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
.field final mValue:Ljava/lang/Object;

# direct methods
.method constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 8

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v2, v7
    .line 3: move-object v3, v0
    .line 4: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 7: move-object v3, v0
    .line 8: move-object v4, v1
    .line 9: iput-object v4, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 11: move-object v3, v0
    .line 12: move-object v4, v2
    .line 13: iput-object v4, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 15: return-void
.end method

# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 7

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v3, v1
    .line 3: move-object v4, v0
    .line 4: if-ne v3, v4, :cond_9
    .line 6: const/4 v3, 1
    .line 7: move v0, v3
    .line 8: return v0
    .line 9: move-object v3, v1
    .line 10: instance-of v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: if-nez v3, :cond_17
    .line 14: const/4 v3, 0
    .line 15: move v0, v3
    .line 16: goto :goto_8
    .line 17: move-object v3, v1
    .line 18: check-cast v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 20: move-object v2, v3
    .line 21: move-object v3, v0
    .line 22: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 24: move-object v4, v2
    .line 25: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 27: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 30: move-result v3
    .line 31: if-eqz v3, :cond_48
    .line 33: move-object v3, v0
    .line 34: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 36: move-object v4, v2
    .line 37: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 39: invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    .line 42: move-result v3
    .line 43: if-eqz v3, :cond_48
    .line 45: const/4 v3, 1
    .line 46: move v0, v3
    .line 47: goto :goto_8
    .line 48: const/4 v3, 0
    .line 49: goto :goto_46
.end method

# virtual methods
.method public getKey()Ljava/lang/Object;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 4: move-object v0, v1
    .line 5: return-object v0
.end method

# virtual methods
.method public getValue()Ljava/lang/Object;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 4: move-object v0, v1
    .line 5: return-object v0
.end method

# virtual methods
.method public hashCode()I
    .registers 4

    .line 0: move-object v0, v3
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 4: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    .line 7: move-result v1
    .line 8: move-object v2, v0
    .line 9: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 11: invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I
    .line 14: move-result v2
    .line 15: xor-int/2addr v1, v2
    .line 16: move v0, v1
    .line 17: return v0
.end method

# virtual methods
.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 0: move-object v0, v6
    .line 1: move-object v1, v7
    .line 2: new-instance v2, Ljava/lang/UnsupportedOperationException;
    .line 4: move-object v5, v2
    .line 5: move-object v2, v5
    .line 6: move-object v3, v5
    .line 7: const-string v4, "An entry modification is not supported"
    .line 9: invoke-direct {v3, v4}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 12: throw v2
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 5

    .line 0: move-object v0, v4
    .line 1: new-instance v1, Ljava/lang/StringBuilder;
    .line 3: move-object v3, v1
    .line 4: move-object v1, v3
    .line 5: move-object v2, v3
    .line 6: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    .line 9: move-object v2, v0
    .line 10: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mKey:Ljava/lang/Object;
    .line 12: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 15: move-result-object v1
    .line 16: const-string v2, "="
    .line 18: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 21: move-result-object v1
    .line 22: move-object v2, v0
    .line 23: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 25: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 28: move-result-object v1
    .line 29: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 32: move-result-object v1
    .line 33: move-object v0, v1
    .line 34: return-object v0
.end method
