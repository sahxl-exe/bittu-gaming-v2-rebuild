.class public Landroidx/arch/core/internal/FastSafeIterableMap;
.super Landroidx/arch/core/internal/SafeIterableMap;
.source "FastSafeIterableMap.java"

.field private mHashMap:Ljava/util/HashMap;

# direct methods
.method public constructor <init>()V
    .registers 6

    .line 0: move-object v0, v5
    .line 1: move-object v1, v0
    .line 2: invoke-direct {v1}, Landroidx/arch/core/internal/SafeIterableMap;-><init>()V
    .line 5: move-object v1, v0
    .line 6: new-instance v2, Ljava/util/HashMap;
    .line 8: move-object v4, v2
    .line 9: move-object v2, v4
    .line 10: move-object v3, v4
    .line 11: invoke-direct {v3}, Ljava/util/HashMap;-><init>()V
    .line 14: iput-object v2, v1, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 16: return-void
.end method

# virtual methods
.method public ceil(Ljava/lang/Object;)Ljava/util/Map$Entry;
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: move-object v3, v1
    .line 4: invoke-virtual {v2, v3}, Landroidx/arch/core/internal/FastSafeIterableMap;->contains(Ljava/lang/Object;)Z
    .line 7: move-result v2
    .line 8: if-eqz v2, :cond_24
    .line 10: move-object v2, v0
    .line 11: iget-object v2, v2, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 13: move-object v3, v1
    .line 14: invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 17: move-result-object v2
    .line 18: check-cast v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 20: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mPrevious:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 22: move-object v0, v2
    .line 23: return-object v0
    .line 24: const/4 v2, 0
    .line 25: move-object v0, v2
    .line 26: goto :goto_23
.end method

# virtual methods
.method public contains(Ljava/lang/Object;)Z
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 5: move-object v3, v1
    .line 6: invoke-virtual {v2, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z
    .line 9: move-result v2
    .line 10: move v0, v2
    .line 11: return v0
.end method

# virtual methods
.method protected get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 6

    .line 0: move-object v0, v4
    .line 1: move-object v1, v5
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 5: move-object v3, v1
    .line 6: invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 9: move-result-object v2
    .line 10: check-cast v2, Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: move-object v0, v2
    .line 13: return-object v0
.end method

# virtual methods
.method public putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 0: move-object v0, v9
    .line 1: move-object v1, v10
    .line 2: move-object v2, v11
    .line 3: move-object v4, v0
    .line 4: move-object v5, v1
    .line 5: invoke-virtual {v4, v5}, Landroidx/arch/core/internal/FastSafeIterableMap;->get(Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 8: move-result-object v4
    .line 9: move-object v3, v4
    .line 10: move-object v4, v3
    .line 11: if-eqz v4, :cond_18
    .line 13: move-object v4, v3
    .line 14: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap$Entry;->mValue:Ljava/lang/Object;
    .line 16: move-object v0, v4
    .line 17: return-object v0
    .line 18: move-object v4, v0
    .line 19: iget-object v4, v4, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 21: move-object v5, v1
    .line 22: move-object v6, v0
    .line 23: move-object v7, v1
    .line 24: move-object v8, v2
    .line 25: invoke-virtual {v6, v7, v8}, Landroidx/arch/core/internal/FastSafeIterableMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 28: move-result-object v6
    .line 29: invoke-virtual {v4, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 32: move-result-object v4
    .line 33: const/4 v4, 0
    .line 34: move-object v0, v4
    .line 35: goto :goto_17
.end method

# virtual methods
.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v3, v0
    .line 3: move-object v4, v1
    .line 4: invoke-super {v3, v4}, Landroidx/arch/core/internal/SafeIterableMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 7: move-result-object v3
    .line 8: move-object v2, v3
    .line 9: move-object v3, v0
    .line 10: iget-object v3, v3, Landroidx/arch/core/internal/FastSafeIterableMap;->mHashMap:Ljava/util/HashMap;
    .line 12: move-object v4, v1
    .line 13: invoke-virtual {v3, v4}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 16: move-result-object v3
    .line 17: move-object v3, v2
    .line 18: move-object v0, v3
    .line 19: return-object v0
.end method
