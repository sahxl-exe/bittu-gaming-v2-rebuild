.class abstract interface Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;
.super Ljava/lang/Object;
.source "SafeIterableMap.java"

# virtual methods
.method public abstract supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
.end method
