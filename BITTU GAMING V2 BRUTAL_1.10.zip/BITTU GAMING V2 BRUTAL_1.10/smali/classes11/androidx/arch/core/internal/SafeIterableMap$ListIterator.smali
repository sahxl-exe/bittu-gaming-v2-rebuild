.class abstract Landroidx/arch/core/internal/SafeIterableMap$ListIterator;
.super Ljava/lang/Object;
.source "SafeIterableMap.java"
.implements Ljava/util/Iterator;
.implements Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;

.field  mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
.field  mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;

# direct methods
.method constructor <init>(Landroidx/arch/core/internal/SafeIterableMap$Entry;Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .registers 8

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v2, v7
    .line 3: move-object v3, v0
    .line 4: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    .line 7: move-object v3, v0
    .line 8: move-object v4, v2
    .line 9: iput-object v4, v3, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 11: move-object v3, v0
    .line 12: move-object v4, v1
    .line 13: iput-object v4, v3, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 15: return-void
.end method

# direct methods
.method private nextNode()Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .registers 4

    .line 0: move-object v0, v3
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 4: move-object v2, v0
    .line 5: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 7: if-eq v1, v2, :cond_14
    .line 9: move-object v1, v0
    .line 10: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: if-nez v1, :cond_17
    .line 14: const/4 v1, 0
    .line 15: move-object v0, v1
    .line 16: return-object v0
    .line 17: move-object v1, v0
    .line 18: move-object v2, v0
    .line 19: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 21: invoke-virtual {v1, v2}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->forward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 24: move-result-object v1
    .line 25: move-object v0, v1
    .line 26: goto :goto_16
.end method

# virtual methods
.method abstract backward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
.end method

# virtual methods
.method abstract forward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
.end method

# virtual methods
.method public hasNext()Z
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: iget-object v1, v1, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 4: if-eqz v1, :cond_9
    .line 6: const/4 v1, 1
    .line 7: move v0, v1
    .line 8: return v0
    .line 9: const/4 v1, 0
    .line 10: goto :goto_7
.end method

# virtual methods
.method public bridge synthetic next()Ljava/lang/Object;
    .registers 3

    .line 0: move-object v0, v2
    .line 1: move-object v1, v0
    .line 2: invoke-virtual {v1}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->next()Ljava/util/Map$Entry;
    .line 5: move-result-object v1
    .line 6: move-object v0, v1
    .line 7: return-object v0
.end method

# virtual methods
.method public next()Ljava/util/Map$Entry;
    .registers 5

    .line 0: move-object v0, v4
    .line 1: move-object v2, v0
    .line 2: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 4: move-object v1, v2
    .line 5: move-object v2, v0
    .line 6: move-object v3, v0
    .line 7: invoke-direct {v3}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->nextNode()Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 10: move-result-object v3
    .line 11: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 13: move-object v2, v1
    .line 14: move-object v0, v2
    .line 15: return-object v0
.end method

# virtual methods
.method public supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
    .registers 7

    .line 0: move-object v0, v5
    .line 1: move-object v1, v6
    .line 2: move-object v2, v0
    .line 3: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 5: move-object v3, v1
    .line 6: if-ne v2, v3, :cond_22
    .line 8: move-object v2, v1
    .line 9: move-object v3, v0
    .line 10: iget-object v3, v3, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 12: if-ne v2, v3, :cond_22
    .line 14: move-object v2, v0
    .line 15: const/4 v3, 0
    .line 16: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 18: move-object v2, v0
    .line 19: const/4 v3, 0
    .line 20: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 22: move-object v2, v0
    .line 23: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 25: move-object v3, v1
    .line 26: if-ne v2, v3, :cond_39
    .line 28: move-object v2, v0
    .line 29: move-object v3, v0
    .line 30: move-object v4, v0
    .line 31: iget-object v4, v4, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 33: invoke-virtual {v3, v4}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->backward(Landroidx/arch/core/internal/SafeIterableMap$Entry;)Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 36: move-result-object v3
    .line 37: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mExpectedEnd:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 39: move-object v2, v0
    .line 40: iget-object v2, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 42: move-object v3, v1
    .line 43: if-ne v2, v3, :cond_53
    .line 45: move-object v2, v0
    .line 46: move-object v3, v0
    .line 47: invoke-direct {v3}, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->nextNode()Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 50: move-result-object v3
    .line 51: iput-object v3, v2, Landroidx/arch/core/internal/SafeIterableMap$ListIterator;->mNext:Landroidx/arch/core/internal/SafeIterableMap$Entry;
    .line 53: return-void
.end method
