.class public abstract interface Landroidx/arch/core/util/Function;
.super Ljava/lang/Object;
.source "Function.java"

# virtual methods
.method public abstract apply(Ljava/lang/Object;)Ljava/lang/Object;
.end method
