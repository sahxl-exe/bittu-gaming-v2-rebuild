.class public abstract interface Landroidx/lifecycle/LifecycleRegistryOwner;
.super Ljava/lang/Object;
.source "LifecycleRegistryOwner.java"
.implements Landroidx/lifecycle/LifecycleOwner;

# virtual methods
.method public abstract getLifecycle()Landroidx/lifecycle/LifecycleRegistry;
.end method
