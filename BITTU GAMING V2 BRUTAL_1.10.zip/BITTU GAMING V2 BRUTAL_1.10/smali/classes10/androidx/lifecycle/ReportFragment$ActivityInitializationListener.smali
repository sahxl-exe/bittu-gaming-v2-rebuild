.class abstract interface Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
.super Ljava/lang/Object;
.source "ReportFragment.java"

# virtual methods
.method public abstract onCreate()V
.end method

# virtual methods
.method public abstract onResume()V
.end method

# virtual methods
.method public abstract onStart()V
.end method
