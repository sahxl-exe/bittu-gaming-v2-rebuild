.class  Landroidx/lifecycle/ReportFragment$LifecycleCallbacks;
.super Ljava/lang/Object;
.source "ReportFragment.java"
.implements Landroid/app/Application$ActivityLifecycleCallbacks;

# direct methods
.method constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method static registerIn(Landroid/app/Activity;)V
    .registers 2

    .line 0: new-instance v0, Landroidx/lifecycle/ReportFragment$LifecycleCallbacks;
    .line 2: invoke-direct {v0}, Landroidx/lifecycle/ReportFragment$LifecycleCallbacks;-><init>()V
    .line 5: invoke-virtual {v1, v0}, Landroid/app/Activity;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    .line 8: return-void
.end method

# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 0: return-void
.end method

# virtual methods
.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 2

    .line 0: return-void
.end method

# virtual methods
.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 2

    .line 0: return-void
.end method

# virtual methods
.method public onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 4

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPostResumed(Landroid/app/Activity;)V
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPostStarted(Landroid/app/Activity;)V
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPreDestroyed(Landroid/app/Activity;)V
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPrePaused(Landroid/app/Activity;)V
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityPreStopped(Landroid/app/Activity;)V
    .registers 3

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: invoke-static {v2, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 5: return-void
.end method

# virtual methods
.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 2

    .line 0: return-void
.end method

# virtual methods
.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 0: return-void
.end method

# virtual methods
.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 2

    .line 0: return-void
.end method

# virtual methods
.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 2

    .line 0: return-void
.end method
