.class public Landroidx/lifecycle/LifecycleRegistry;
.super Landroidx/lifecycle/Lifecycle;
.source "LifecycleRegistry.java"

.field private mAddingObserverCounter:I
.field private final mEnforceMainThread:Z
.field private mHandlingEvent:Z
.field private final mLifecycleOwner:Ljava/lang/ref/WeakReference;
.field private mNewEventOccurred:Z
.field private mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
.field private mParentStates:Ljava/util/ArrayList;
.field private mState:Landroidx/lifecycle/Lifecycle$State;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/LifecycleOwner;)V
    .registers 3

    .line 0: const/4 v0, 1
    .line 1: invoke-direct {v1, v2, v0}, Landroidx/lifecycle/LifecycleRegistry;-><init>(Landroidx/lifecycle/LifecycleOwner;Z)V
    .line 4: return-void
.end method

# direct methods
.method private constructor <init>(Landroidx/lifecycle/LifecycleOwner;Z)V
    .registers 4

    .line 0: invoke-direct {v1}, Landroidx/lifecycle/Lifecycle;-><init>()V
    .line 3: new-instance v0, Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 5: invoke-direct {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 10: const/4 v0, 0
    .line 11: iput v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 13: iput-boolean v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mHandlingEvent:Z
    .line 15: iput-boolean v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 17: new-instance v0, Ljava/util/ArrayList;
    .line 19: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    .line 22: iput-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mParentStates:Ljava/util/ArrayList;
    .line 24: new-instance v0, Ljava/lang/ref/WeakReference;
    .line 26: invoke-direct {v0, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V
    .line 29: iput-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mLifecycleOwner:Ljava/lang/ref/WeakReference;
    .line 31: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->INITIALIZED:Landroidx/lifecycle/Lifecycle$State;
    .line 33: iput-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 35: iput-boolean v3, v1, Landroidx/lifecycle/LifecycleRegistry;->mEnforceMainThread:Z
    .line 37: return-void
.end method

# direct methods
.method private backwardPass(Landroidx/lifecycle/LifecycleOwner;)V
    .registers 9

    .line 0: iget-object v0, v7, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 2: invoke-virtual {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;->descendingIterator()Ljava/util/Iterator;
    .line 5: move-result-object v0
    .line 6: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_104
    .line 12: iget-boolean v1, v7, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 14: if-nez v1, :cond_104
    .line 16: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: check-cast v1, Ljava/util/Map$Entry;
    .line 22: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 25: move-result-object v2
    .line 26: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 28: iget-object v3, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 30: iget-object v4, v7, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 32: invoke-virtual {v3, v4}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 35: move-result v3
    .line 36: if-lez v3, :cond_103
    .line 38: iget-boolean v3, v7, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 40: if-nez v3, :cond_103
    .line 42: iget-object v3, v7, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 44: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 47: move-result-object v4
    .line 48: check-cast v4, Landroidx/lifecycle/LifecycleObserver;
    .line 50: invoke-virtual {v3, v4}, Landroidx/arch/core/internal/FastSafeIterableMap;->contains(Ljava/lang/Object;)Z
    .line 53: move-result v3
    .line 54: if-eqz v3, :cond_103
    .line 56: iget-object v3, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 58: invoke-static {v3}, Landroidx/lifecycle/Lifecycle$Event;->downFrom(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .line 61: move-result-object v3
    .line 62: if-eqz v3, :cond_78
    .line 64: invoke-virtual {v3}, Landroidx/lifecycle/Lifecycle$Event;->getTargetState()Landroidx/lifecycle/Lifecycle$State;
    .line 67: move-result-object v4
    .line 68: invoke-direct {v7, v4}, Landroidx/lifecycle/LifecycleRegistry;->pushParentState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 71: invoke-virtual {v2, v8, v3}, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->dispatchEvent(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 74: invoke-direct {v7}, Landroidx/lifecycle/LifecycleRegistry;->popParentState()V
    .line 77: goto :goto_28
    .line 78: new-instance v4, Ljava/lang/IllegalStateException;
    .line 80: new-instance v5, Ljava/lang/StringBuilder;
    .line 82: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    .line 85: const-string v6, "no event down from "
    .line 87: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 90: iget-object v6, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 92: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 95: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 98: move-result-object v5
    .line 99: invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 102: throw v4
    .line 103: goto :goto_6
    .line 104: return-void
.end method

# direct methods
.method private calculateTargetState(Landroidx/lifecycle/LifecycleObserver;)Landroidx/lifecycle/Lifecycle$State;
    .registers 6

    .line 0: iget-object v0, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 2: invoke-virtual {v0, v5}, Landroidx/arch/core/internal/FastSafeIterableMap;->ceil(Ljava/lang/Object;)Ljava/util/Map$Entry;
    .line 5: move-result-object v0
    .line 6: const/4 v1, 0
    .line 7: if-eqz v0, :cond_18
    .line 9: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 12: move-result-object v2
    .line 13: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 15: iget-object v2, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 17: goto :goto_19
    .line 18: move-object v2, v1
    .line 19: iget-object v3, v4, Landroidx/lifecycle/LifecycleRegistry;->mParentStates:Ljava/util/ArrayList;
    .line 21: invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z
    .line 24: move-result v3
    .line 25: if-nez v3, :cond_42
    .line 27: iget-object v1, v4, Landroidx/lifecycle/LifecycleRegistry;->mParentStates:Ljava/util/ArrayList;
    .line 29: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 32: move-result v3
    .line 33: add-int/lit8 v3, v3, -1
    .line 35: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 38: move-result-object v1
    .line 39: check-cast v1, Landroidx/lifecycle/Lifecycle$State;
    .line 41: goto :goto_43
    .line 42: nop
    .line 43: nop
    .line 44: iget-object v3, v4, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 46: invoke-static {v3, v2}, Landroidx/lifecycle/LifecycleRegistry;->min(Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$State;
    .line 49: move-result-object v3
    .line 50: invoke-static {v3, v1}, Landroidx/lifecycle/LifecycleRegistry;->min(Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$State;
    .line 53: move-result-object v3
    .line 54: return-object v3
.end method

# direct methods
.method public static createUnsafe(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/LifecycleRegistry;
    .registers 3

    .line 0: new-instance v0, Landroidx/lifecycle/LifecycleRegistry;
    .line 2: const/4 v1, 0
    .line 3: invoke-direct {v0, v2, v1}, Landroidx/lifecycle/LifecycleRegistry;-><init>(Landroidx/lifecycle/LifecycleOwner;Z)V
    .line 6: return-object v0
.end method

# direct methods
.method private enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .registers 5

    .line 0: iget-boolean v0, v3, Landroidx/lifecycle/LifecycleRegistry;->mEnforceMainThread:Z
    .line 2: if-eqz v0, :cond_43
    .line 4: invoke-static {}, Landroidx/arch/core/executor/ArchTaskExecutor;->getInstance()Landroidx/arch/core/executor/ArchTaskExecutor;
    .line 7: move-result-object v0
    .line 8: invoke-virtual {v0}, Landroidx/arch/core/executor/ArchTaskExecutor;->isMainThread()Z
    .line 11: move-result v0
    .line 12: if-eqz v0, :cond_15
    .line 14: goto :goto_43
    .line 15: new-instance v0, Ljava/lang/IllegalStateException;
    .line 17: new-instance v1, Ljava/lang/StringBuilder;
    .line 19: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 22: const-string v2, "Method "
    .line 24: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 27: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 30: const-string v2, " must be called on the main thread"
    .line 32: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 35: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 38: move-result-object v1
    .line 39: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 42: throw v0
    .line 43: return-void
.end method

# direct methods
.method private forwardPass(Landroidx/lifecycle/LifecycleOwner;)V
    .registers 9

    .line 0: iget-object v0, v7, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 2: invoke-virtual {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;->iteratorWithAdditions()Landroidx/arch/core/internal/SafeIterableMap$IteratorWithAdditions;
    .line 5: move-result-object v0
    .line 6: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_102
    .line 12: iget-boolean v1, v7, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 14: if-nez v1, :cond_102
    .line 16: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: check-cast v1, Ljava/util/Map$Entry;
    .line 22: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 25: move-result-object v2
    .line 26: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 28: iget-object v3, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 30: iget-object v4, v7, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 32: invoke-virtual {v3, v4}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 35: move-result v3
    .line 36: if-gez v3, :cond_101
    .line 38: iget-boolean v3, v7, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 40: if-nez v3, :cond_101
    .line 42: iget-object v3, v7, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 44: invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 47: move-result-object v4
    .line 48: check-cast v4, Landroidx/lifecycle/LifecycleObserver;
    .line 50: invoke-virtual {v3, v4}, Landroidx/arch/core/internal/FastSafeIterableMap;->contains(Ljava/lang/Object;)Z
    .line 53: move-result v3
    .line 54: if-eqz v3, :cond_101
    .line 56: iget-object v3, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 58: invoke-direct {v7, v3}, Landroidx/lifecycle/LifecycleRegistry;->pushParentState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 61: iget-object v3, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 63: invoke-static {v3}, Landroidx/lifecycle/Lifecycle$Event;->upFrom(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .line 66: move-result-object v3
    .line 67: if-eqz v3, :cond_76
    .line 69: invoke-virtual {v2, v8, v3}, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->dispatchEvent(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 72: invoke-direct {v7}, Landroidx/lifecycle/LifecycleRegistry;->popParentState()V
    .line 75: goto :goto_28
    .line 76: new-instance v4, Ljava/lang/IllegalStateException;
    .line 78: new-instance v5, Ljava/lang/StringBuilder;
    .line 80: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    .line 83: const-string v6, "no event up from "
    .line 85: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 88: iget-object v6, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 90: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 93: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 96: move-result-object v5
    .line 97: invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 100: throw v4
    .line 101: goto :goto_6
    .line 102: return-void
.end method

# direct methods
.method private isSynced()Z
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 2: invoke-virtual {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;->size()I
    .line 5: move-result v0
    .line 6: const/4 v1, 1
    .line 7: if-nez v0, :cond_10
    .line 9: return v1
    .line 10: iget-object v0, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 12: invoke-virtual {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;->eldest()Ljava/util/Map$Entry;
    .line 15: move-result-object v0
    .line 16: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 19: move-result-object v0
    .line 20: check-cast v0, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 22: iget-object v0, v0, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 24: iget-object v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 26: invoke-virtual {v2}, Landroidx/arch/core/internal/FastSafeIterableMap;->newest()Ljava/util/Map$Entry;
    .line 29: move-result-object v2
    .line 30: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 33: move-result-object v2
    .line 34: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 36: iget-object v2, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 38: if-ne v0, v2, :cond_45
    .line 40: iget-object v3, v4, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 42: if-ne v3, v2, :cond_45
    .line 44: goto :goto_46
    .line 45: const/4 v1, 0
    .line 46: return v1
.end method

# direct methods
.method static min(Landroidx/lifecycle/Lifecycle$State;Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$State;
    .registers 3

    .line 0: if-eqz v2, :cond_10
    .line 2: invoke-virtual {v2, v1}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 5: move-result v0
    .line 6: if-gez v0, :cond_10
    .line 8: move-object v0, v2
    .line 9: goto :goto_11
    .line 10: move-object v0, v1
    .line 11: return-object v0
.end method

# direct methods
.method private moveToState(Landroidx/lifecycle/Lifecycle$State;)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 2: if-ne v0, v3, :cond_5
    .line 4: return-void
    .line 5: iput-object v3, v2, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 7: iget-boolean v0, v2, Landroidx/lifecycle/LifecycleRegistry;->mHandlingEvent:Z
    .line 9: const/4 v1, 1
    .line 10: if-nez v0, :cond_26
    .line 12: iget v0, v2, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 14: if-eqz v0, :cond_17
    .line 16: goto :goto_26
    .line 17: iput-boolean v1, v2, Landroidx/lifecycle/LifecycleRegistry;->mHandlingEvent:Z
    .line 19: invoke-direct {v2}, Landroidx/lifecycle/LifecycleRegistry;->sync()V
    .line 22: const/4 v0, 0
    .line 23: iput-boolean v0, v2, Landroidx/lifecycle/LifecycleRegistry;->mHandlingEvent:Z
    .line 25: return-void
    .line 26: iput-boolean v1, v2, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 28: return-void
.end method

# direct methods
.method private popParentState()V
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/lifecycle/LifecycleRegistry;->mParentStates:Ljava/util/ArrayList;
    .line 2: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    .line 5: move-result v1
    .line 6: add-int/lit8 v1, v1, -1
    .line 8: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    .line 11: return-void
.end method

# direct methods
.method private pushParentState(Landroidx/lifecycle/Lifecycle$State;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mParentStates:Ljava/util/ArrayList;
    .line 2: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 5: return-void
.end method

# direct methods
.method private sync()V
    .registers 5

    .line 0: iget-object v0, v4, Landroidx/lifecycle/LifecycleRegistry;->mLifecycleOwner:Ljava/lang/ref/WeakReference;
    .line 2: invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/LifecycleOwner;
    .line 8: if-eqz v0, :cond_79
    .line 10: invoke-direct {v4}, Landroidx/lifecycle/LifecycleRegistry;->isSynced()Z
    .line 13: move-result v1
    .line 14: const/4 v2, 0
    .line 15: if-nez v1, :cond_76
    .line 17: iput-boolean v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 19: iget-object v1, v4, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 21: iget-object v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 23: invoke-virtual {v2}, Landroidx/arch/core/internal/FastSafeIterableMap;->eldest()Ljava/util/Map$Entry;
    .line 26: move-result-object v2
    .line 27: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 30: move-result-object v2
    .line 31: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 33: iget-object v2, v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 35: invoke-virtual {v1, v2}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 38: move-result v1
    .line 39: if-gez v1, :cond_44
    .line 41: invoke-direct {v4, v0}, Landroidx/lifecycle/LifecycleRegistry;->backwardPass(Landroidx/lifecycle/LifecycleOwner;)V
    .line 44: iget-object v1, v4, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 46: invoke-virtual {v1}, Landroidx/arch/core/internal/FastSafeIterableMap;->newest()Ljava/util/Map$Entry;
    .line 49: move-result-object v1
    .line 50: iget-boolean v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 52: if-nez v2, :cond_75
    .line 54: if-eqz v1, :cond_75
    .line 56: iget-object v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 58: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 61: move-result-object v3
    .line 62: check-cast v3, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 64: iget-object v3, v3, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 66: invoke-virtual {v2, v3}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 69: move-result v2
    .line 70: if-lez v2, :cond_75
    .line 72: invoke-direct {v4, v0}, Landroidx/lifecycle/LifecycleRegistry;->forwardPass(Landroidx/lifecycle/LifecycleOwner;)V
    .line 75: goto :goto_10
    .line 76: iput-boolean v2, v4, Landroidx/lifecycle/LifecycleRegistry;->mNewEventOccurred:Z
    .line 78: return-void
    .line 79: new-instance v1, Ljava/lang/IllegalStateException;
    .line 81: const-string v2, "LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state."
    .line 83: invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 86: goto :goto_88
    .line 87: throw v1
    .line 88: goto :goto_87
.end method

# virtual methods
.method public addObserver(Landroidx/lifecycle/LifecycleObserver;)V
    .registers 12

    .line 0: const-string v0, "addObserver"
    .line 2: invoke-direct {v10, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: iget-object v0, v10, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 7: sget-object v1, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;
    .line 9: if-ne v0, v1, :cond_14
    .line 11: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;
    .line 13: goto :goto_16
    .line 14: sget-object v0, Landroidx/lifecycle/Lifecycle$State;->INITIALIZED:Landroidx/lifecycle/Lifecycle$State;
    .line 16: new-instance v1, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 18: invoke-direct {v1, v11, v0}, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;-><init>(Landroidx/lifecycle/LifecycleObserver;Landroidx/lifecycle/Lifecycle$State;)V
    .line 21: iget-object v2, v10, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 23: invoke-virtual {v2, v11, v1}, Landroidx/arch/core/internal/FastSafeIterableMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 26: move-result-object v2
    .line 27: check-cast v2, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;
    .line 29: if-eqz v2, :cond_32
    .line 31: return-void
    .line 32: iget-object v3, v10, Landroidx/lifecycle/LifecycleRegistry;->mLifecycleOwner:Ljava/lang/ref/WeakReference;
    .line 34: invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;
    .line 37: move-result-object v3
    .line 38: check-cast v3, Landroidx/lifecycle/LifecycleOwner;
    .line 40: if-nez v3, :cond_43
    .line 42: return-void
    .line 43: iget v4, v10, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 45: const/4 v5, 1
    .line 46: if-nez v4, :cond_55
    .line 48: iget-boolean v4, v10, Landroidx/lifecycle/LifecycleRegistry;->mHandlingEvent:Z
    .line 50: if-eqz v4, :cond_53
    .line 52: goto :goto_55
    .line 53: const/4 v4, 0
    .line 54: goto :goto_56
    .line 55: const/4 v4, 1
    .line 56: invoke-direct {v10, v11}, Landroidx/lifecycle/LifecycleRegistry;->calculateTargetState(Landroidx/lifecycle/LifecycleObserver;)Landroidx/lifecycle/Lifecycle$State;
    .line 59: move-result-object v6
    .line 60: iget v7, v10, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 62: add-int/2addr v7, v5
    .line 63: iput v7, v10, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 65: iget-object v7, v1, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 67: invoke-virtual {v7, v6}, Landroidx/lifecycle/Lifecycle$State;->compareTo(Ljava/lang/Enum;)I
    .line 70: move-result v7
    .line 71: if-gez v7, :cond_130
    .line 73: iget-object v7, v10, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 75: invoke-virtual {v7, v11}, Landroidx/arch/core/internal/FastSafeIterableMap;->contains(Ljava/lang/Object;)Z
    .line 78: move-result v7
    .line 79: if-eqz v7, :cond_130
    .line 81: iget-object v7, v1, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 83: invoke-direct {v10, v7}, Landroidx/lifecycle/LifecycleRegistry;->pushParentState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 86: iget-object v7, v1, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 88: invoke-static {v7}, Landroidx/lifecycle/Lifecycle$Event;->upFrom(Landroidx/lifecycle/Lifecycle$State;)Landroidx/lifecycle/Lifecycle$Event;
    .line 91: move-result-object v7
    .line 92: if-eqz v7, :cond_105
    .line 94: invoke-virtual {v1, v3, v7}, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->dispatchEvent(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 97: invoke-direct {v10}, Landroidx/lifecycle/LifecycleRegistry;->popParentState()V
    .line 100: invoke-direct {v10, v11}, Landroidx/lifecycle/LifecycleRegistry;->calculateTargetState(Landroidx/lifecycle/LifecycleObserver;)Landroidx/lifecycle/Lifecycle$State;
    .line 103: move-result-object v6
    .line 104: goto :goto_65
    .line 105: new-instance v5, Ljava/lang/IllegalStateException;
    .line 107: new-instance v8, Ljava/lang/StringBuilder;
    .line 109: invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V
    .line 112: const-string v9, "no event up from "
    .line 114: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 117: iget-object v9, v1, Landroidx/lifecycle/LifecycleRegistry$ObserverWithState;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 119: invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 122: invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 125: move-result-object v8
    .line 126: invoke-direct {v5, v8}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 129: throw v5
    .line 130: if-nez v4, :cond_135
    .line 132: invoke-direct {v10}, Landroidx/lifecycle/LifecycleRegistry;->sync()V
    .line 135: iget v7, v10, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 137: sub-int/2addr v7, v5
    .line 138: iput v7, v10, Landroidx/lifecycle/LifecycleRegistry;->mAddingObserverCounter:I
    .line 140: return-void
.end method

# virtual methods
.method public getCurrentState()Landroidx/lifecycle/Lifecycle$State;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mState:Landroidx/lifecycle/Lifecycle$State;
    .line 2: return-object v0
.end method

# virtual methods
.method public getObserverCount()I
    .registers 2

    .line 0: const-string v0, "getObserverCount"
    .line 2: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: iget-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 7: invoke-virtual {v0}, Landroidx/arch/core/internal/FastSafeIterableMap;->size()I
    .line 10: move-result v0
    .line 11: return v0
.end method

# virtual methods
.method public handleLifecycleEvent(Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 3

    .line 0: const-string v0, "handleLifecycleEvent"
    .line 2: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: invoke-virtual {v2}, Landroidx/lifecycle/Lifecycle$Event;->getTargetState()Landroidx/lifecycle/Lifecycle$State;
    .line 8: move-result-object v0
    .line 9: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->moveToState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 12: return-void
.end method

# virtual methods
.method public markState(Landroidx/lifecycle/Lifecycle$State;)V
    .registers 3

    .line 0: const-string v0, "markState"
    .line 2: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: invoke-virtual {v1, v2}, Landroidx/lifecycle/LifecycleRegistry;->setCurrentState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 8: return-void
.end method

# virtual methods
.method public removeObserver(Landroidx/lifecycle/LifecycleObserver;)V
    .registers 3

    .line 0: const-string v0, "removeObserver"
    .line 2: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: iget-object v0, v1, Landroidx/lifecycle/LifecycleRegistry;->mObserverMap:Landroidx/arch/core/internal/FastSafeIterableMap;
    .line 7: invoke-virtual {v0, v2}, Landroidx/arch/core/internal/FastSafeIterableMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 10: return-void
.end method

# virtual methods
.method public setCurrentState(Landroidx/lifecycle/Lifecycle$State;)V
    .registers 3

    .line 0: const-string v0, "setCurrentState"
    .line 2: invoke-direct {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->enforceMainThreadIfNeeded(Ljava/lang/String;)V
    .line 5: invoke-direct {v1, v2}, Landroidx/lifecycle/LifecycleRegistry;->moveToState(Landroidx/lifecycle/Lifecycle$State;)V
    .line 8: return-void
.end method
