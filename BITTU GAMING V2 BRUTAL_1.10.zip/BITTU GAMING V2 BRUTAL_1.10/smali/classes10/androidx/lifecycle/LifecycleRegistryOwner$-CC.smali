.class public final synthetic Landroidx/lifecycle/LifecycleRegistryOwner$-CC;
.super Ljava/lang/Object;
.source "LifecycleRegistryOwner.java"

# direct methods
.method public static bridge synthetic $default$getLifecycle(Landroidx/lifecycle/LifecycleRegistryOwner;)Landroidx/lifecycle/Lifecycle;
    .registers 2

    .line 0: invoke-interface {v1}, Landroidx/lifecycle/LifecycleRegistryOwner;->getLifecycle()Landroidx/lifecycle/LifecycleRegistry;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method
