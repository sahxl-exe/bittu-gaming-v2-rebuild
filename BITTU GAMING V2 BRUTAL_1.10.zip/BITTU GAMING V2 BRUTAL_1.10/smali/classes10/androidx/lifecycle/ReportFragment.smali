.class public Landroidx/lifecycle/ReportFragment;
.super Landroid/app/Fragment;
.source "ReportFragment.java"

.field private static final REPORT_FRAGMENT_TAG:Ljava/lang/String;

.field private mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroid/app/Fragment;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method static dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 4

    .line 0: instance-of v0, v2, Landroidx/lifecycle/LifecycleRegistryOwner;
    .line 2: if-eqz v0, :cond_15
    .line 4: move-object v0, v2
    .line 5: check-cast v0, Landroidx/lifecycle/LifecycleRegistryOwner;
    .line 7: invoke-interface {v0}, Landroidx/lifecycle/LifecycleRegistryOwner;->getLifecycle()Landroidx/lifecycle/LifecycleRegistry;
    .line 10: move-result-object v0
    .line 11: invoke-virtual {v0, v3}, Landroidx/lifecycle/LifecycleRegistry;->handleLifecycleEvent(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 14: return-void
    .line 15: instance-of v0, v2, Landroidx/lifecycle/LifecycleOwner;
    .line 17: if-eqz v0, :cond_36
    .line 19: move-object v0, v2
    .line 20: check-cast v0, Landroidx/lifecycle/LifecycleOwner;
    .line 22: invoke-interface {v0}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;
    .line 25: move-result-object v0
    .line 26: instance-of v1, v0, Landroidx/lifecycle/LifecycleRegistry;
    .line 28: if-eqz v1, :cond_36
    .line 30: move-object v1, v0
    .line 31: check-cast v1, Landroidx/lifecycle/LifecycleRegistry;
    .line 33: invoke-virtual {v1, v3}, Landroidx/lifecycle/LifecycleRegistry;->handleLifecycleEvent(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 36: return-void
.end method

# direct methods
.method private dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 4

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 29
    .line 4: if-ge v0, v1, :cond_13
    .line 6: invoke-virtual {v2}, Landroidx/lifecycle/ReportFragment;->getActivity()Landroid/app/Activity;
    .line 9: move-result-object v0
    .line 10: invoke-static {v0, v3}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroid/app/Activity;Landroidx/lifecycle/Lifecycle$Event;)V
    .line 13: return-void
.end method

# direct methods
.method private dispatchCreate(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .registers 2

    .line 0: if-eqz v1, :cond_5
    .line 2: invoke-interface {v1}, Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;->onCreate()V
    .line 5: return-void
.end method

# direct methods
.method private dispatchResume(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .registers 2

    .line 0: if-eqz v1, :cond_5
    .line 2: invoke-interface {v1}, Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;->onResume()V
    .line 5: return-void
.end method

# direct methods
.method private dispatchStart(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .registers 2

    .line 0: if-eqz v1, :cond_5
    .line 2: invoke-interface {v1}, Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;->onStart()V
    .line 5: return-void
.end method

# direct methods
.method static get(Landroid/app/Activity;)Landroidx/lifecycle/ReportFragment;
    .registers 3

    .line 0: invoke-virtual {v2}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;
    .line 3: move-result-object v0
    .line 4: const-string v1, "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag"
    .line 6: invoke-virtual {v0, v1}, Landroid/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroid/app/Fragment;
    .line 9: move-result-object v0
    .line 10: check-cast v0, Landroidx/lifecycle/ReportFragment;
    .line 12: return-object v0
.end method

# direct methods
.method public static injectIfNeededIn(Landroid/app/Activity;)V
    .registers 5

    .line 0: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 2: const/16 v1, 29
    .line 4: if-lt v0, v1, :cond_9
    .line 6: invoke-static {v4}, Landroidx/lifecycle/ReportFragment$LifecycleCallbacks;->registerIn(Landroid/app/Activity;)V
    .line 9: invoke-virtual {v4}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;
    .line 12: move-result-object v0
    .line 13: const-string v1, "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag"
    .line 15: invoke-virtual {v0, v1}, Landroid/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroid/app/Fragment;
    .line 18: move-result-object v2
    .line 19: if-nez v2, :cond_40
    .line 21: invoke-virtual {v0}, Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;
    .line 24: move-result-object v2
    .line 25: new-instance v3, Landroidx/lifecycle/ReportFragment;
    .line 27: invoke-direct {v3}, Landroidx/lifecycle/ReportFragment;-><init>()V
    .line 30: invoke-virtual {v2, v3, v1}, Landroid/app/FragmentTransaction;->add(Landroid/app/Fragment;Ljava/lang/String;)Landroid/app/FragmentTransaction;
    .line 33: move-result-object v1
    .line 34: invoke-virtual {v1}, Landroid/app/FragmentTransaction;->commit()I
    .line 37: invoke-virtual {v0}, Landroid/app/FragmentManager;->executePendingTransactions()Z
    .line 40: return-void
.end method

# virtual methods
.method public onActivityCreated(Landroid/os/Bundle;)V
    .registers 3

    .line 0: invoke-super {v1, v2}, Landroid/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    .line 3: iget-object v0, v1, Landroidx/lifecycle/ReportFragment;->mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatchCreate(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .line 8: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;
    .line 10: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 13: return-void
.end method

# virtual methods
.method public onDestroy()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onDestroy()V
    .line 3: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 8: const/4 v0, 0
    .line 9: iput-object v0, v1, Landroidx/lifecycle/ReportFragment;->mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
    .line 11: return-void
.end method

# virtual methods
.method public onPause()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onPause()V
    .line 3: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 8: return-void
.end method

# virtual methods
.method public onResume()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onResume()V
    .line 3: iget-object v0, v1, Landroidx/lifecycle/ReportFragment;->mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatchResume(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .line 8: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .line 10: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 13: return-void
.end method

# virtual methods
.method public onStart()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onStart()V
    .line 3: iget-object v0, v1, Landroidx/lifecycle/ReportFragment;->mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatchStart(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .line 8: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 10: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 13: return-void
.end method

# virtual methods
.method public onStop()V
    .registers 2

    .line 0: invoke-super {v1}, Landroid/app/Fragment;->onStop()V
    .line 3: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;
    .line 5: invoke-direct {v1, v0}, Landroidx/lifecycle/ReportFragment;->dispatch(Landroidx/lifecycle/Lifecycle$Event;)V
    .line 8: return-void
.end method

# virtual methods
.method  setProcessListener(Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;)V
    .registers 2

    .line 0: iput-object v1, v0, Landroidx/lifecycle/ReportFragment;->mProcessListener:Landroidx/lifecycle/ReportFragment$ActivityInitializationListener;
    .line 2: return-void
.end method
