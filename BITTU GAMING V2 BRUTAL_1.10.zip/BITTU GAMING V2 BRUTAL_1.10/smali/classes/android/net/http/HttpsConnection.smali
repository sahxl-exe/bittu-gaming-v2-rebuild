.class public Landroid/net/http/HttpsConnection;
.super Landroid/net/http/Connection;
.source "HttpsConnection.java"

.field protected mCertificate:Landroid/net/http/SslCertificate;
.field protected mHttpClientConnection:Landroid/net/http/AndroidHttpClientConnection;

# direct methods
.method constructor <init>()V
    .registers 4

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Landroid/content/Context;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Lorg/apache/http/HttpHost;
    .line 7: check-cast v1, Landroid/net/http/RequestFeeder;
    .line 9: invoke-direct {v3, v0, v2, v1}, Landroid/net/http/Connection;-><init>(Landroid/content/Context;Lorg/apache/http/HttpHost;Landroid/net/http/RequestFeeder;)V
    .line 12: new-instance v0, Ljava/lang/RuntimeException;
    .line 14: const-string v1, "Stub!"
    .line 16: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 19: throw v0
.end method

# direct methods
.method public static initializeEngine(Ljava/io/File;)V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public bridge synthetic toString()Ljava/lang/String;
    .registers 2

    .line 0: invoke-super {v1}, Landroid/net/http/Connection;->toString()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: return-object v0
.end method
