.class public Landroid/net/http/RequestQueue;
.super Ljava/lang/Object;
.source "RequestQueue.java"
.implements Landroid/net/http/RequestFeeder;

# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public declared-synchronized disablePlatformNotifications()V
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized enablePlatformNotifications()V
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public getProxyHost()Lorg/apache/http/HttpHost;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public declared-synchronized getRequest()Landroid/net/http/Request;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getRequest(Lorg/apache/http/HttpHost;)Landroid/net/http/Request;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized haveRequest(Lorg/apache/http/HttpHost;)Z
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public queueRequest(Ljava/lang/String;Landroid/net/compatibility/WebAddress;Ljava/lang/String;Ljava/util/Map;Landroid/net/http/EventHandler;Ljava/io/InputStream;I)Landroid/net/http/RequestHandle;
    .registers 10

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public queueRequest(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Landroid/net/http/EventHandler;Ljava/io/InputStream;I)Landroid/net/http/RequestHandle;
    .registers 9

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected declared-synchronized queueRequest(Landroid/net/http/Request;Z)V
    .registers 5

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public queueSynchronousRequest(Ljava/lang/String;Landroid/net/compatibility/WebAddress;Ljava/lang/String;Ljava/util/Map;Landroid/net/http/EventHandler;Ljava/io/InputStream;I)Landroid/net/http/RequestHandle;
    .registers 10

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public requeueRequest(Landroid/net/http/Request;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public shutdown()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public startTiming()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public stopTiming()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
