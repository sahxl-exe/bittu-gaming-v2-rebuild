.class public abstract interface Landroid/net/http/EventHandler;
.super Ljava/lang/Object;
.source "EventHandler.java"

.field public static final ERROR:I
.field public static final ERROR_AUTH:I
.field public static final ERROR_BAD_URL:I
.field public static final ERROR_CONNECT:I
.field public static final ERROR_FAILED_SSL_HANDSHAKE:I
.field public static final ERROR_IO:I
.field public static final ERROR_LOOKUP:I
.field public static final ERROR_PROXYAUTH:I
.field public static final ERROR_REDIRECT_LOOP:I
.field public static final ERROR_TIMEOUT:I
.field public static final ERROR_UNSUPPORTED_AUTH_SCHEME:I
.field public static final ERROR_UNSUPPORTED_SCHEME:I
.field public static final FILE_ERROR:I
.field public static final FILE_NOT_FOUND_ERROR:I
.field public static final OK:I
.field public static final TOO_MANY_REQUESTS_ERROR:I

# virtual methods
.method public abstract certificate(Landroid/net/http/SslCertificate;)V
.end method

# virtual methods
.method public abstract data([BI)V
.end method

# virtual methods
.method public abstract endData()V
.end method

# virtual methods
.method public abstract error(ILjava/lang/String;)V
.end method

# virtual methods
.method public abstract handleSslErrorRequest(Landroid/net/http/SslError;)Z
.end method

# virtual methods
.method public abstract headers(Landroid/net/http/Headers;)V
.end method

# virtual methods
.method public abstract status(IIILjava/lang/String;)V
.end method
