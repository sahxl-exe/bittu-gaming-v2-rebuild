.class public Landroid/net/http/SslError;
.super Ljava/lang/Object;
.source "SslError.java"

.field public static final SSL_DATE_INVALID:I
.field public static final SSL_EXPIRED:I
.field public static final SSL_IDMISMATCH:I
.field public static final SSL_INVALID:I
.field public static final SSL_MAX_ERROR:I
.field public static final SSL_NOTYETVALID:I
.field public static final SSL_UNTRUSTED:I

# direct methods
.method public constructor <init>(ILandroid/net/http/SslCertificate;)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public constructor <init>(ILandroid/net/http/SslCertificate;Ljava/lang/String;)V
    .registers 6

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public constructor <init>(ILjava/security/cert/X509Certificate;)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public constructor <init>(ILjava/security/cert/X509Certificate;Ljava/lang/String;)V
    .registers 6

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public addError(I)Z
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getCertificate()Landroid/net/http/SslCertificate;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getPrimaryError()I
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getUrl()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public hasError(I)Z
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public toString()Ljava/lang/String;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
