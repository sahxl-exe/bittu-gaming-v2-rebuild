.class abstract Landroid/net/http/Connection;
.super Ljava/lang/Object;
.source "Connection.java"

.field protected mCertificate:Landroid/net/http/SslCertificate;
.field protected mHttpClientConnection:Landroid/net/http/AndroidHttpClientConnection;

# direct methods
.method protected constructor <init>(Landroid/content/Context;Lorg/apache/http/HttpHost;Landroid/net/http/RequestFeeder;)V
    .registers 6

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public declared-synchronized toString()Ljava/lang/String;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method
