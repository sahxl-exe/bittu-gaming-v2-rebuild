.class public abstract interface Landroid/net/http/Headers$HeaderCallback;
.super Ljava/lang/Object;
.source "Headers.java"

# virtual methods
.method public abstract header(Ljava/lang/String;Ljava/lang/String;)V
.end method
