.class public Lorg/apache/commons/codec/DecoderException;
.super Ljava/lang/Exception;
.source "DecoderException.java"

# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 4

    .line 0: invoke-direct {v2}, Ljava/lang/Exception;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method
