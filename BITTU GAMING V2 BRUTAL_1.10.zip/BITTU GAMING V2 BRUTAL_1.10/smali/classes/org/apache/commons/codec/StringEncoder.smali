.class public abstract interface Lorg/apache/commons/codec/StringEncoder;
.super Ljava/lang/Object;
.source "StringEncoder.java"
.implements Lorg/apache/commons/codec/Encoder;

# virtual methods
.method public abstract encode(Ljava/lang/String;)Ljava/lang/String;
.end method
