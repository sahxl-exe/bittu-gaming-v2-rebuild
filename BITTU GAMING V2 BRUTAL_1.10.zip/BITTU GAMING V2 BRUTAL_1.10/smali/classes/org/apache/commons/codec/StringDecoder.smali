.class public abstract interface Lorg/apache/commons/codec/StringDecoder;
.super Ljava/lang/Object;
.source "StringDecoder.java"
.implements Lorg/apache/commons/codec/Decoder;

# virtual methods
.method public abstract decode(Ljava/lang/String;)Ljava/lang/String;
.end method
