.class public abstract interface Lorg/apache/commons/codec/BinaryEncoder;
.super Ljava/lang/Object;
.source "BinaryEncoder.java"
.implements Lorg/apache/commons/codec/Encoder;

# virtual methods
.method public abstract encode([B)[B
.end method
