.class public abstract interface Lorg/apache/commons/logging/Log;
.super Ljava/lang/Object;
.source "Log.java"

# virtual methods
.method public abstract debug(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract debug(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract error(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract error(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract fatal(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract fatal(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract info(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract info(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract isDebugEnabled()Z
.end method

# virtual methods
.method public abstract isErrorEnabled()Z
.end method

# virtual methods
.method public abstract isFatalEnabled()Z
.end method

# virtual methods
.method public abstract isInfoEnabled()Z
.end method

# virtual methods
.method public abstract isTraceEnabled()Z
.end method

# virtual methods
.method public abstract isWarnEnabled()Z
.end method

# virtual methods
.method public abstract trace(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract trace(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method

# virtual methods
.method public abstract warn(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract warn(Ljava/lang/Object;Ljava/lang/Throwable;)V
.end method
