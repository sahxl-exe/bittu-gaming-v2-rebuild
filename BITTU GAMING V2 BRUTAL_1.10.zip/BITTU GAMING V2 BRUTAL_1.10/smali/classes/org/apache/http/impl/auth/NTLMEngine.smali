.class public abstract interface Lorg/apache/http/impl/auth/NTLMEngine;
.super Ljava/lang/Object;
.source "NTLMEngine.java"

# virtual methods
.method public abstract generateType1Msg(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method

# virtual methods
.method public abstract generateType3Msg(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
.end method
