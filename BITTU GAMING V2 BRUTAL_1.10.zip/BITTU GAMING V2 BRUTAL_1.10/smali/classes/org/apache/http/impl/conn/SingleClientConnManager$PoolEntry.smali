.class public Lorg/apache/http/impl/conn/SingleClientConnManager$PoolEntry;
.super Lorg/apache/http/impl/conn/AbstractPoolEntry;
.source "SingleClientConnManager.java"

.field final synthetic this$0:Lorg/apache/http/impl/conn/SingleClientConnManager;

# direct methods
.method protected constructor <init>(Lorg/apache/http/impl/conn/SingleClientConnManager;)V
    .registers 4

    .line 0: const/4 v1, 0
    .line 1: iput-object v3, v2, Lorg/apache/http/impl/conn/SingleClientConnManager$PoolEntry;->this$0:Lorg/apache/http/impl/conn/SingleClientConnManager;
    .line 3: move-object v0, v1
    .line 4: check-cast v0, Lorg/apache/http/conn/ClientConnectionOperator;
    .line 6: check-cast v1, Lorg/apache/http/conn/routing/HttpRoute;
    .line 8: invoke-direct {v2, v0, v1}, Lorg/apache/http/impl/conn/AbstractPoolEntry;-><init>(Lorg/apache/http/conn/ClientConnectionOperator;Lorg/apache/http/conn/routing/HttpRoute;)V
    .line 11: new-instance v0, Ljava/lang/RuntimeException;
    .line 13: const-string v1, "Stub!"
    .line 15: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 18: throw v0
.end method

# virtual methods
.method protected close()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected shutdown()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
