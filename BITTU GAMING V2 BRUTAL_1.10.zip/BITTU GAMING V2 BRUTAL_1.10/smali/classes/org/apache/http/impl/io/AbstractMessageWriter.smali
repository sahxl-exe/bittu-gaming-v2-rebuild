.class public abstract Lorg/apache/http/impl/io/AbstractMessageWriter;
.super Ljava/lang/Object;
.source "AbstractMessageWriter.java"
.implements Lorg/apache/http/io/HttpMessageWriter;

.field protected final lineBuf:Lorg/apache/http/util/CharArrayBuffer;
.field protected final lineFormatter:Lorg/apache/http/message/LineFormatter;
.field protected final sessionBuffer:Lorg/apache/http/io/SessionOutputBuffer;

# direct methods
.method public constructor <init>(Lorg/apache/http/io/SessionOutputBuffer;Lorg/apache/http/message/LineFormatter;Lorg/apache/http/params/HttpParams;)V
    .registers 6

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public write(Lorg/apache/http/HttpMessage;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected abstract writeHeadLine(Lorg/apache/http/HttpMessage;)V
.end method
