.class public abstract interface Lorg/apache/http/impl/conn/tsccm/RefQueueHandler;
.super Ljava/lang/Object;
.source "RefQueueHandler.java"

# virtual methods
.method public abstract handleReference(Ljava/lang/ref/Reference;)V
.end method
