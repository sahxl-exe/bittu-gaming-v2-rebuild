.class public Lorg/apache/http/impl/client/DefaultHttpRequestRetryHandler;
.super Ljava/lang/Object;
.source "DefaultHttpRequestRetryHandler.java"
.implements Lorg/apache/http/client/HttpRequestRetryHandler;

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public constructor <init>(IZ)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public getRetryCount()I
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public isRequestSentRetryEnabled()Z
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public retryRequest(Ljava/io/IOException;ILorg/apache/http/protocol/HttpContext;)Z
    .registers 6

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
