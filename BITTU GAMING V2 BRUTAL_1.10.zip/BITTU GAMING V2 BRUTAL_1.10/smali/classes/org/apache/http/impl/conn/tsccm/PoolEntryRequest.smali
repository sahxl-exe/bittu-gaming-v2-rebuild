.class public abstract interface Lorg/apache/http/impl/conn/tsccm/PoolEntryRequest;
.super Ljava/lang/Object;
.source "PoolEntryRequest.java"

# virtual methods
.method public abstract abortRequest()V
.end method

# virtual methods
.method public abstract getPoolEntry(JLjava/util/concurrent/TimeUnit;)Lorg/apache/http/impl/conn/tsccm/BasicPoolEntry;
.end method
