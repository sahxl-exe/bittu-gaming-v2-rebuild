.class public Lorg/apache/http/impl/conn/tsccm/ThreadSafeClientConnManager;
.super Ljava/lang/Object;
.source "ThreadSafeClientConnManager.java"
.implements Lorg/apache/http/conn/ClientConnectionManager;

.field protected connOperator:Lorg/apache/http/conn/ClientConnectionOperator;
.field protected final connectionPool:Lorg/apache/http/impl/conn/tsccm/AbstractConnPool;
.field protected schemeRegistry:Lorg/apache/http/conn/scheme/SchemeRegistry;

# direct methods
.method public constructor <init>(Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/scheme/SchemeRegistry;)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public closeExpiredConnections()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public closeIdleConnections(JLjava/util/concurrent/TimeUnit;)V
    .registers 6

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected createConnectionOperator(Lorg/apache/http/conn/scheme/SchemeRegistry;)Lorg/apache/http/conn/ClientConnectionOperator;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected createConnectionPool(Lorg/apache/http/params/HttpParams;)Lorg/apache/http/impl/conn/tsccm/AbstractConnPool;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected finalize()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getConnectionsInPool()I
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getConnectionsInPool(Lorg/apache/http/conn/routing/HttpRoute;)I
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getSchemeRegistry()Lorg/apache/http/conn/scheme/SchemeRegistry;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public releaseConnection(Lorg/apache/http/conn/ManagedClientConnection;JLjava/util/concurrent/TimeUnit;)V
    .registers 7

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public requestConnection(Lorg/apache/http/conn/routing/HttpRoute;Ljava/lang/Object;)Lorg/apache/http/conn/ClientConnectionRequest;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public shutdown()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
