.class public abstract Lorg/apache/http/impl/auth/AuthSchemeBase;
.super Ljava/lang/Object;
.source "AuthSchemeBase.java"
.implements Lorg/apache/http/auth/AuthScheme;

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public isProxy()Z
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected abstract parseChallenge(Lorg/apache/http/util/CharArrayBuffer;II)V
.end method

# virtual methods
.method public processChallenge(Lorg/apache/http/Header;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
