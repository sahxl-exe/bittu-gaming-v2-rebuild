.class public abstract Lorg/apache/http/impl/client/AbstractHttpClient;
.super Ljava/lang/Object;
.source "AbstractHttpClient.java"
.implements Lorg/apache/http/client/HttpClient;

# direct methods
.method protected constructor <init>(Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/params/HttpParams;)V
    .registers 5

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public declared-synchronized addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;I)V
    .registers 5

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;I)V
    .registers 5

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized clearRequestInterceptors()V
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized clearResponseInterceptors()V
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method protected abstract createAuthSchemeRegistry()Lorg/apache/http/auth/AuthSchemeRegistry;
.end method

# virtual methods
.method protected abstract createClientConnectionManager()Lorg/apache/http/conn/ClientConnectionManager;
.end method

# virtual methods
.method protected createClientRequestDirector(Lorg/apache/http/protocol/HttpRequestExecutor;Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/ConnectionReuseStrategy;Lorg/apache/http/conn/ConnectionKeepAliveStrategy;Lorg/apache/http/conn/routing/HttpRoutePlanner;Lorg/apache/http/protocol/HttpProcessor;Lorg/apache/http/client/HttpRequestRetryHandler;Lorg/apache/http/client/RedirectHandler;Lorg/apache/http/client/AuthenticationHandler;Lorg/apache/http/client/AuthenticationHandler;Lorg/apache/http/client/UserTokenHandler;Lorg/apache/http/params/HttpParams;)Lorg/apache/http/client/RequestDirector;
    .registers 15

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected abstract createConnectionKeepAliveStrategy()Lorg/apache/http/conn/ConnectionKeepAliveStrategy;
.end method

# virtual methods
.method protected abstract createConnectionReuseStrategy()Lorg/apache/http/ConnectionReuseStrategy;
.end method

# virtual methods
.method protected abstract createCookieSpecRegistry()Lorg/apache/http/cookie/CookieSpecRegistry;
.end method

# virtual methods
.method protected abstract createCookieStore()Lorg/apache/http/client/CookieStore;
.end method

# virtual methods
.method protected abstract createCredentialsProvider()Lorg/apache/http/client/CredentialsProvider;
.end method

# virtual methods
.method protected abstract createHttpContext()Lorg/apache/http/protocol/HttpContext;
.end method

# virtual methods
.method protected abstract createHttpParams()Lorg/apache/http/params/HttpParams;
.end method

# virtual methods
.method protected abstract createHttpProcessor()Lorg/apache/http/protocol/BasicHttpProcessor;
.end method

# virtual methods
.method protected abstract createHttpRequestRetryHandler()Lorg/apache/http/client/HttpRequestRetryHandler;
.end method

# virtual methods
.method protected abstract createHttpRoutePlanner()Lorg/apache/http/conn/routing/HttpRoutePlanner;
.end method

# virtual methods
.method protected abstract createProxyAuthenticationHandler()Lorg/apache/http/client/AuthenticationHandler;
.end method

# virtual methods
.method protected abstract createRedirectHandler()Lorg/apache/http/client/RedirectHandler;
.end method

# virtual methods
.method protected abstract createRequestExecutor()Lorg/apache/http/protocol/HttpRequestExecutor;
.end method

# virtual methods
.method protected abstract createTargetAuthenticationHandler()Lorg/apache/http/client/AuthenticationHandler;
.end method

# virtual methods
.method protected abstract createUserTokenHandler()Lorg/apache/http/client/UserTokenHandler;
.end method

# virtual methods
.method protected determineParams(Lorg/apache/http/HttpRequest;)Lorg/apache/http/params/HttpParams;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;
    .registers 6

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;
    .registers 7

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;)Ljava/lang/Object;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/client/ResponseHandler;Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;
    .registers 6

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public final execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    .registers 6

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public final execute(Lorg/apache/http/client/methods/HttpUriRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public final declared-synchronized getAuthSchemes()Lorg/apache/http/auth/AuthSchemeRegistry;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getConnectionKeepAliveStrategy()Lorg/apache/http/conn/ConnectionKeepAliveStrategy;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getConnectionManager()Lorg/apache/http/conn/ClientConnectionManager;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getConnectionReuseStrategy()Lorg/apache/http/ConnectionReuseStrategy;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getCookieSpecs()Lorg/apache/http/cookie/CookieSpecRegistry;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getCookieStore()Lorg/apache/http/client/CookieStore;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getCredentialsProvider()Lorg/apache/http/client/CredentialsProvider;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method protected final declared-synchronized getHttpProcessor()Lorg/apache/http/protocol/BasicHttpProcessor;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getHttpRequestRetryHandler()Lorg/apache/http/client/HttpRequestRetryHandler;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getParams()Lorg/apache/http/params/HttpParams;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getProxyAuthenticationHandler()Lorg/apache/http/client/AuthenticationHandler;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getRedirectHandler()Lorg/apache/http/client/RedirectHandler;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getRequestExecutor()Lorg/apache/http/protocol/HttpRequestExecutor;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getRequestInterceptor(I)Lorg/apache/http/HttpRequestInterceptor;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getRequestInterceptorCount()I
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getResponseInterceptor(I)Lorg/apache/http/HttpResponseInterceptor;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getResponseInterceptorCount()I
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getRoutePlanner()Lorg/apache/http/conn/routing/HttpRoutePlanner;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getTargetAuthenticationHandler()Lorg/apache/http/client/AuthenticationHandler;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public final declared-synchronized getUserTokenHandler()Lorg/apache/http/client/UserTokenHandler;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public removeRequestInterceptorByClass(Ljava/lang/Class;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public removeResponseInterceptorByClass(Ljava/lang/Class;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public declared-synchronized setAuthSchemes(Lorg/apache/http/auth/AuthSchemeRegistry;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setCookieSpecs(Lorg/apache/http/cookie/CookieSpecRegistry;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setCookieStore(Lorg/apache/http/client/CookieStore;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setCredentialsProvider(Lorg/apache/http/client/CredentialsProvider;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setHttpRequestRetryHandler(Lorg/apache/http/client/HttpRequestRetryHandler;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setKeepAliveStrategy(Lorg/apache/http/conn/ConnectionKeepAliveStrategy;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setParams(Lorg/apache/http/params/HttpParams;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setProxyAuthenticationHandler(Lorg/apache/http/client/AuthenticationHandler;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setRedirectHandler(Lorg/apache/http/client/RedirectHandler;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setReuseStrategy(Lorg/apache/http/ConnectionReuseStrategy;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setRoutePlanner(Lorg/apache/http/conn/routing/HttpRoutePlanner;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setTargetAuthenticationHandler(Lorg/apache/http/client/AuthenticationHandler;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setUserTokenHandler(Lorg/apache/http/client/UserTokenHandler;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method
