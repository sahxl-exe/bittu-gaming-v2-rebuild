.class public Lorg/apache/http/impl/io/HttpResponseWriter;
.super Lorg/apache/http/impl/io/AbstractMessageWriter;
.source "HttpResponseWriter.java"

# direct methods
.method public constructor <init>(Lorg/apache/http/io/SessionOutputBuffer;Lorg/apache/http/message/LineFormatter;Lorg/apache/http/params/HttpParams;)V
    .registers 7

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Lorg/apache/http/io/SessionOutputBuffer;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Lorg/apache/http/message/LineFormatter;
    .line 7: check-cast v1, Lorg/apache/http/params/HttpParams;
    .line 9: invoke-direct {v3, v0, v2, v1}, Lorg/apache/http/impl/io/AbstractMessageWriter;-><init>(Lorg/apache/http/io/SessionOutputBuffer;Lorg/apache/http/message/LineFormatter;Lorg/apache/http/params/HttpParams;)V
    .line 12: new-instance v0, Ljava/lang/RuntimeException;
    .line 14: const-string v1, "Stub!"
    .line 16: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 19: throw v0
.end method

# virtual methods
.method protected writeHeadLine(Lorg/apache/http/HttpMessage;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
