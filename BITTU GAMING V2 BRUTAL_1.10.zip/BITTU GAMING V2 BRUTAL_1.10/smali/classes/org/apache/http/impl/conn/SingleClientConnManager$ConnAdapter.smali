.class public Lorg/apache/http/impl/conn/SingleClientConnManager$ConnAdapter;
.super Lorg/apache/http/impl/conn/AbstractPooledConnAdapter;
.source "SingleClientConnManager.java"

.field final synthetic this$0:Lorg/apache/http/impl/conn/SingleClientConnManager;

# direct methods
.method protected constructor <init>(Lorg/apache/http/impl/conn/SingleClientConnManager;Lorg/apache/http/impl/conn/SingleClientConnManager$PoolEntry;Lorg/apache/http/conn/routing/HttpRoute;)V
    .registers 6

    .line 0: const/4 v1, 0
    .line 1: iput-object v3, v2, Lorg/apache/http/impl/conn/SingleClientConnManager$ConnAdapter;->this$0:Lorg/apache/http/impl/conn/SingleClientConnManager;
    .line 3: move-object v0, v1
    .line 4: check-cast v0, Lorg/apache/http/conn/ClientConnectionManager;
    .line 6: check-cast v1, Lorg/apache/http/impl/conn/AbstractPoolEntry;
    .line 8: invoke-direct {v2, v0, v1}, Lorg/apache/http/impl/conn/AbstractPooledConnAdapter;-><init>(Lorg/apache/http/conn/ClientConnectionManager;Lorg/apache/http/impl/conn/AbstractPoolEntry;)V
    .line 11: new-instance v0, Ljava/lang/RuntimeException;
    .line 13: const-string v1, "Stub!"
    .line 15: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 18: throw v0
.end method
