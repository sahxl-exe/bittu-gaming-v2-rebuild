.class public abstract interface Lorg/apache/http/HeaderIterator;
.super Ljava/lang/Object;
.source "HeaderIterator.java"
.implements Ljava/util/Iterator;

# virtual methods
.method public abstract hasNext()Z
.end method

# virtual methods
.method public abstract nextHeader()Lorg/apache/http/Header;
.end method
