.class public abstract interface Lorg/apache/http/message/HeaderValueFormatter;
.super Ljava/lang/Object;
.source "HeaderValueFormatter.java"

# virtual methods
.method public abstract formatElements(Lorg/apache/http/util/CharArrayBuffer;[Lorg/apache/http/HeaderElement;Z)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatHeaderElement(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/HeaderElement;Z)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatNameValuePair(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/NameValuePair;Z)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatParameters(Lorg/apache/http/util/CharArrayBuffer;[Lorg/apache/http/NameValuePair;Z)Lorg/apache/http/util/CharArrayBuffer;
.end method
