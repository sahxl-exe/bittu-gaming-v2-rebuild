.class public abstract interface Lorg/apache/http/message/LineParser;
.super Ljava/lang/Object;
.source "LineParser.java"

# virtual methods
.method public abstract hasProtocolVersion(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Z
.end method

# virtual methods
.method public abstract parseHeader(Lorg/apache/http/util/CharArrayBuffer;)Lorg/apache/http/Header;
.end method

# virtual methods
.method public abstract parseProtocolVersion(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Lorg/apache/http/ProtocolVersion;
.end method

# virtual methods
.method public abstract parseRequestLine(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Lorg/apache/http/RequestLine;
.end method

# virtual methods
.method public abstract parseStatusLine(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Lorg/apache/http/StatusLine;
.end method
