.class public abstract interface Lorg/apache/http/message/HeaderValueParser;
.super Ljava/lang/Object;
.source "HeaderValueParser.java"

# virtual methods
.method public abstract parseElements(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)[Lorg/apache/http/HeaderElement;
.end method

# virtual methods
.method public abstract parseHeaderElement(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Lorg/apache/http/HeaderElement;
.end method

# virtual methods
.method public abstract parseNameValuePair(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)Lorg/apache/http/NameValuePair;
.end method

# virtual methods
.method public abstract parseParameters(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/message/ParserCursor;)[Lorg/apache/http/NameValuePair;
.end method
