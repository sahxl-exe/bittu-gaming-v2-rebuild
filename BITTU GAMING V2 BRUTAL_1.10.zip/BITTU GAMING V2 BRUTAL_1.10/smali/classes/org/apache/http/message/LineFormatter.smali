.class public abstract interface Lorg/apache/http/message/LineFormatter;
.super Ljava/lang/Object;
.source "LineFormatter.java"

# virtual methods
.method public abstract appendProtocolVersion(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/ProtocolVersion;)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatHeader(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/Header;)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatRequestLine(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/RequestLine;)Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract formatStatusLine(Lorg/apache/http/util/CharArrayBuffer;Lorg/apache/http/StatusLine;)Lorg/apache/http/util/CharArrayBuffer;
.end method
