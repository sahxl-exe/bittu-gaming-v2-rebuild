.class public final Lorg/apache/http/client/params/AuthPolicy;
.super Ljava/lang/Object;
.source "AuthPolicy.java"

.field public static final BASIC:Ljava/lang/String;
.field public static final DIGEST:Ljava/lang/String;
.field public static final NTLM:Ljava/lang/String;

# direct methods
.method constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method
