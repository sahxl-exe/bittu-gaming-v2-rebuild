.class public abstract interface Lorg/apache/http/client/methods/AbortableHttpRequest;
.super Ljava/lang/Object;
.source "AbortableHttpRequest.java"

# virtual methods
.method public abstract abort()V
.end method

# virtual methods
.method public abstract setConnectionRequest(Lorg/apache/http/conn/ClientConnectionRequest;)V
.end method

# virtual methods
.method public abstract setReleaseTrigger(Lorg/apache/http/conn/ConnectionReleaseTrigger;)V
.end method
