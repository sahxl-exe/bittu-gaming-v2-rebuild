.class public abstract interface Lorg/apache/http/client/HttpRequestRetryHandler;
.super Ljava/lang/Object;
.source "HttpRequestRetryHandler.java"

# virtual methods
.method public abstract retryRequest(Ljava/io/IOException;ILorg/apache/http/protocol/HttpContext;)Z
.end method
