.class public final Lorg/apache/http/client/params/CookiePolicy;
.super Ljava/lang/Object;
.source "CookiePolicy.java"

.field public static final BEST_MATCH:Ljava/lang/String;
.field public static final BROWSER_COMPATIBILITY:Ljava/lang/String;
.field public static final NETSCAPE:Ljava/lang/String;
.field public static final RFC_2109:Ljava/lang/String;
.field public static final RFC_2965:Ljava/lang/String;

# direct methods
.method constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method
