.class public abstract interface Lorg/apache/http/client/RequestDirector;
.super Ljava/lang/Object;
.source "RequestDirector.java"

# virtual methods
.method public abstract execute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
.end method
