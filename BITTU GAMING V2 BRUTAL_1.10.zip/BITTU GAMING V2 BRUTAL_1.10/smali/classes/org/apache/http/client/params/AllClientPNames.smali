.class public abstract interface Lorg/apache/http/client/params/AllClientPNames;
.super Ljava/lang/Object;
.source "AllClientPNames.java"
.implements Lorg/apache/http/params/CoreConnectionPNames;
.implements Lorg/apache/http/params/CoreProtocolPNames;
.implements Lorg/apache/http/client/params/ClientPNames;
.implements Lorg/apache/http/auth/params/AuthPNames;
.implements Lorg/apache/http/cookie/params/CookieSpecPNames;
.implements Lorg/apache/http/conn/params/ConnConnectionPNames;
.implements Lorg/apache/http/conn/params/ConnManagerPNames;
.implements Lorg/apache/http/conn/params/ConnRoutePNames;
