.class public Lorg/apache/http/client/entity/UrlEncodedFormEntity;
.super Lorg/apache/http/entity/StringEntity;
.source "UrlEncodedFormEntity.java"

# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: check-cast v0, Ljava/lang/String;
    .line 3: invoke-direct {v2, v0}, Lorg/apache/http/entity/StringEntity;-><init>(Ljava/lang/String;)V
    .line 6: new-instance v0, Ljava/lang/RuntimeException;
    .line 8: const-string v1, "Stub!"
    .line 10: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 13: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/String;)V
    .registers 5

    .line 0: const/4 v0, 0
    .line 1: check-cast v0, Ljava/lang/String;
    .line 3: invoke-direct {v2, v0}, Lorg/apache/http/entity/StringEntity;-><init>(Ljava/lang/String;)V
    .line 6: new-instance v0, Ljava/lang/RuntimeException;
    .line 8: const-string v1, "Stub!"
    .line 10: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 13: throw v0
.end method
