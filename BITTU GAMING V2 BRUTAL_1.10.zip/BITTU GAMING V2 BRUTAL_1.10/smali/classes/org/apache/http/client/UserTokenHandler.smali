.class public abstract interface Lorg/apache/http/client/UserTokenHandler;
.super Ljava/lang/Object;
.source "UserTokenHandler.java"

# virtual methods
.method public abstract getUserToken(Lorg/apache/http/protocol/HttpContext;)Ljava/lang/Object;
.end method
