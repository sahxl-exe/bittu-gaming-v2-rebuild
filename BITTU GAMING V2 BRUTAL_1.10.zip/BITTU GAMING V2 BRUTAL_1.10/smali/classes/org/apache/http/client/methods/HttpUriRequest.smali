.class public abstract interface Lorg/apache/http/client/methods/HttpUriRequest;
.super Ljava/lang/Object;
.source "HttpUriRequest.java"
.implements Lorg/apache/http/HttpRequest;

# virtual methods
.method public abstract abort()V
.end method

# virtual methods
.method public abstract getMethod()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getURI()Ljava/net/URI;
.end method

# virtual methods
.method public abstract isAborted()Z
.end method
