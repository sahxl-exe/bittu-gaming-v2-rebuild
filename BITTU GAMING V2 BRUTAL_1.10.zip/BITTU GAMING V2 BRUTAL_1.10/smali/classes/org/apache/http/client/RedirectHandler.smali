.class public abstract interface Lorg/apache/http/client/RedirectHandler;
.super Ljava/lang/Object;
.source "RedirectHandler.java"

# virtual methods
.method public abstract getLocationURI(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Ljava/net/URI;
.end method

# virtual methods
.method public abstract isRedirectRequested(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Z
.end method
