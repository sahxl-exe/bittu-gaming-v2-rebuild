.class public abstract interface Lorg/apache/http/client/ResponseHandler;
.super Ljava/lang/Object;
.source "ResponseHandler.java"

# virtual methods
.method public abstract handleResponse(Lorg/apache/http/HttpResponse;)Ljava/lang/Object;
.end method
