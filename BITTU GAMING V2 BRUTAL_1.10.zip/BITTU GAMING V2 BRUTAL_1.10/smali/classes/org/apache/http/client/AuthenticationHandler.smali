.class public abstract interface Lorg/apache/http/client/AuthenticationHandler;
.super Ljava/lang/Object;
.source "AuthenticationHandler.java"

# virtual methods
.method public abstract getChallenges(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Ljava/util/Map;
.end method

# virtual methods
.method public abstract isAuthenticationRequested(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Z
.end method

# virtual methods
.method public abstract selectScheme(Ljava/util/Map;Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/auth/AuthScheme;
.end method
