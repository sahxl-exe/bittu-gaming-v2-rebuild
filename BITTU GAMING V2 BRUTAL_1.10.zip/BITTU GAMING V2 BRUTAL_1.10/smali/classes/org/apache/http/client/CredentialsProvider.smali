.class public abstract interface Lorg/apache/http/client/CredentialsProvider;
.super Ljava/lang/Object;
.source "CredentialsProvider.java"

# virtual methods
.method public abstract clear()V
.end method

# virtual methods
.method public abstract getCredentials(Lorg/apache/http/auth/AuthScope;)Lorg/apache/http/auth/Credentials;
.end method

# virtual methods
.method public abstract setCredentials(Lorg/apache/http/auth/AuthScope;Lorg/apache/http/auth/Credentials;)V
.end method
