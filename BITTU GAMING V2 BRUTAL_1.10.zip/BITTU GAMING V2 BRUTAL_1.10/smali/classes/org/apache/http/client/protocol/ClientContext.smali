.class public abstract interface Lorg/apache/http/client/protocol/ClientContext;
.super Ljava/lang/Object;
.source "ClientContext.java"

.field public static final AUTHSCHEME_REGISTRY:Ljava/lang/String;
.field public static final AUTH_SCHEME_PREF:Ljava/lang/String;
.field public static final COOKIESPEC_REGISTRY:Ljava/lang/String;
.field public static final COOKIE_ORIGIN:Ljava/lang/String;
.field public static final COOKIE_SPEC:Ljava/lang/String;
.field public static final COOKIE_STORE:Ljava/lang/String;
.field public static final CREDS_PROVIDER:Ljava/lang/String;
.field public static final PROXY_AUTH_STATE:Ljava/lang/String;
.field public static final TARGET_AUTH_STATE:Ljava/lang/String;
.field public static final USER_TOKEN:Ljava/lang/String;
