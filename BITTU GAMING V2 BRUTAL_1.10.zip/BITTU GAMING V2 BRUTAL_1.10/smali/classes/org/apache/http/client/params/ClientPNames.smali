.class public abstract interface Lorg/apache/http/client/params/ClientPNames;
.super Ljava/lang/Object;
.source "ClientPNames.java"

.field public static final ALLOW_CIRCULAR_REDIRECTS:Ljava/lang/String;
.field public static final CONNECTION_MANAGER_FACTORY:Ljava/lang/String;
.field public static final CONNECTION_MANAGER_FACTORY_CLASS_NAME:Ljava/lang/String;
.field public static final COOKIE_POLICY:Ljava/lang/String;
.field public static final DEFAULT_HEADERS:Ljava/lang/String;
.field public static final DEFAULT_HOST:Ljava/lang/String;
.field public static final HANDLE_AUTHENTICATION:Ljava/lang/String;
.field public static final HANDLE_REDIRECTS:Ljava/lang/String;
.field public static final MAX_REDIRECTS:Ljava/lang/String;
.field public static final REJECT_RELATIVE_REDIRECT:Ljava/lang/String;
.field public static final VIRTUAL_HOST:Ljava/lang/String;
