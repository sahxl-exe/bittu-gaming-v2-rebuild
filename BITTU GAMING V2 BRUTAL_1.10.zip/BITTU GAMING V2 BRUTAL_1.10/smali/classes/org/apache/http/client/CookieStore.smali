.class public abstract interface Lorg/apache/http/client/CookieStore;
.super Ljava/lang/Object;
.source "CookieStore.java"

# virtual methods
.method public abstract addCookie(Lorg/apache/http/cookie/Cookie;)V
.end method

# virtual methods
.method public abstract clear()V
.end method

# virtual methods
.method public abstract clearExpired(Ljava/util/Date;)Z
.end method

# virtual methods
.method public abstract getCookies()Ljava/util/List;
.end method
