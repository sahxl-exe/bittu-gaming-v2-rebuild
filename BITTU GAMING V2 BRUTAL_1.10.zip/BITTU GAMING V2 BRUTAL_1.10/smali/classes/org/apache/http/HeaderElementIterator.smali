.class public abstract interface Lorg/apache/http/HeaderElementIterator;
.super Ljava/lang/Object;
.source "HeaderElementIterator.java"
.implements Ljava/util/Iterator;

# virtual methods
.method public abstract hasNext()Z
.end method

# virtual methods
.method public abstract nextElement()Lorg/apache/http/HeaderElement;
.end method
