.class public abstract interface Lorg/apache/http/StatusLine;
.super Ljava/lang/Object;
.source "StatusLine.java"

# virtual methods
.method public abstract getProtocolVersion()Lorg/apache/http/ProtocolVersion;
.end method

# virtual methods
.method public abstract getReasonPhrase()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getStatusCode()I
.end method
