.class public abstract interface Lorg/apache/http/HttpEntityEnclosingRequest;
.super Ljava/lang/Object;
.source "HttpEntityEnclosingRequest.java"
.implements Lorg/apache/http/HttpRequest;

# virtual methods
.method public abstract expectContinue()Z
.end method

# virtual methods
.method public abstract getEntity()Lorg/apache/http/HttpEntity;
.end method

# virtual methods
.method public abstract setEntity(Lorg/apache/http/HttpEntity;)V
.end method
