.class public abstract interface Lorg/apache/http/HttpResponse;
.super Ljava/lang/Object;
.source "HttpResponse.java"
.implements Lorg/apache/http/HttpMessage;

# virtual methods
.method public abstract getEntity()Lorg/apache/http/HttpEntity;
.end method

# virtual methods
.method public abstract getLocale()Ljava/util/Locale;
.end method

# virtual methods
.method public abstract getStatusLine()Lorg/apache/http/StatusLine;
.end method

# virtual methods
.method public abstract setEntity(Lorg/apache/http/HttpEntity;)V
.end method

# virtual methods
.method public abstract setLocale(Ljava/util/Locale;)V
.end method

# virtual methods
.method public abstract setReasonPhrase(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setStatusCode(I)V
.end method

# virtual methods
.method public abstract setStatusLine(Lorg/apache/http/ProtocolVersion;I)V
.end method

# virtual methods
.method public abstract setStatusLine(Lorg/apache/http/ProtocolVersion;ILjava/lang/String;)V
.end method

# virtual methods
.method public abstract setStatusLine(Lorg/apache/http/StatusLine;)V
.end method
