.class public abstract interface Lorg/apache/http/cookie/SetCookie;
.super Ljava/lang/Object;
.source "SetCookie.java"
.implements Lorg/apache/http/cookie/Cookie;

# virtual methods
.method public abstract setComment(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setDomain(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setExpiryDate(Ljava/util/Date;)V
.end method

# virtual methods
.method public abstract setPath(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setSecure(Z)V
.end method

# virtual methods
.method public abstract setValue(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setVersion(I)V
.end method
