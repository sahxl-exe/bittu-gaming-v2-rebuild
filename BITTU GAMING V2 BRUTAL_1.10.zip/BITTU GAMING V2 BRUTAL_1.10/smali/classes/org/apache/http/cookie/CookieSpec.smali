.class public abstract interface Lorg/apache/http/cookie/CookieSpec;
.super Ljava/lang/Object;
.source "CookieSpec.java"

# virtual methods
.method public abstract formatCookies(Ljava/util/List;)Ljava/util/List;
.end method

# virtual methods
.method public abstract getVersion()I
.end method

# virtual methods
.method public abstract getVersionHeader()Lorg/apache/http/Header;
.end method

# virtual methods
.method public abstract match(Lorg/apache/http/cookie/Cookie;Lorg/apache/http/cookie/CookieOrigin;)Z
.end method

# virtual methods
.method public abstract parse(Lorg/apache/http/Header;Lorg/apache/http/cookie/CookieOrigin;)Ljava/util/List;
.end method

# virtual methods
.method public abstract validate(Lorg/apache/http/cookie/Cookie;Lorg/apache/http/cookie/CookieOrigin;)V
.end method
