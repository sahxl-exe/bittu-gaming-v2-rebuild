.class public abstract interface Lorg/apache/http/cookie/params/CookieSpecPNames;
.super Ljava/lang/Object;
.source "CookieSpecPNames.java"

.field public static final DATE_PATTERNS:Ljava/lang/String;
.field public static final SINGLE_COOKIE_HEADER:Ljava/lang/String;
