.class public abstract interface Lorg/apache/http/cookie/Cookie;
.super Ljava/lang/Object;
.source "Cookie.java"

# virtual methods
.method public abstract getComment()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getCommentURL()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getDomain()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getExpiryDate()Ljava/util/Date;
.end method

# virtual methods
.method public abstract getName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getPath()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getPorts()[I
.end method

# virtual methods
.method public abstract getValue()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getVersion()I
.end method

# virtual methods
.method public abstract isExpired(Ljava/util/Date;)Z
.end method

# virtual methods
.method public abstract isPersistent()Z
.end method

# virtual methods
.method public abstract isSecure()Z
.end method
