.class public abstract interface Lorg/apache/http/cookie/SM;
.super Ljava/lang/Object;
.source "SM.java"

.field public static final COOKIE:Ljava/lang/String;
.field public static final COOKIE2:Ljava/lang/String;
.field public static final SET_COOKIE:Ljava/lang/String;
.field public static final SET_COOKIE2:Ljava/lang/String;
