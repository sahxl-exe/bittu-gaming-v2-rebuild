.class public abstract interface Lorg/apache/http/cookie/ClientCookie;
.super Ljava/lang/Object;
.source "ClientCookie.java"
.implements Lorg/apache/http/cookie/Cookie;

.field public static final COMMENTURL_ATTR:Ljava/lang/String;
.field public static final COMMENT_ATTR:Ljava/lang/String;
.field public static final DISCARD_ATTR:Ljava/lang/String;
.field public static final DOMAIN_ATTR:Ljava/lang/String;
.field public static final EXPIRES_ATTR:Ljava/lang/String;
.field public static final MAX_AGE_ATTR:Ljava/lang/String;
.field public static final PATH_ATTR:Ljava/lang/String;
.field public static final PORT_ATTR:Ljava/lang/String;
.field public static final SECURE_ATTR:Ljava/lang/String;
.field public static final VERSION_ATTR:Ljava/lang/String;

# virtual methods
.method public abstract containsAttribute(Ljava/lang/String;)Z
.end method

# virtual methods
.method public abstract getAttribute(Ljava/lang/String;)Ljava/lang/String;
.end method
