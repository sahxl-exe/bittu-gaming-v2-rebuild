.class public abstract interface Lorg/apache/http/cookie/SetCookie2;
.super Ljava/lang/Object;
.source "SetCookie2.java"
.implements Lorg/apache/http/cookie/SetCookie;

# virtual methods
.method public abstract setCommentURL(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract setDiscard(Z)V
.end method

# virtual methods
.method public abstract setPorts([I)V
.end method
