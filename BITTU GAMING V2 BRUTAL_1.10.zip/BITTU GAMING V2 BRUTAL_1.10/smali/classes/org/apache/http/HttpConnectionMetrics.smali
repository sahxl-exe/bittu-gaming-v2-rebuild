.class public abstract interface Lorg/apache/http/HttpConnectionMetrics;
.super Ljava/lang/Object;
.source "HttpConnectionMetrics.java"

# virtual methods
.method public abstract getMetric(Ljava/lang/String;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract getReceivedBytesCount()J
.end method

# virtual methods
.method public abstract getRequestCount()J
.end method

# virtual methods
.method public abstract getResponseCount()J
.end method

# virtual methods
.method public abstract getSentBytesCount()J
.end method

# virtual methods
.method public abstract reset()V
.end method
