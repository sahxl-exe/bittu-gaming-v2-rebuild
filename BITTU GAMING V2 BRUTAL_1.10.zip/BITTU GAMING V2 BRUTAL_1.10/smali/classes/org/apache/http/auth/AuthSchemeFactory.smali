.class public abstract interface Lorg/apache/http/auth/AuthSchemeFactory;
.super Ljava/lang/Object;
.source "AuthSchemeFactory.java"

# virtual methods
.method public abstract newInstance(Lorg/apache/http/params/HttpParams;)Lorg/apache/http/auth/AuthScheme;
.end method
