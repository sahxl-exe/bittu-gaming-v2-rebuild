.class public abstract interface Lorg/apache/http/auth/Credentials;
.super Ljava/lang/Object;
.source "Credentials.java"

# virtual methods
.method public abstract getPassword()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getUserPrincipal()Ljava/security/Principal;
.end method
