.class public abstract interface Lorg/apache/http/auth/params/AuthPNames;
.super Ljava/lang/Object;
.source "AuthPNames.java"

.field public static final CREDENTIAL_CHARSET:Ljava/lang/String;
