.class public abstract interface Lorg/apache/http/auth/AuthScheme;
.super Ljava/lang/Object;
.source "AuthScheme.java"

# virtual methods
.method public abstract authenticate(Lorg/apache/http/auth/Credentials;Lorg/apache/http/HttpRequest;)Lorg/apache/http/Header;
.end method

# virtual methods
.method public abstract getParameter(Ljava/lang/String;)Ljava/lang/String;
.end method

# virtual methods
.method public abstract getRealm()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getSchemeName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract isComplete()Z
.end method

# virtual methods
.method public abstract isConnectionBased()Z
.end method

# virtual methods
.method public abstract processChallenge(Lorg/apache/http/Header;)V
.end method
