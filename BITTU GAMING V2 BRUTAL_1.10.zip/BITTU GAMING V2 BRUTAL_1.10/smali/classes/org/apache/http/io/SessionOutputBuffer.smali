.class public abstract interface Lorg/apache/http/io/SessionOutputBuffer;
.super Ljava/lang/Object;
.source "SessionOutputBuffer.java"

# virtual methods
.method public abstract flush()V
.end method

# virtual methods
.method public abstract getMetrics()Lorg/apache/http/io/HttpTransportMetrics;
.end method

# virtual methods
.method public abstract write(I)V
.end method

# virtual methods
.method public abstract write([B)V
.end method

# virtual methods
.method public abstract write([BII)V
.end method

# virtual methods
.method public abstract writeLine(Ljava/lang/String;)V
.end method

# virtual methods
.method public abstract writeLine(Lorg/apache/http/util/CharArrayBuffer;)V
.end method
