.class public abstract interface Lorg/apache/http/io/HttpMessageParser;
.super Ljava/lang/Object;
.source "HttpMessageParser.java"

# virtual methods
.method public abstract parse()Lorg/apache/http/HttpMessage;
.end method
