.class public abstract interface Lorg/apache/http/io/HttpTransportMetrics;
.super Ljava/lang/Object;
.source "HttpTransportMetrics.java"

# virtual methods
.method public abstract getBytesTransferred()J
.end method

# virtual methods
.method public abstract reset()V
.end method
