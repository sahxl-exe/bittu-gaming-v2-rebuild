.class public abstract interface Lorg/apache/http/io/HttpMessageWriter;
.super Ljava/lang/Object;
.source "HttpMessageWriter.java"

# virtual methods
.method public abstract write(Lorg/apache/http/HttpMessage;)V
.end method
