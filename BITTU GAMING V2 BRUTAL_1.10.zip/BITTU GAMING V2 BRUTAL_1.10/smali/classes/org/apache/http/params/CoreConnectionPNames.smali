.class public abstract interface Lorg/apache/http/params/CoreConnectionPNames;
.super Ljava/lang/Object;
.source "CoreConnectionPNames.java"

.field public static final CONNECTION_TIMEOUT:Ljava/lang/String;
.field public static final MAX_HEADER_COUNT:Ljava/lang/String;
.field public static final MAX_LINE_LENGTH:Ljava/lang/String;
.field public static final SOCKET_BUFFER_SIZE:Ljava/lang/String;
.field public static final SO_LINGER:Ljava/lang/String;
.field public static final SO_TIMEOUT:Ljava/lang/String;
.field public static final STALE_CONNECTION_CHECK:Ljava/lang/String;
.field public static final TCP_NODELAY:Ljava/lang/String;
