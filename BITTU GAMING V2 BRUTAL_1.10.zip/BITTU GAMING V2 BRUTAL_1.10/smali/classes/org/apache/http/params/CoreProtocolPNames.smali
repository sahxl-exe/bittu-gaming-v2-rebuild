.class public abstract interface Lorg/apache/http/params/CoreProtocolPNames;
.super Ljava/lang/Object;
.source "CoreProtocolPNames.java"

.field public static final HTTP_CONTENT_CHARSET:Ljava/lang/String;
.field public static final HTTP_ELEMENT_CHARSET:Ljava/lang/String;
.field public static final ORIGIN_SERVER:Ljava/lang/String;
.field public static final PROTOCOL_VERSION:Ljava/lang/String;
.field public static final STRICT_TRANSFER_ENCODING:Ljava/lang/String;
.field public static final USER_AGENT:Ljava/lang/String;
.field public static final USE_EXPECT_CONTINUE:Ljava/lang/String;
.field public static final WAIT_FOR_CONTINUE:Ljava/lang/String;
