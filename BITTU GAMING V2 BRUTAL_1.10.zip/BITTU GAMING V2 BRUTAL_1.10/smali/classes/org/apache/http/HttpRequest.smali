.class public abstract interface Lorg/apache/http/HttpRequest;
.super Ljava/lang/Object;
.source "HttpRequest.java"
.implements Lorg/apache/http/HttpMessage;

# virtual methods
.method public abstract getRequestLine()Lorg/apache/http/RequestLine;
.end method
