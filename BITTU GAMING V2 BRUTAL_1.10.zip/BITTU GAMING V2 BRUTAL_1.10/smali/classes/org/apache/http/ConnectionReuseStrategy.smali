.class public abstract interface Lorg/apache/http/ConnectionReuseStrategy;
.super Ljava/lang/Object;
.source "ConnectionReuseStrategy.java"

# virtual methods
.method public abstract keepAlive(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)Z
.end method
