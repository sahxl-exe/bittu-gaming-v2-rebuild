.class public abstract interface Lorg/apache/http/Header;
.super Ljava/lang/Object;
.source "Header.java"

# virtual methods
.method public abstract getElements()[Lorg/apache/http/HeaderElement;
.end method

# virtual methods
.method public abstract getName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getValue()Ljava/lang/String;
.end method
