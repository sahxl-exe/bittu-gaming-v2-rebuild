.class public final Lorg/apache/http/protocol/BasicHttpProcessor;
.super Ljava/lang/Object;
.source "BasicHttpProcessor.java"
.implements Lorg/apache/http/protocol/HttpProcessor;
.implements Lorg/apache/http/protocol/HttpRequestInterceptorList;
.implements Lorg/apache/http/protocol/HttpResponseInterceptorList;

.field protected requestInterceptors:Ljava/util/List;
.field protected responseInterceptors:Ljava/util/List;

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public addInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addInterceptor(Lorg/apache/http/HttpRequestInterceptor;I)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addInterceptor(Lorg/apache/http/HttpResponseInterceptor;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addInterceptor(Lorg/apache/http/HttpResponseInterceptor;I)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;I)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;I)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public clearInterceptors()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public clearRequestInterceptors()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public clearResponseInterceptors()V
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public clone()Ljava/lang/Object;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public copy()Lorg/apache/http/protocol/BasicHttpProcessor;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected copyInterceptors(Lorg/apache/http/protocol/BasicHttpProcessor;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getRequestInterceptor(I)Lorg/apache/http/HttpRequestInterceptor;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getRequestInterceptorCount()I
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getResponseInterceptor(I)Lorg/apache/http/HttpResponseInterceptor;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public getResponseInterceptorCount()I
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public process(Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public process(Lorg/apache/http/HttpResponse;Lorg/apache/http/protocol/HttpContext;)V
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public removeRequestInterceptorByClass(Ljava/lang/Class;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public removeResponseInterceptorByClass(Ljava/lang/Class;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public setInterceptors(Ljava/util/List;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
