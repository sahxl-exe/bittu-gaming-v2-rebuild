.class public abstract interface Lorg/apache/http/protocol/HttpRequestInterceptorList;
.super Ljava/lang/Object;
.source "HttpRequestInterceptorList.java"

# virtual methods
.method public abstract addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;)V
.end method

# virtual methods
.method public abstract addRequestInterceptor(Lorg/apache/http/HttpRequestInterceptor;I)V
.end method

# virtual methods
.method public abstract clearRequestInterceptors()V
.end method

# virtual methods
.method public abstract getRequestInterceptor(I)Lorg/apache/http/HttpRequestInterceptor;
.end method

# virtual methods
.method public abstract getRequestInterceptorCount()I
.end method

# virtual methods
.method public abstract removeRequestInterceptorByClass(Ljava/lang/Class;)V
.end method

# virtual methods
.method public abstract setInterceptors(Ljava/util/List;)V
.end method
