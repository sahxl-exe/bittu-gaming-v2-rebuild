.class public final Lorg/apache/http/protocol/HTTP;
.super Ljava/lang/Object;
.source "HTTP.java"

.field public static final ASCII:Ljava/lang/String;
.field public static final CHARSET_PARAM:Ljava/lang/String;
.field public static final CHUNK_CODING:Ljava/lang/String;
.field public static final CONN_CLOSE:Ljava/lang/String;
.field public static final CONN_DIRECTIVE:Ljava/lang/String;
.field public static final CONN_KEEP_ALIVE:Ljava/lang/String;
.field public static final CONTENT_ENCODING:Ljava/lang/String;
.field public static final CONTENT_LEN:Ljava/lang/String;
.field public static final CONTENT_TYPE:Ljava/lang/String;
.field public static final CR:I
.field public static final DATE_HEADER:Ljava/lang/String;
.field public static final DEFAULT_CONTENT_CHARSET:Ljava/lang/String;
.field public static final DEFAULT_CONTENT_TYPE:Ljava/lang/String;
.field public static final DEFAULT_PROTOCOL_CHARSET:Ljava/lang/String;
.field public static final EXPECT_CONTINUE:Ljava/lang/String;
.field public static final EXPECT_DIRECTIVE:Ljava/lang/String;
.field public static final HT:I
.field public static final IDENTITY_CODING:Ljava/lang/String;
.field public static final ISO_8859_1:Ljava/lang/String;
.field public static final LF:I
.field public static final OCTET_STREAM_TYPE:Ljava/lang/String;
.field public static final PLAIN_TEXT_TYPE:Ljava/lang/String;
.field public static final SERVER_HEADER:Ljava/lang/String;
.field public static final SP:I
.field public static final TARGET_HOST:Ljava/lang/String;
.field public static final TRANSFER_ENCODING:Ljava/lang/String;
.field public static final USER_AGENT:Ljava/lang/String;
.field public static final US_ASCII:Ljava/lang/String;
.field public static final UTF_16:Ljava/lang/String;
.field public static final UTF_8:Ljava/lang/String;

# direct methods
.method constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# direct methods
.method public static isWhitespace(C)Z
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
