.class public abstract interface Lorg/apache/http/protocol/HttpContext;
.super Ljava/lang/Object;
.source "HttpContext.java"

.field public static final RESERVED_PREFIX:Ljava/lang/String;

# virtual methods
.method public abstract getAttribute(Ljava/lang/String;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract removeAttribute(Ljava/lang/String;)Ljava/lang/Object;
.end method

# virtual methods
.method public abstract setAttribute(Ljava/lang/String;Ljava/lang/Object;)V
.end method
