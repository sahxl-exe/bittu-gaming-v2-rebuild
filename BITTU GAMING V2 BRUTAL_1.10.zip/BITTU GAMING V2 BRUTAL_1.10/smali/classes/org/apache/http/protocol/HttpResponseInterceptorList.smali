.class public abstract interface Lorg/apache/http/protocol/HttpResponseInterceptorList;
.super Ljava/lang/Object;
.source "HttpResponseInterceptorList.java"

# virtual methods
.method public abstract addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;)V
.end method

# virtual methods
.method public abstract addResponseInterceptor(Lorg/apache/http/HttpResponseInterceptor;I)V
.end method

# virtual methods
.method public abstract clearResponseInterceptors()V
.end method

# virtual methods
.method public abstract getResponseInterceptor(I)Lorg/apache/http/HttpResponseInterceptor;
.end method

# virtual methods
.method public abstract getResponseInterceptorCount()I
.end method

# virtual methods
.method public abstract removeResponseInterceptorByClass(Ljava/lang/Class;)V
.end method

# virtual methods
.method public abstract setInterceptors(Ljava/util/List;)V
.end method
