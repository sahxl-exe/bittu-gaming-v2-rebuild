.class public abstract interface Lorg/apache/http/protocol/HttpProcessor;
.super Ljava/lang/Object;
.source "HttpProcessor.java"
.implements Lorg/apache/http/HttpRequestInterceptor;
.implements Lorg/apache/http/HttpResponseInterceptor;
