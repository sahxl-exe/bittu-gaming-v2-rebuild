.class public abstract interface Lorg/apache/http/protocol/ExecutionContext;
.super Ljava/lang/Object;
.source "ExecutionContext.java"

.field public static final HTTP_CONNECTION:Ljava/lang/String;
.field public static final HTTP_PROXY_HOST:Ljava/lang/String;
.field public static final HTTP_REQUEST:Ljava/lang/String;
.field public static final HTTP_REQ_SENT:Ljava/lang/String;
.field public static final HTTP_RESPONSE:Ljava/lang/String;
.field public static final HTTP_TARGET_HOST:Ljava/lang/String;
