.class public abstract interface Lorg/apache/http/HttpRequestFactory;
.super Ljava/lang/Object;
.source "HttpRequestFactory.java"

# virtual methods
.method public abstract newHttpRequest(Ljava/lang/String;Ljava/lang/String;)Lorg/apache/http/HttpRequest;
.end method

# virtual methods
.method public abstract newHttpRequest(Lorg/apache/http/RequestLine;)Lorg/apache/http/HttpRequest;
.end method
