.class public abstract interface Lorg/apache/http/HeaderElement;
.super Ljava/lang/Object;
.source "HeaderElement.java"

# virtual methods
.method public abstract getName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getParameter(I)Lorg/apache/http/NameValuePair;
.end method

# virtual methods
.method public abstract getParameterByName(Ljava/lang/String;)Lorg/apache/http/NameValuePair;
.end method

# virtual methods
.method public abstract getParameterCount()I
.end method

# virtual methods
.method public abstract getParameters()[Lorg/apache/http/NameValuePair;
.end method

# virtual methods
.method public abstract getValue()Ljava/lang/String;
.end method
