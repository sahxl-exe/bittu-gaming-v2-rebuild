.class public abstract interface Lorg/apache/http/HttpConnection;
.super Ljava/lang/Object;
.source "HttpConnection.java"

# virtual methods
.method public abstract close()V
.end method

# virtual methods
.method public abstract getMetrics()Lorg/apache/http/HttpConnectionMetrics;
.end method

# virtual methods
.method public abstract getSocketTimeout()I
.end method

# virtual methods
.method public abstract isOpen()Z
.end method

# virtual methods
.method public abstract isStale()Z
.end method

# virtual methods
.method public abstract setSocketTimeout(I)V
.end method

# virtual methods
.method public abstract shutdown()V
.end method
