.class public abstract interface Lorg/apache/http/TokenIterator;
.super Ljava/lang/Object;
.source "TokenIterator.java"
.implements Ljava/util/Iterator;

# virtual methods
.method public abstract hasNext()Z
.end method

# virtual methods
.method public abstract nextToken()Ljava/lang/String;
.end method
