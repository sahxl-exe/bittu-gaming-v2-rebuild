.class public abstract interface Lorg/apache/http/HttpInetConnection;
.super Ljava/lang/Object;
.source "HttpInetConnection.java"
.implements Lorg/apache/http/HttpConnection;

# virtual methods
.method public abstract getLocalAddress()Ljava/net/InetAddress;
.end method

# virtual methods
.method public abstract getLocalPort()I
.end method

# virtual methods
.method public abstract getRemoteAddress()Ljava/net/InetAddress;
.end method

# virtual methods
.method public abstract getRemotePort()I
.end method
