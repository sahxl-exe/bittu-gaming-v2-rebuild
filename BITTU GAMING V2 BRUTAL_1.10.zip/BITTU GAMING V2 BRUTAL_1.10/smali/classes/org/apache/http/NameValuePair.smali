.class public abstract interface Lorg/apache/http/NameValuePair;
.super Ljava/lang/Object;
.source "NameValuePair.java"

# virtual methods
.method public abstract getName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getValue()Ljava/lang/String;
.end method
