.class public final Lorg/apache/http/HttpVersion;
.super Lorg/apache/http/ProtocolVersion;
.source "HttpVersion.java"
.implements Ljava/io/Serializable;

.field public static final HTTP:Ljava/lang/String;
.field public static final HTTP_0_9:Lorg/apache/http/HttpVersion;
.field public static final HTTP_1_0:Lorg/apache/http/HttpVersion;
.field public static final HTTP_1_1:Lorg/apache/http/HttpVersion;

# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 0: const/4 v0, 0
    .line 1: sput-object v0, Lorg/apache/http/HttpVersion;->HTTP_0_9:Lorg/apache/http/HttpVersion;
    .line 3: sput-object v0, Lorg/apache/http/HttpVersion;->HTTP_1_0:Lorg/apache/http/HttpVersion;
    .line 5: sput-object v0, Lorg/apache/http/HttpVersion;->HTTP_1_1:Lorg/apache/http/HttpVersion;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(II)V
    .registers 5

    .line 0: const/4 v1, 0
    .line 1: const/4 v0, 0
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: invoke-direct {v2, v0, v1, v1}, Lorg/apache/http/ProtocolVersion;-><init>(Ljava/lang/String;II)V
    .line 7: new-instance v0, Ljava/lang/RuntimeException;
    .line 9: const-string v1, "Stub!"
    .line 11: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 14: throw v0
.end method

# virtual methods
.method public forVersion(II)Lorg/apache/http/ProtocolVersion;
    .registers 5

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
