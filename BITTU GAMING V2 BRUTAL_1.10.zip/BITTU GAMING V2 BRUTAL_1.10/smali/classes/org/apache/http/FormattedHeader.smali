.class public abstract interface Lorg/apache/http/FormattedHeader;
.super Ljava/lang/Object;
.source "FormattedHeader.java"
.implements Lorg/apache/http/Header;

# virtual methods
.method public abstract getBuffer()Lorg/apache/http/util/CharArrayBuffer;
.end method

# virtual methods
.method public abstract getValuePos()I
.end method
