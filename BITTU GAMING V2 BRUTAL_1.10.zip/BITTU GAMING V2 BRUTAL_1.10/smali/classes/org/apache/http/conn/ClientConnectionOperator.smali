.class public abstract interface Lorg/apache/http/conn/ClientConnectionOperator;
.super Ljava/lang/Object;
.source "ClientConnectionOperator.java"

# virtual methods
.method public abstract createConnection()Lorg/apache/http/conn/OperatedClientConnection;
.end method

# virtual methods
.method public abstract openConnection(Lorg/apache/http/conn/OperatedClientConnection;Lorg/apache/http/HttpHost;Ljava/net/InetAddress;Lorg/apache/http/protocol/HttpContext;Lorg/apache/http/params/HttpParams;)V
.end method

# virtual methods
.method public abstract updateSecureConnection(Lorg/apache/http/conn/OperatedClientConnection;Lorg/apache/http/HttpHost;Lorg/apache/http/protocol/HttpContext;Lorg/apache/http/params/HttpParams;)V
.end method
