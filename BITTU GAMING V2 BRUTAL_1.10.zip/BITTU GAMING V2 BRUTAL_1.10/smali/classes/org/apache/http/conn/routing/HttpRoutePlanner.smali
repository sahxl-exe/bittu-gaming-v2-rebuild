.class public abstract interface Lorg/apache/http/conn/routing/HttpRoutePlanner;
.super Ljava/lang/Object;
.source "HttpRoutePlanner.java"

# virtual methods
.method public abstract determineRoute(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/conn/routing/HttpRoute;
.end method
