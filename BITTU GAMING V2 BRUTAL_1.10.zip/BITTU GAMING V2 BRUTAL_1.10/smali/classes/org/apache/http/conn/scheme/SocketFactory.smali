.class public abstract interface Lorg/apache/http/conn/scheme/SocketFactory;
.super Ljava/lang/Object;
.source "SocketFactory.java"

# virtual methods
.method public abstract connectSocket(Ljava/net/Socket;Ljava/lang/String;ILjava/net/InetAddress;ILorg/apache/http/params/HttpParams;)Ljava/net/Socket;
.end method

# virtual methods
.method public abstract createSocket()Ljava/net/Socket;
.end method

# virtual methods
.method public abstract isSecure(Ljava/net/Socket;)Z
.end method
