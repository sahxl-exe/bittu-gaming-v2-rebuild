.class public abstract interface Lorg/apache/http/conn/params/ConnRoutePNames;
.super Ljava/lang/Object;
.source "ConnRoutePNames.java"

.field public static final DEFAULT_PROXY:Ljava/lang/String;
.field public static final FORCED_ROUTE:Ljava/lang/String;
.field public static final LOCAL_ADDRESS:Ljava/lang/String;
