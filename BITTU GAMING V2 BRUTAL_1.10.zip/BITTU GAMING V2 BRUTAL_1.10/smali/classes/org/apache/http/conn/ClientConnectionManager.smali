.class public abstract interface Lorg/apache/http/conn/ClientConnectionManager;
.super Ljava/lang/Object;
.source "ClientConnectionManager.java"

# virtual methods
.method public abstract closeExpiredConnections()V
.end method

# virtual methods
.method public abstract closeIdleConnections(JLjava/util/concurrent/TimeUnit;)V
.end method

# virtual methods
.method public abstract getSchemeRegistry()Lorg/apache/http/conn/scheme/SchemeRegistry;
.end method

# virtual methods
.method public abstract releaseConnection(Lorg/apache/http/conn/ManagedClientConnection;JLjava/util/concurrent/TimeUnit;)V
.end method

# virtual methods
.method public abstract requestConnection(Lorg/apache/http/conn/routing/HttpRoute;Ljava/lang/Object;)Lorg/apache/http/conn/ClientConnectionRequest;
.end method

# virtual methods
.method public abstract shutdown()V
.end method
