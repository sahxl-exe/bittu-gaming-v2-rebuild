.class public abstract interface Lorg/apache/http/conn/scheme/HostNameResolver;
.super Ljava/lang/Object;
.source "HostNameResolver.java"

# virtual methods
.method public abstract resolve(Ljava/lang/String;)Ljava/net/InetAddress;
.end method
