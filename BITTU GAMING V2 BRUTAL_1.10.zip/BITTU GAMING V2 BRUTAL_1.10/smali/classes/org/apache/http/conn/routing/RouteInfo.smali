.class public abstract interface Lorg/apache/http/conn/routing/RouteInfo;
.super Ljava/lang/Object;
.source "RouteInfo.java"

# virtual methods
.method public abstract getHopCount()I
.end method

# virtual methods
.method public abstract getHopTarget(I)Lorg/apache/http/HttpHost;
.end method

# virtual methods
.method public abstract getLayerType()Lorg/apache/http/conn/routing/RouteInfo$LayerType;
.end method

# virtual methods
.method public abstract getLocalAddress()Ljava/net/InetAddress;
.end method

# virtual methods
.method public abstract getProxyHost()Lorg/apache/http/HttpHost;
.end method

# virtual methods
.method public abstract getTargetHost()Lorg/apache/http/HttpHost;
.end method

# virtual methods
.method public abstract getTunnelType()Lorg/apache/http/conn/routing/RouteInfo$TunnelType;
.end method

# virtual methods
.method public abstract isLayered()Z
.end method

# virtual methods
.method public abstract isSecure()Z
.end method

# virtual methods
.method public abstract isTunnelled()Z
.end method
