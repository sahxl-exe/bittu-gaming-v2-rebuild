.class public final enum Lorg/apache/http/conn/routing/RouteInfo$LayerType;
.super Ljava/lang/Enum;
.source "RouteInfo.java"

.field private static final synthetic $VALUES:[Lorg/apache/http/conn/routing/RouteInfo$LayerType;
.field public static final enum LAYERED:Lorg/apache/http/conn/routing/RouteInfo$LayerType;
.field public static final enum PLAIN:Lorg/apache/http/conn/routing/RouteInfo$LayerType;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: const/4 v3, 1
    .line 1: const/4 v2, 0
    .line 2: new-instance v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 4: const-string v1, "LAYERED"
    .line 6: invoke-direct {v0, v1, v2}, Lorg/apache/http/conn/routing/RouteInfo$LayerType;-><init>(Ljava/lang/String;I)V
    .line 9: sput-object v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->LAYERED:Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 11: new-instance v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 13: const-string v1, "PLAIN"
    .line 15: invoke-direct {v0, v1, v3}, Lorg/apache/http/conn/routing/RouteInfo$LayerType;-><init>(Ljava/lang/String;I)V
    .line 18: sput-object v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->PLAIN:Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 20: const/4 v0, 2
    .line 21: new-array v0, v0, [Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 23: sget-object v1, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->LAYERED:Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 25: aput-object v1, v0, v2
    .line 27: sget-object v1, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->PLAIN:Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 29: aput-object v1, v0, v3
    .line 31: sput-object v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->$VALUES:[Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 33: return-void
.end method

# direct methods
.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 0: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    .line 3: return-void
.end method

# direct methods
.method public static valueOf(Ljava/lang/String;)Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .registers 2

    .line 0: const-class v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 2: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 8: return-object v0
.end method

# direct methods
.method public static values()[Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .registers 1

    .line 0: sget-object v0, Lorg/apache/http/conn/routing/RouteInfo$LayerType;->$VALUES:[Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 2: invoke-virtual {v0}, [Lorg/apache/http/conn/routing/RouteInfo$LayerType;->clone()Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, [Lorg/apache/http/conn/routing/RouteInfo$LayerType;
    .line 8: return-object v0
.end method
