.class public abstract interface Lorg/apache/http/conn/params/ConnManagerPNames;
.super Ljava/lang/Object;
.source "ConnManagerPNames.java"

.field public static final MAX_CONNECTIONS_PER_ROUTE:Ljava/lang/String;
.field public static final MAX_TOTAL_CONNECTIONS:Ljava/lang/String;
.field public static final TIMEOUT:Ljava/lang/String;
