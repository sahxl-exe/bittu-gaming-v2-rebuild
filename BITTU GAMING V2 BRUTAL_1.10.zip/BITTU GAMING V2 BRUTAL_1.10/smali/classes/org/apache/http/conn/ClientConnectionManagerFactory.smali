.class public abstract interface Lorg/apache/http/conn/ClientConnectionManagerFactory;
.super Ljava/lang/Object;
.source "ClientConnectionManagerFactory.java"

# virtual methods
.method public abstract newInstance(Lorg/apache/http/params/HttpParams;Lorg/apache/http/conn/scheme/SchemeRegistry;)Lorg/apache/http/conn/ClientConnectionManager;
.end method
