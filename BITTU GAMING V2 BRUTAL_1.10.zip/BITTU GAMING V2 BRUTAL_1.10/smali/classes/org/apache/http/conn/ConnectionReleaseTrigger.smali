.class public abstract interface Lorg/apache/http/conn/ConnectionReleaseTrigger;
.super Ljava/lang/Object;
.source "ConnectionReleaseTrigger.java"

# virtual methods
.method public abstract abortConnection()V
.end method

# virtual methods
.method public abstract releaseConnection()V
.end method
