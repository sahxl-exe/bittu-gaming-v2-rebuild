.class public abstract interface Lorg/apache/http/conn/scheme/LayeredSocketFactory;
.super Ljava/lang/Object;
.source "LayeredSocketFactory.java"
.implements Lorg/apache/http/conn/scheme/SocketFactory;

# virtual methods
.method public abstract createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;
.end method
