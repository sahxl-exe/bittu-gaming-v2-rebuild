.class public abstract interface Lorg/apache/http/conn/params/ConnPerRoute;
.super Ljava/lang/Object;
.source "ConnPerRoute.java"

# virtual methods
.method public abstract getMaxForRoute(Lorg/apache/http/conn/routing/HttpRoute;)I
.end method
