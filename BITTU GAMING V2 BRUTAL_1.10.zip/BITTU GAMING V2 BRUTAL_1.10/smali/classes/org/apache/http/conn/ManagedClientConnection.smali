.class public abstract interface Lorg/apache/http/conn/ManagedClientConnection;
.super Ljava/lang/Object;
.source "ManagedClientConnection.java"
.implements Lorg/apache/http/HttpClientConnection;
.implements Lorg/apache/http/HttpInetConnection;
.implements Lorg/apache/http/conn/ConnectionReleaseTrigger;

# virtual methods
.method public abstract getRoute()Lorg/apache/http/conn/routing/HttpRoute;
.end method

# virtual methods
.method public abstract getSSLSession()Ljavax/net/ssl/SSLSession;
.end method

# virtual methods
.method public abstract getState()Ljava/lang/Object;
.end method

# virtual methods
.method public abstract isMarkedReusable()Z
.end method

# virtual methods
.method public abstract isSecure()Z
.end method

# virtual methods
.method public abstract layerProtocol(Lorg/apache/http/protocol/HttpContext;Lorg/apache/http/params/HttpParams;)V
.end method

# virtual methods
.method public abstract markReusable()V
.end method

# virtual methods
.method public abstract open(Lorg/apache/http/conn/routing/HttpRoute;Lorg/apache/http/protocol/HttpContext;Lorg/apache/http/params/HttpParams;)V
.end method

# virtual methods
.method public abstract setIdleDuration(JLjava/util/concurrent/TimeUnit;)V
.end method

# virtual methods
.method public abstract setState(Ljava/lang/Object;)V
.end method

# virtual methods
.method public abstract tunnelProxy(Lorg/apache/http/HttpHost;ZLorg/apache/http/params/HttpParams;)V
.end method

# virtual methods
.method public abstract tunnelTarget(ZLorg/apache/http/params/HttpParams;)V
.end method

# virtual methods
.method public abstract unmarkReusable()V
.end method
