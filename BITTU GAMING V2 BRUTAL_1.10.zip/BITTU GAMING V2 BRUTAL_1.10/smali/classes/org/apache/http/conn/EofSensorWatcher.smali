.class public abstract interface Lorg/apache/http/conn/EofSensorWatcher;
.super Ljava/lang/Object;
.source "EofSensorWatcher.java"

# virtual methods
.method public abstract eofDetected(Ljava/io/InputStream;)Z
.end method

# virtual methods
.method public abstract streamAbort(Ljava/io/InputStream;)Z
.end method

# virtual methods
.method public abstract streamClosed(Ljava/io/InputStream;)Z
.end method
