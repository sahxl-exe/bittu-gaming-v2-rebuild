.class public abstract interface Lorg/apache/http/conn/ClientConnectionRequest;
.super Ljava/lang/Object;
.source "ClientConnectionRequest.java"

# virtual methods
.method public abstract abortRequest()V
.end method

# virtual methods
.method public abstract getConnection(JLjava/util/concurrent/TimeUnit;)Lorg/apache/http/conn/ManagedClientConnection;
.end method
