.class public final Lorg/apache/http/conn/scheme/SchemeRegistry;
.super Ljava/lang/Object;
.source "SchemeRegistry.java"

# direct methods
.method public constructor <init>()V
    .registers 3

    .line 0: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/lang/RuntimeException;
    .line 5: const-string v1, "Stub!"
    .line 7: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 10: throw v0
.end method

# virtual methods
.method public declared-synchronized get(Ljava/lang/String;)Lorg/apache/http/conn/scheme/Scheme;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getScheme(Ljava/lang/String;)Lorg/apache/http/conn/scheme/Scheme;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getScheme(Lorg/apache/http/HttpHost;)Lorg/apache/http/conn/scheme/Scheme;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized getSchemeNames()Ljava/util/List;
    .registers 3

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized register(Lorg/apache/http/conn/scheme/Scheme;)Lorg/apache/http/conn/scheme/Scheme;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized setItems(Ljava/util/Map;)V
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method

# virtual methods
.method public declared-synchronized unregister(Ljava/lang/String;)Lorg/apache/http/conn/scheme/Scheme;
    .registers 4

    .line 0: monitor-enter v2
    .line 1: new-instance v0, Ljava/lang/RuntimeException;
    .line 3: const-string v1, "Stub!"
    .line 5: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 8: throw v0
    .line 9: move-exception v0
    .line 10: monitor-exit v2
    .line 11: throw v0
.end method
