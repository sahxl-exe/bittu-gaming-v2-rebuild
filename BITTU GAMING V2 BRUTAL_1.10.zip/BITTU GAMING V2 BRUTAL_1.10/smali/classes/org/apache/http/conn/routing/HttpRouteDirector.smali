.class public abstract interface Lorg/apache/http/conn/routing/HttpRouteDirector;
.super Ljava/lang/Object;
.source "HttpRouteDirector.java"

.field public static final COMPLETE:I
.field public static final CONNECT_PROXY:I
.field public static final CONNECT_TARGET:I
.field public static final LAYER_PROTOCOL:I
.field public static final TUNNEL_PROXY:I
.field public static final TUNNEL_TARGET:I
.field public static final UNREACHABLE:I

# virtual methods
.method public abstract nextStep(Lorg/apache/http/conn/routing/RouteInfo;Lorg/apache/http/conn/routing/RouteInfo;)I
.end method
