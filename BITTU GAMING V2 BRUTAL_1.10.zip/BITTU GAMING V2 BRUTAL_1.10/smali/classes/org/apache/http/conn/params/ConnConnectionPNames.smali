.class public abstract interface Lorg/apache/http/conn/params/ConnConnectionPNames;
.super Ljava/lang/Object;
.source "ConnConnectionPNames.java"

.field public static final MAX_STATUS_LINE_GARBAGE:Ljava/lang/String;
