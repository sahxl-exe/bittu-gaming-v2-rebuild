.class public abstract interface Lorg/apache/http/entity/ContentLengthStrategy;
.super Ljava/lang/Object;
.source "ContentLengthStrategy.java"

.field public static final CHUNKED:I
.field public static final IDENTITY:I

# virtual methods
.method public abstract determineLength(Lorg/apache/http/HttpMessage;)J
.end method
