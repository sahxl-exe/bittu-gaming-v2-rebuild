.class public abstract interface Lorg/apache/http/HttpEntity;
.super Ljava/lang/Object;
.source "HttpEntity.java"

# virtual methods
.method public abstract consumeContent()V
.end method

# virtual methods
.method public abstract getContent()Ljava/io/InputStream;
.end method

# virtual methods
.method public abstract getContentEncoding()Lorg/apache/http/Header;
.end method

# virtual methods
.method public abstract getContentLength()J
.end method

# virtual methods
.method public abstract getContentType()Lorg/apache/http/Header;
.end method

# virtual methods
.method public abstract isChunked()Z
.end method

# virtual methods
.method public abstract isRepeatable()Z
.end method

# virtual methods
.method public abstract isStreaming()Z
.end method

# virtual methods
.method public abstract writeTo(Ljava/io/OutputStream;)V
.end method
