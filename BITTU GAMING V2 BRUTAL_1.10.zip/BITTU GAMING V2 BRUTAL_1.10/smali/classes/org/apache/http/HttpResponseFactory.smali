.class public abstract interface Lorg/apache/http/HttpResponseFactory;
.super Ljava/lang/Object;
.source "HttpResponseFactory.java"

# virtual methods
.method public abstract newHttpResponse(Lorg/apache/http/ProtocolVersion;ILorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
.end method

# virtual methods
.method public abstract newHttpResponse(Lorg/apache/http/StatusLine;Lorg/apache/http/protocol/HttpContext;)Lorg/apache/http/HttpResponse;
.end method
