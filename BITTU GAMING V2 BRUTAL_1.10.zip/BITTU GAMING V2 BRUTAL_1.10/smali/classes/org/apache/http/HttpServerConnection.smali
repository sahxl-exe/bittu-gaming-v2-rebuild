.class public abstract interface Lorg/apache/http/HttpServerConnection;
.super Ljava/lang/Object;
.source "HttpServerConnection.java"
.implements Lorg/apache/http/HttpConnection;

# virtual methods
.method public abstract flush()V
.end method

# virtual methods
.method public abstract receiveRequestEntity(Lorg/apache/http/HttpEntityEnclosingRequest;)V
.end method

# virtual methods
.method public abstract receiveRequestHeader()Lorg/apache/http/HttpRequest;
.end method

# virtual methods
.method public abstract sendResponseEntity(Lorg/apache/http/HttpResponse;)V
.end method

# virtual methods
.method public abstract sendResponseHeader(Lorg/apache/http/HttpResponse;)V
.end method
