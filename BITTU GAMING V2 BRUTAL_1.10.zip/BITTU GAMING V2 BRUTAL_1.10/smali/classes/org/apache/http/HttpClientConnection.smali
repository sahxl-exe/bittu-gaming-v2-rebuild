.class public abstract interface Lorg/apache/http/HttpClientConnection;
.super Ljava/lang/Object;
.source "HttpClientConnection.java"
.implements Lorg/apache/http/HttpConnection;

# virtual methods
.method public abstract flush()V
.end method

# virtual methods
.method public abstract isResponseAvailable(I)Z
.end method

# virtual methods
.method public abstract receiveResponseEntity(Lorg/apache/http/HttpResponse;)V
.end method

# virtual methods
.method public abstract receiveResponseHeader()Lorg/apache/http/HttpResponse;
.end method

# virtual methods
.method public abstract sendRequestEntity(Lorg/apache/http/HttpEntityEnclosingRequest;)V
.end method

# virtual methods
.method public abstract sendRequestHeader(Lorg/apache/http/HttpRequest;)V
.end method
