.class public abstract interface Lcom/android/internal/http/multipart/PartSource;
.super Ljava/lang/Object;
.source "PartSource.java"

# virtual methods
.method public abstract createInputStream()Ljava/io/InputStream;
.end method

# virtual methods
.method public abstract getFileName()Ljava/lang/String;
.end method

# virtual methods
.method public abstract getLength()J
.end method
