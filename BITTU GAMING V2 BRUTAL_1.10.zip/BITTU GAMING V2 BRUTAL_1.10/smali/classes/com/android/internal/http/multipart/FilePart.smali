.class public Lcom/android/internal/http/multipart/FilePart;
.super Lcom/android/internal/http/multipart/PartBase;
.source "FilePart.java"

.field public static final DEFAULT_CHARSET:Ljava/lang/String;
.field public static final DEFAULT_CONTENT_TYPE:Ljava/lang/String;
.field public static final DEFAULT_TRANSFER_ENCODING:Ljava/lang/String;
.field protected static final FILE_NAME:Ljava/lang/String;

# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/android/internal/http/multipart/PartSource;)V
    .registers 7

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/android/internal/http/multipart/PartSource;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/io/File;)V
    .registers 7

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V
    .registers 9

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)V
    .registers 8

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    .line 0: const/4 v1, 0
    .line 1: move-object v0, v1
    .line 2: check-cast v0, Ljava/lang/String;
    .line 4: move-object v2, v1
    .line 5: check-cast v2, Ljava/lang/String;
    .line 7: move-object v3, v1
    .line 8: check-cast v3, Ljava/lang/String;
    .line 10: check-cast v1, Ljava/lang/String;
    .line 12: invoke-direct {v4, v0, v2, v3, v1}, Lcom/android/internal/http/multipart/PartBase;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .line 15: new-instance v0, Ljava/lang/RuntimeException;
    .line 17: const-string v1, "Stub!"
    .line 19: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 22: throw v0
.end method

# virtual methods
.method protected getSource()Lcom/android/internal/http/multipart/PartSource;
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected lengthOfData()J
    .registers 3

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected sendData(Ljava/io/OutputStream;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method protected sendDispositionHeader(Ljava/io/OutputStream;)V
    .registers 4

    .line 0: new-instance v0, Ljava/lang/RuntimeException;
    .line 2: const-string v1, "Stub!"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method
