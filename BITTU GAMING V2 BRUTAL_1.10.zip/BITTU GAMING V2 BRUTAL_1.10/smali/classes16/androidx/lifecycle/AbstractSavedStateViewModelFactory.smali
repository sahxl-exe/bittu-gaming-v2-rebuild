.class public abstract Landroidx/lifecycle/AbstractSavedStateViewModelFactory;
.super Landroidx/lifecycle/ViewModelProvider$KeyedFactory;
.source "AbstractSavedStateViewModelFactory.java"

.field static final TAG_SAVED_STATE_HANDLE_CONTROLLER:Ljava/lang/String;

.field private final mDefaultArgs:Landroid/os/Bundle;
.field private final mLifecycle:Landroidx/lifecycle/Lifecycle;
.field private final mSavedStateRegistry:Landroidx/savedstate/SavedStateRegistry;

# direct methods
.method public constructor <init>(Landroidx/savedstate/SavedStateRegistryOwner;Landroid/os/Bundle;)V
    .registers 4

    .line 0: invoke-direct {v1}, Landroidx/lifecycle/ViewModelProvider$KeyedFactory;-><init>()V
    .line 3: invoke-interface {v2}, Landroidx/savedstate/SavedStateRegistryOwner;->getSavedStateRegistry()Landroidx/savedstate/SavedStateRegistry;
    .line 6: move-result-object v0
    .line 7: iput-object v0, v1, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mSavedStateRegistry:Landroidx/savedstate/SavedStateRegistry;
    .line 9: invoke-interface {v2}, Landroidx/savedstate/SavedStateRegistryOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;
    .line 12: move-result-object v0
    .line 13: iput-object v0, v1, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mLifecycle:Landroidx/lifecycle/Lifecycle;
    .line 15: iput-object v3, v1, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mDefaultArgs:Landroid/os/Bundle;
    .line 17: return-void
.end method

# virtual methods
.method public final create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_11
    .line 6: invoke-virtual {v3, v0, v4}, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->create(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .line 9: move-result-object v1
    .line 10: return-object v1
    .line 11: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 13: const-string v2, "Local and anonymous classes can not be ViewModels"
    .line 15: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 18: throw v1
.end method

# virtual methods
.method public final create(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 6

    .line 0: iget-object v0, v3, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mSavedStateRegistry:Landroidx/savedstate/SavedStateRegistry;
    .line 2: iget-object v1, v3, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mLifecycle:Landroidx/lifecycle/Lifecycle;
    .line 4: iget-object v2, v3, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mDefaultArgs:Landroid/os/Bundle;
    .line 6: invoke-static {v0, v1, v4, v2}, Landroidx/lifecycle/SavedStateHandleController;->create(Landroidx/savedstate/SavedStateRegistry;Landroidx/lifecycle/Lifecycle;Ljava/lang/String;Landroid/os/Bundle;)Landroidx/lifecycle/SavedStateHandleController;
    .line 9: move-result-object v0
    .line 10: invoke-virtual {v0}, Landroidx/lifecycle/SavedStateHandleController;->getHandle()Landroidx/lifecycle/SavedStateHandle;
    .line 13: move-result-object v1
    .line 14: invoke-virtual {v3, v4, v5, v1}, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->create(Ljava/lang/String;Ljava/lang/Class;Landroidx/lifecycle/SavedStateHandle;)Landroidx/lifecycle/ViewModel;
    .line 17: move-result-object v1
    .line 18: const-string v2, "androidx.lifecycle.savedstate.vm.tag"
    .line 20: invoke-virtual {v1, v2, v0}, Landroidx/lifecycle/ViewModel;->setTagIfAbsent(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .line 23: return-object v1
.end method

# virtual methods
.method protected abstract create(Ljava/lang/String;Ljava/lang/Class;Landroidx/lifecycle/SavedStateHandle;)Landroidx/lifecycle/ViewModel;
.end method

# virtual methods
.method  onRequery(Landroidx/lifecycle/ViewModel;)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mSavedStateRegistry:Landroidx/savedstate/SavedStateRegistry;
    .line 2: iget-object v1, v2, Landroidx/lifecycle/AbstractSavedStateViewModelFactory;->mLifecycle:Landroidx/lifecycle/Lifecycle;
    .line 4: invoke-static {v3, v0, v1}, Landroidx/lifecycle/SavedStateHandleController;->attachHandleIfNeeded(Landroidx/lifecycle/ViewModel;Landroidx/savedstate/SavedStateRegistry;Landroidx/lifecycle/Lifecycle;)V
    .line 7: return-void
.end method
