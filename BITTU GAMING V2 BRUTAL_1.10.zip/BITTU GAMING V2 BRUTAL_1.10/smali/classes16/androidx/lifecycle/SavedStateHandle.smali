.class public final Landroidx/lifecycle/SavedStateHandle;
.super Ljava/lang/Object;
.source "SavedStateHandle.java"

.field private static final ACCEPTABLE_CLASSES:[Ljava/lang/Class;
.field private static final KEYS:Ljava/lang/String;
.field private static final VALUES:Ljava/lang/String;

.field private final mLiveDatas:Ljava/util/Map;
.field final mRegular:Ljava/util/Map;
.field private final mSavedStateProvider:Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
.field final mSavedStateProviders:Ljava/util/Map;

# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 0: const/16 v0, 29
    .line 2: new-array v0, v0, [Ljava/lang/Class;
    .line 4: sget-object v1, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    .line 6: const/4 v2, 0
    .line 7: aput-object v1, v0, v2
    .line 9: const/4 v1, 1
    .line 10: const-class v2, [Z
    .line 12: aput-object v2, v0, v1
    .line 14: sget-object v1, Ljava/lang/Double;->TYPE:Ljava/lang/Class;
    .line 16: const/4 v2, 2
    .line 17: aput-object v1, v0, v2
    .line 19: const/4 v1, 3
    .line 20: const-class v2, [D
    .line 22: aput-object v2, v0, v1
    .line 24: sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 26: const/4 v2, 4
    .line 27: aput-object v1, v0, v2
    .line 29: const/4 v1, 5
    .line 30: const-class v2, [I
    .line 32: aput-object v2, v0, v1
    .line 34: sget-object v1, Ljava/lang/Long;->TYPE:Ljava/lang/Class;
    .line 36: const/4 v2, 6
    .line 37: aput-object v1, v0, v2
    .line 39: const/4 v1, 7
    .line 40: const-class v2, [J
    .line 42: aput-object v2, v0, v1
    .line 44: const/16 v1, 8
    .line 46: const-class v2, Ljava/lang/String;
    .line 48: aput-object v2, v0, v1
    .line 50: const/16 v1, 9
    .line 52: const-class v2, [Ljava/lang/String;
    .line 54: aput-object v2, v0, v1
    .line 56: const/16 v1, 10
    .line 58: const-class v2, Landroid/os/Binder;
    .line 60: aput-object v2, v0, v1
    .line 62: const/16 v1, 11
    .line 64: const-class v2, Landroid/os/Bundle;
    .line 66: aput-object v2, v0, v1
    .line 68: sget-object v1, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;
    .line 70: const/16 v2, 12
    .line 72: aput-object v1, v0, v2
    .line 74: const/16 v1, 13
    .line 76: const-class v2, [B
    .line 78: aput-object v2, v0, v1
    .line 80: sget-object v1, Ljava/lang/Character;->TYPE:Ljava/lang/Class;
    .line 82: const/16 v2, 14
    .line 84: aput-object v1, v0, v2
    .line 86: const/16 v1, 15
    .line 88: const-class v2, [C
    .line 90: aput-object v2, v0, v1
    .line 92: const/16 v1, 16
    .line 94: const-class v2, Ljava/lang/CharSequence;
    .line 96: aput-object v2, v0, v1
    .line 98: const/16 v1, 17
    .line 100: const-class v2, [Ljava/lang/CharSequence;
    .line 102: aput-object v2, v0, v1
    .line 104: const/16 v1, 18
    .line 106: const-class v2, Ljava/util/ArrayList;
    .line 108: aput-object v2, v0, v1
    .line 110: sget-object v1, Ljava/lang/Float;->TYPE:Ljava/lang/Class;
    .line 112: const/16 v2, 19
    .line 114: aput-object v1, v0, v2
    .line 116: const/16 v1, 20
    .line 118: const-class v2, [F
    .line 120: aput-object v2, v0, v1
    .line 122: const-class v1, Landroid/os/Parcelable;
    .line 124: const/16 v2, 21
    .line 126: aput-object v1, v0, v2
    .line 128: const/16 v1, 22
    .line 130: const-class v3, [Landroid/os/Parcelable;
    .line 132: aput-object v3, v0, v1
    .line 134: const/16 v1, 23
    .line 136: const-class v3, Ljava/io/Serializable;
    .line 138: aput-object v3, v0, v1
    .line 140: sget-object v1, Ljava/lang/Short;->TYPE:Ljava/lang/Class;
    .line 142: const/16 v3, 24
    .line 144: aput-object v1, v0, v3
    .line 146: const/16 v1, 25
    .line 148: const-class v3, [S
    .line 150: aput-object v3, v0, v1
    .line 152: const/16 v1, 26
    .line 154: const-class v3, Landroid/util/SparseArray;
    .line 156: aput-object v3, v0, v1
    .line 158: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 160: if-lt v1, v2, :cond_165
    .line 162: const-class v1, Landroid/util/Size;
    .line 164: goto :goto_167
    .line 165: sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 167: const/16 v3, 27
    .line 169: aput-object v1, v0, v3
    .line 171: const/16 v1, 28
    .line 173: sget v3, Landroid/os/Build$VERSION;->SDK_INT:I
    .line 175: if-lt v3, v2, :cond_180
    .line 177: const-class v2, Landroid/util/SizeF;
    .line 179: goto :goto_182
    .line 180: sget-object v2, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    .line 182: aput-object v2, v0, v1
    .line 184: sput-object v0, Landroidx/lifecycle/SavedStateHandle;->ACCEPTABLE_CLASSES:[Ljava/lang/Class;
    .line 186: return-void
.end method

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 17: new-instance v0, Landroidx/lifecycle/SavedStateHandle$1;
    .line 19: invoke-direct {v0, v1}, Landroidx/lifecycle/SavedStateHandle$1;-><init>(Landroidx/lifecycle/SavedStateHandle;)V
    .line 22: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProvider:Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
    .line 24: new-instance v0, Ljava/util/HashMap;
    .line 26: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 29: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 31: return-void
.end method

# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .registers 3

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 17: new-instance v0, Landroidx/lifecycle/SavedStateHandle$1;
    .line 19: invoke-direct {v0, v1}, Landroidx/lifecycle/SavedStateHandle$1;-><init>(Landroidx/lifecycle/SavedStateHandle;)V
    .line 22: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProvider:Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
    .line 24: new-instance v0, Ljava/util/HashMap;
    .line 26: invoke-direct {v0, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V
    .line 29: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 31: return-void
.end method

# direct methods
.method static createHandle(Landroid/os/Bundle;Landroid/os/Bundle;)Landroidx/lifecycle/SavedStateHandle;
    .registers 8

    .line 0: if-nez v6, :cond_10
    .line 2: if-nez v7, :cond_10
    .line 4: new-instance v0, Landroidx/lifecycle/SavedStateHandle;
    .line 6: invoke-direct {v0}, Landroidx/lifecycle/SavedStateHandle;-><init>()V
    .line 9: return-object v0
    .line 10: new-instance v0, Ljava/util/HashMap;
    .line 12: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 15: if-eqz v7, :cond_45
    .line 17: invoke-virtual {v7}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    .line 20: move-result-object v1
    .line 21: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 24: move-result-object v1
    .line 25: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 28: move-result v2
    .line 29: if-eqz v2, :cond_45
    .line 31: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 34: move-result-object v2
    .line 35: check-cast v2, Ljava/lang/String;
    .line 37: invoke-virtual {v7, v2}, Landroid/os/Bundle;->get(Ljava/lang/String;)Ljava/lang/Object;
    .line 40: move-result-object v3
    .line 41: invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 44: goto :goto_25
    .line 45: if-nez v6, :cond_53
    .line 47: new-instance v1, Landroidx/lifecycle/SavedStateHandle;
    .line 49: invoke-direct {v1, v0}, Landroidx/lifecycle/SavedStateHandle;-><init>(Ljava/util/Map;)V
    .line 52: return-object v1
    .line 53: const-string v1, "keys"
    .line 55: invoke-virtual {v6, v1}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 58: move-result-object v1
    .line 59: const-string v2, "values"
    .line 61: invoke-virtual {v6, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;
    .line 64: move-result-object v2
    .line 65: if-eqz v1, :cond_108
    .line 67: if-eqz v2, :cond_108
    .line 69: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 72: move-result v3
    .line 73: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 76: move-result v4
    .line 77: if-ne v3, v4, :cond_108
    .line 79: const/4 v3, 0
    .line 80: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    .line 83: move-result v4
    .line 84: if-ge v3, v4, :cond_102
    .line 86: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 89: move-result-object v4
    .line 90: check-cast v4, Ljava/lang/String;
    .line 92: invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    .line 95: move-result-object v5
    .line 96: invoke-interface {v0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 99: add-int/lit8 v3, v3, 1
    .line 101: goto :goto_80
    .line 102: new-instance v3, Landroidx/lifecycle/SavedStateHandle;
    .line 104: invoke-direct {v3, v0}, Landroidx/lifecycle/SavedStateHandle;-><init>(Ljava/util/Map;)V
    .line 107: return-object v3
    .line 108: new-instance v3, Ljava/lang/IllegalStateException;
    .line 110: const-string v4, "Invalid bundle passed as restored state"
    .line 112: invoke-direct {v3, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    .line 115: goto :goto_117
    .line 116: throw v3
    .line 117: goto :goto_116
.end method

# direct methods
.method private getLiveDataInternal(Ljava/lang/String;ZLjava/lang/Object;)Landroidx/lifecycle/MutableLiveData;
    .registers 7

    .line 0: iget-object v0, v3, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 2: invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/MutableLiveData;
    .line 8: if-eqz v0, :cond_11
    .line 10: return-object v0
    .line 11: iget-object v1, v3, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 13: invoke-interface {v1, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 16: move-result v1
    .line 17: if-eqz v1, :cond_31
    .line 19: new-instance v1, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;
    .line 21: iget-object v2, v3, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 23: invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 26: move-result-object v2
    .line 27: invoke-direct {v1, v3, v4, v2}, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;-><init>(Landroidx/lifecycle/SavedStateHandle;Ljava/lang/String;Ljava/lang/Object;)V
    .line 30: goto :goto_44
    .line 31: if-eqz v5, :cond_39
    .line 33: new-instance v1, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;
    .line 35: invoke-direct {v1, v3, v4, v6}, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;-><init>(Landroidx/lifecycle/SavedStateHandle;Ljava/lang/String;Ljava/lang/Object;)V
    .line 38: goto :goto_44
    .line 39: new-instance v1, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;
    .line 41: invoke-direct {v1, v3, v4}, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;-><init>(Landroidx/lifecycle/SavedStateHandle;Ljava/lang/String;)V
    .line 44: iget-object v2, v3, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 46: invoke-interface {v2, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 49: return-object v1
.end method

# direct methods
.method private static validateValue(Ljava/lang/Object;)V
    .registers 6

    .line 0: if-nez v5, :cond_3
    .line 2: return-void
    .line 3: sget-object v0, Landroidx/lifecycle/SavedStateHandle;->ACCEPTABLE_CLASSES:[Ljava/lang/Class;
    .line 5: array-length v1, v0
    .line 6: const/4 v2, 0
    .line 7: if-ge v2, v1, :cond_21
    .line 9: aget-object v3, v0, v2
    .line 11: invoke-virtual {v3, v5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 14: move-result v4
    .line 15: if-eqz v4, :cond_18
    .line 17: return-void
    .line 18: add-int/lit8 v2, v2, 1
    .line 20: goto :goto_7
    .line 21: new-instance v0, Ljava/lang/IllegalArgumentException;
    .line 23: new-instance v1, Ljava/lang/StringBuilder;
    .line 25: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 28: const-string v2, "Can't put value with type "
    .line 30: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 33: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    .line 36: move-result-object v2
    .line 37: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 40: const-string v2, " into saved state"
    .line 42: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v1
    .line 49: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 52: goto :goto_54
    .line 53: throw v0
    .line 54: goto :goto_53
.end method

# virtual methods
.method public clearSavedStateProvider(Ljava/lang/String;)V
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 2: invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: return-void
.end method

# virtual methods
.method public contains(Ljava/lang/String;)Z
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 2: invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    .line 5: move-result v0
    .line 6: return v0
.end method

# virtual methods
.method public get(Ljava/lang/String;)Ljava/lang/Object;
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 2: invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public getLiveData(Ljava/lang/String;)Landroidx/lifecycle/MutableLiveData;
    .registers 4

    .line 0: const/4 v0, 0
    .line 1: const/4 v1, 0
    .line 2: invoke-direct {v2, v3, v0, v1}, Landroidx/lifecycle/SavedStateHandle;->getLiveDataInternal(Ljava/lang/String;ZLjava/lang/Object;)Landroidx/lifecycle/MutableLiveData;
    .line 5: move-result-object v0
    .line 6: return-object v0
.end method

# virtual methods
.method public getLiveData(Ljava/lang/String;Ljava/lang/Object;)Landroidx/lifecycle/MutableLiveData;
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: invoke-direct {v1, v2, v0, v3}, Landroidx/lifecycle/SavedStateHandle;->getLiveDataInternal(Ljava/lang/String;ZLjava/lang/Object;)Landroidx/lifecycle/MutableLiveData;
    .line 4: move-result-object v0
    .line 5: return-object v0
.end method

# virtual methods
.method public keys()Ljava/util/Set;
    .registers 3

    .line 0: new-instance v0, Ljava/util/HashSet;
    .line 2: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 4: invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;
    .line 7: move-result-object v1
    .line 8: invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V
    .line 11: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 13: invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;
    .line 16: move-result-object v1
    .line 17: invoke-virtual {v0, v1}, Ljava/util/HashSet;->addAll(Ljava/util/Collection;)Z
    .line 20: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 22: invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;
    .line 25: move-result-object v1
    .line 26: invoke-virtual {v0, v1}, Ljava/util/HashSet;->addAll(Ljava/util/Collection;)Z
    .line 29: return-object v0
.end method

# virtual methods
.method public remove(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 2: invoke-interface {v0, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 8: invoke-interface {v1, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    .line 11: move-result-object v1
    .line 12: check-cast v1, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;
    .line 14: if-eqz v1, :cond_19
    .line 16: invoke-virtual {v1}, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->detach()V
    .line 19: return-object v0
.end method

# virtual methods
.method  savedStateProvider()Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProvider:Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
    .line 2: return-object v0
.end method

# virtual methods
.method public set(Ljava/lang/String;Ljava/lang/Object;)V
    .registers 5

    .line 0: invoke-static {v4}, Landroidx/lifecycle/SavedStateHandle;->validateValue(Ljava/lang/Object;)V
    .line 3: iget-object v0, v2, Landroidx/lifecycle/SavedStateHandle;->mLiveDatas:Ljava/util/Map;
    .line 5: invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 8: move-result-object v0
    .line 9: check-cast v0, Landroidx/lifecycle/MutableLiveData;
    .line 11: if-eqz v0, :cond_17
    .line 13: invoke-virtual {v0, v4}, Landroidx/lifecycle/MutableLiveData;->setValue(Ljava/lang/Object;)V
    .line 16: goto :goto_22
    .line 17: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 19: invoke-interface {v1, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 22: return-void
.end method

# virtual methods
.method public setSavedStateProvider(Ljava/lang/String;Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 2: invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: return-void
.end method
