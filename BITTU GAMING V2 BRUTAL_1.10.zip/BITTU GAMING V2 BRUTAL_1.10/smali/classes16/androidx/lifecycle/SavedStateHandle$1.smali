.class  Landroidx/lifecycle/SavedStateHandle$1;
.super Ljava/lang/Object;
.source "SavedStateHandle.java"
.implements Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;

.field final synthetic this$0:Landroidx/lifecycle/SavedStateHandle;

# direct methods
.method constructor <init>(Landroidx/lifecycle/SavedStateHandle;)V
    .registers 2

    .line 0: iput-object v1, v0, Landroidx/lifecycle/SavedStateHandle$1;->this$0:Landroidx/lifecycle/SavedStateHandle;
    .line 2: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 5: return-void
.end method

# virtual methods
.method public saveState()Landroid/os/Bundle;
    .registers 8

    .line 0: new-instance v0, Ljava/util/HashMap;
    .line 2: iget-object v1, v7, Landroidx/lifecycle/SavedStateHandle$1;->this$0:Landroidx/lifecycle/SavedStateHandle;
    .line 4: iget-object v1, v1, Landroidx/lifecycle/SavedStateHandle;->mSavedStateProviders:Ljava/util/Map;
    .line 6: invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V
    .line 9: invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    .line 12: move-result-object v1
    .line 13: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 16: move-result-object v1
    .line 17: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 20: move-result v2
    .line 21: if-eqz v2, :cond_51
    .line 23: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 26: move-result-object v2
    .line 27: check-cast v2, Ljava/util/Map$Entry;
    .line 29: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    .line 32: move-result-object v3
    .line 33: check-cast v3, Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;
    .line 35: invoke-interface {v3}, Landroidx/savedstate/SavedStateRegistry$SavedStateProvider;->saveState()Landroid/os/Bundle;
    .line 38: move-result-object v3
    .line 39: iget-object v4, v7, Landroidx/lifecycle/SavedStateHandle$1;->this$0:Landroidx/lifecycle/SavedStateHandle;
    .line 41: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    .line 44: move-result-object v5
    .line 45: check-cast v5, Ljava/lang/String;
    .line 47: invoke-virtual {v4, v5, v3}, Landroidx/lifecycle/SavedStateHandle;->set(Ljava/lang/String;Ljava/lang/Object;)V
    .line 50: goto :goto_17
    .line 51: iget-object v1, v7, Landroidx/lifecycle/SavedStateHandle$1;->this$0:Landroidx/lifecycle/SavedStateHandle;
    .line 53: iget-object v1, v1, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 55: invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;
    .line 58: move-result-object v1
    .line 59: new-instance v2, Ljava/util/ArrayList;
    .line 61: invoke-interface {v1}, Ljava/util/Set;->size()I
    .line 64: move-result v3
    .line 65: invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V
    .line 68: new-instance v3, Ljava/util/ArrayList;
    .line 70: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    .line 73: move-result v4
    .line 74: invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V
    .line 77: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    .line 80: move-result-object v4
    .line 81: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    .line 84: move-result v5
    .line 85: if-eqz v5, :cond_108
    .line 87: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 90: move-result-object v5
    .line 91: check-cast v5, Ljava/lang/String;
    .line 93: invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 96: iget-object v6, v7, Landroidx/lifecycle/SavedStateHandle$1;->this$0:Landroidx/lifecycle/SavedStateHandle;
    .line 98: iget-object v6, v6, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 100: invoke-interface {v6, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 103: move-result-object v6
    .line 104: invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    .line 107: goto :goto_81
    .line 108: new-instance v4, Landroid/os/Bundle;
    .line 110: invoke-direct {v4}, Landroid/os/Bundle;-><init>()V
    .line 113: const-string v5, "keys"
    .line 115: invoke-virtual {v4, v5, v2}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V
    .line 118: const-string v5, "values"
    .line 120: invoke-virtual {v4, v5, v3}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V
    .line 123: return-object v4
.end method
