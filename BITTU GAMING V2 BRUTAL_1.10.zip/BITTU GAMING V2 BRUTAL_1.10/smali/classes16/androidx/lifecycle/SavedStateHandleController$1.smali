.class  Landroidx/lifecycle/SavedStateHandleController$1;
.super Ljava/lang/Object;
.source "SavedStateHandleController.java"
.implements Landroidx/lifecycle/LifecycleEventObserver;

.field final synthetic val$lifecycle:Landroidx/lifecycle/Lifecycle;
.field final synthetic val$registry:Landroidx/savedstate/SavedStateRegistry;

# direct methods
.method constructor <init>(Landroidx/lifecycle/Lifecycle;Landroidx/savedstate/SavedStateRegistry;)V
    .registers 3

    .line 0: iput-object v1, v0, Landroidx/lifecycle/SavedStateHandleController$1;->val$lifecycle:Landroidx/lifecycle/Lifecycle;
    .line 2: iput-object v2, v0, Landroidx/lifecycle/SavedStateHandleController$1;->val$registry:Landroidx/savedstate/SavedStateRegistry;
    .line 4: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 7: return-void
.end method

# virtual methods
.method public onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 5

    .line 0: sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;
    .line 2: if-ne v4, v0, :cond_16
    .line 4: iget-object v0, v2, Landroidx/lifecycle/SavedStateHandleController$1;->val$lifecycle:Landroidx/lifecycle/Lifecycle;
    .line 6: invoke-virtual {v0, v2}, Landroidx/lifecycle/Lifecycle;->removeObserver(Landroidx/lifecycle/LifecycleObserver;)V
    .line 9: iget-object v0, v2, Landroidx/lifecycle/SavedStateHandleController$1;->val$registry:Landroidx/savedstate/SavedStateRegistry;
    .line 11: const-class v1, Landroidx/lifecycle/SavedStateHandleController$OnRecreation;
    .line 13: invoke-virtual {v0, v1}, Landroidx/savedstate/SavedStateRegistry;->runOnNextRecreation(Ljava/lang/Class;)V
    .line 16: return-void
.end method
