.class  Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;
.super Landroidx/lifecycle/MutableLiveData;
.source "SavedStateHandle.java"

.field private mHandle:Landroidx/lifecycle/SavedStateHandle;
.field private mKey:Ljava/lang/String;

# direct methods
.method constructor <init>(Landroidx/lifecycle/SavedStateHandle;Ljava/lang/String;)V
    .registers 3

    .line 0: invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V
    .line 3: iput-object v2, v0, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mKey:Ljava/lang/String;
    .line 5: iput-object v1, v0, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mHandle:Landroidx/lifecycle/SavedStateHandle;
    .line 7: return-void
.end method

# direct methods
.method constructor <init>(Landroidx/lifecycle/SavedStateHandle;Ljava/lang/String;Ljava/lang/Object;)V
    .registers 4

    .line 0: invoke-direct {v0, v3}, Landroidx/lifecycle/MutableLiveData;-><init>(Ljava/lang/Object;)V
    .line 3: iput-object v2, v0, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mKey:Ljava/lang/String;
    .line 5: iput-object v1, v0, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mHandle:Landroidx/lifecycle/SavedStateHandle;
    .line 7: return-void
.end method

# virtual methods
.method  detach()V
    .registers 2

    .line 0: const/4 v0, 0
    .line 1: iput-object v0, v1, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mHandle:Landroidx/lifecycle/SavedStateHandle;
    .line 3: return-void
.end method

# virtual methods
.method public setValue(Ljava/lang/Object;)V
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mHandle:Landroidx/lifecycle/SavedStateHandle;
    .line 2: if-eqz v0, :cond_11
    .line 4: iget-object v0, v0, Landroidx/lifecycle/SavedStateHandle;->mRegular:Ljava/util/Map;
    .line 6: iget-object v1, v2, Landroidx/lifecycle/SavedStateHandle$SavingStateLiveData;->mKey:Ljava/lang/String;
    .line 8: invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 11: invoke-super {v2, v3}, Landroidx/lifecycle/MutableLiveData;->setValue(Ljava/lang/Object;)V
    .line 14: return-void
.end method
