.class public Landroidx/lifecycle/ViewModelProvider;
.super Ljava/lang/Object;
.source "ViewModelProvider.java"

.field private static final DEFAULT_KEY:Ljava/lang/String;

.field private final mFactory:Landroidx/lifecycle/ViewModelProvider$Factory;
.field private final mViewModelStore:Landroidx/lifecycle/ViewModelStore;

# direct methods
.method public constructor <init>(Landroidx/lifecycle/ViewModelStore;Landroidx/lifecycle/ViewModelProvider$Factory;)V
    .registers 3

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: iput-object v2, v0, Landroidx/lifecycle/ViewModelProvider;->mFactory:Landroidx/lifecycle/ViewModelProvider$Factory;
    .line 5: iput-object v1, v0, Landroidx/lifecycle/ViewModelProvider;->mViewModelStore:Landroidx/lifecycle/ViewModelStore;
    .line 7: return-void
.end method

# direct methods
.method public constructor <init>(Landroidx/lifecycle/ViewModelStoreOwner;)V
    .registers 4

    .line 0: invoke-interface {v3}, Landroidx/lifecycle/ViewModelStoreOwner;->getViewModelStore()Landroidx/lifecycle/ViewModelStore;
    .line 3: move-result-object v0
    .line 4: instance-of v1, v3, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;
    .line 6: if-eqz v1, :cond_16
    .line 8: move-object v1, v3
    .line 9: check-cast v1, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;
    .line 11: invoke-interface {v1}, Landroidx/lifecycle/HasDefaultViewModelProviderFactory;->getDefaultViewModelProviderFactory()Landroidx/lifecycle/ViewModelProvider$Factory;
    .line 14: move-result-object v1
    .line 15: goto :goto_20
    .line 16: invoke-static {}, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;->getInstance()Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .line 19: move-result-object v1
    .line 20: invoke-direct {v2, v0, v1}, Landroidx/lifecycle/ViewModelProvider;-><init>(Landroidx/lifecycle/ViewModelStore;Landroidx/lifecycle/ViewModelProvider$Factory;)V
    .line 23: return-void
.end method

# direct methods
.method public constructor <init>(Landroidx/lifecycle/ViewModelStoreOwner;Landroidx/lifecycle/ViewModelProvider$Factory;)V
    .registers 4

    .line 0: invoke-interface {v2}, Landroidx/lifecycle/ViewModelStoreOwner;->getViewModelStore()Landroidx/lifecycle/ViewModelStore;
    .line 3: move-result-object v0
    .line 4: invoke-direct {v1, v0, v3}, Landroidx/lifecycle/ViewModelProvider;-><init>(Landroidx/lifecycle/ViewModelStore;Landroidx/lifecycle/ViewModelProvider$Factory;)V
    .line 7: return-void
.end method

# virtual methods
.method public get(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 5

    .line 0: invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;
    .line 3: move-result-object v0
    .line 4: if-eqz v0, :cond_28
    .line 6: new-instance v1, Ljava/lang/StringBuilder;
    .line 8: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    .line 11: const-string v2, "androidx.lifecycle.ViewModelProvider.DefaultKey:"
    .line 13: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 16: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 19: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 22: move-result-object v1
    .line 23: invoke-virtual {v3, v1, v4}, Landroidx/lifecycle/ViewModelProvider;->get(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .line 26: move-result-object v1
    .line 27: return-object v1
    .line 28: new-instance v1, Ljava/lang/IllegalArgumentException;
    .line 30: const-string v2, "Local and anonymous classes can not be ViewModels"
    .line 32: invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    .line 35: throw v1
.end method

# virtual methods
.method public get(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 6

    .line 0: iget-object v0, v3, Landroidx/lifecycle/ViewModelProvider;->mViewModelStore:Landroidx/lifecycle/ViewModelStore;
    .line 2: invoke-virtual {v0, v4}, Landroidx/lifecycle/ViewModelStore;->get(Ljava/lang/String;)Landroidx/lifecycle/ViewModel;
    .line 5: move-result-object v0
    .line 6: invoke-virtual {v5, v0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z
    .line 9: move-result v1
    .line 10: if-eqz v1, :cond_24
    .line 12: iget-object v1, v3, Landroidx/lifecycle/ViewModelProvider;->mFactory:Landroidx/lifecycle/ViewModelProvider$Factory;
    .line 14: instance-of v2, v1, Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;
    .line 16: if-eqz v2, :cond_23
    .line 18: check-cast v1, Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;
    .line 20: invoke-virtual {v1, v0}, Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;->onRequery(Landroidx/lifecycle/ViewModel;)V
    .line 23: return-object v0
    .line 24: nop
    .line 25: iget-object v1, v3, Landroidx/lifecycle/ViewModelProvider;->mFactory:Landroidx/lifecycle/ViewModelProvider$Factory;
    .line 27: instance-of v2, v1, Landroidx/lifecycle/ViewModelProvider$KeyedFactory;
    .line 29: if-eqz v2, :cond_38
    .line 31: check-cast v1, Landroidx/lifecycle/ViewModelProvider$KeyedFactory;
    .line 33: invoke-virtual {v1, v4, v5}, Landroidx/lifecycle/ViewModelProvider$KeyedFactory;->create(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .line 36: move-result-object v0
    .line 37: goto :goto_42
    .line 38: invoke-interface {v1, v5}, Landroidx/lifecycle/ViewModelProvider$Factory;->create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .line 41: move-result-object v0
    .line 42: iget-object v1, v3, Landroidx/lifecycle/ViewModelProvider;->mViewModelStore:Landroidx/lifecycle/ViewModelStore;
    .line 44: invoke-virtual {v1, v4, v0}, Landroidx/lifecycle/ViewModelStore;->put(Ljava/lang/String;Landroidx/lifecycle/ViewModel;)V
    .line 47: return-object v0
.end method
