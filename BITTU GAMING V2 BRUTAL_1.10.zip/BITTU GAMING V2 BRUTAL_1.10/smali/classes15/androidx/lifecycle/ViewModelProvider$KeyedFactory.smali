.class abstract Landroidx/lifecycle/ViewModelProvider$KeyedFactory;
.super Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;
.source "ViewModelProvider.java"
.implements Landroidx/lifecycle/ViewModelProvider$Factory;

# direct methods
.method constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method public create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 4

    .line 0: new-instance v0, Ljava/lang/UnsupportedOperationException;
    .line 2: const-string v1, "create(String, Class<?>) must be called on implementaions of KeyedFactory"
    .line 4: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    .line 7: throw v0
.end method

# virtual methods
.method public abstract create(Ljava/lang/String;Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
.end method
