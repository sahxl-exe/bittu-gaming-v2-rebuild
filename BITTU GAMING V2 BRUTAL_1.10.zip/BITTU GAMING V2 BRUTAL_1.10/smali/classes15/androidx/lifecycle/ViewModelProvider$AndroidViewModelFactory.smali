.class public Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
.super Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
.source "ViewModelProvider.java"

.field private static sInstance:Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;

.field private mApplication:Landroid/app/Application;

# direct methods
.method public constructor <init>(Landroid/app/Application;)V
    .registers 2

    .line 0: invoke-direct {v0}, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;->mApplication:Landroid/app/Application;
    .line 5: return-void
.end method

# direct methods
.method public static getInstance(Landroid/app/Application;)Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
    .registers 2

    .line 0: sget-object v0, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
    .line 2: if-nez v0, :cond_11
    .line 4: new-instance v0, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
    .line 6: invoke-direct {v0, v1}, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;-><init>(Landroid/app/Application;)V
    .line 9: sput-object v0, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
    .line 11: sget-object v0, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;
    .line 13: return-object v0
.end method

# virtual methods
.method public create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 7

    .line 0: const-string v0, "Cannot create an instance of "
    .line 2: const-class v1, Landroidx/lifecycle/AndroidViewModel;
    .line 4: invoke-virtual {v1, v6}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z
    .line 7: move-result v1
    .line 8: if-eqz v1, :cond_123
    .line 10: const/4 v1, 1
    .line 11: new-array v2, v1, [Ljava/lang/Class;
    .line 13: const-class v3, Landroid/app/Application;
    .line 15: const/4 v4, 0
    .line 16: aput-object v3, v2, v4
    .line 18: invoke-virtual {v6, v2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    .line 21: move-result-object v2
    .line 22: new-array v1, v1, [Ljava/lang/Object;
    .line 24: iget-object v3, v5, Landroidx/lifecycle/ViewModelProvider$AndroidViewModelFactory;->mApplication:Landroid/app/Application;
    .line 26: aput-object v3, v1, v4
    .line 28: invoke-virtual {v2, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    .line 31: move-result-object v1
    .line 32: check-cast v1, Landroidx/lifecycle/ViewModel;
    .line 34: return-object v1
    .line 35: move-exception v1
    .line 36: new-instance v2, Ljava/lang/RuntimeException;
    .line 38: new-instance v3, Ljava/lang/StringBuilder;
    .line 40: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 43: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 46: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 49: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 52: move-result-object v0
    .line 53: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 56: throw v2
    .line 57: move-exception v1
    .line 58: new-instance v2, Ljava/lang/RuntimeException;
    .line 60: new-instance v3, Ljava/lang/StringBuilder;
    .line 62: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 65: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 68: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 71: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 74: move-result-object v0
    .line 75: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 78: throw v2
    .line 79: move-exception v1
    .line 80: new-instance v2, Ljava/lang/RuntimeException;
    .line 82: new-instance v3, Ljava/lang/StringBuilder;
    .line 84: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 87: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 90: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 93: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 96: move-result-object v0
    .line 97: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 100: throw v2
    .line 101: move-exception v1
    .line 102: new-instance v2, Ljava/lang/RuntimeException;
    .line 104: new-instance v3, Ljava/lang/StringBuilder;
    .line 106: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 109: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 112: invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 115: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 118: move-result-object v0
    .line 119: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 122: throw v2
    .line 123: invoke-super {v5, v6}, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;->create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .line 126: move-result-object v0
    .line 127: return-object v0
.end method
