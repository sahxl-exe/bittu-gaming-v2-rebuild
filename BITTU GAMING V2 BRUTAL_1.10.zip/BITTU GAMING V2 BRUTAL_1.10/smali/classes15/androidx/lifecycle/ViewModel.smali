.class public abstract Landroidx/lifecycle/ViewModel;
.super Ljava/lang/Object;
.source "ViewModel.java"

.field private final mBagOfTags:Ljava/util/Map;
.field private volatile mCleared:Z

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 10: const/4 v0, 0
    .line 11: iput-boolean v0, v1, Landroidx/lifecycle/ViewModel;->mCleared:Z
    .line 13: return-void
.end method

# direct methods
.method private static closeWithRuntimeException(Ljava/lang/Object;)V
    .registers 3

    .line 0: instance-of v0, v2, Ljava/io/Closeable;
    .line 2: if-eqz v0, :cond_18
    .line 4: move-object v0, v2
    .line 5: check-cast v0, Ljava/io/Closeable;
    .line 7: invoke-interface {v0}, Ljava/io/Closeable;->close()V
    .line 10: goto :goto_18
    .line 11: move-exception v0
    .line 12: new-instance v1, Ljava/lang/RuntimeException;
    .line 14: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V
    .line 17: throw v1
    .line 18: return-void
.end method

# virtual methods
.method final clear()V
    .registers 4

    .line 0: const/4 v0, 1
    .line 1: iput-boolean v0, v3, Landroidx/lifecycle/ViewModel;->mCleared:Z
    .line 3: iget-object v0, v3, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 5: if-eqz v0, :cond_37
    .line 7: monitor-enter v0
    .line 8: iget-object v1, v3, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 10: invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;
    .line 13: move-result-object v1
    .line 14: invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 17: move-result-object v1
    .line 18: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    .line 21: move-result v2
    .line 22: if-eqz v2, :cond_32
    .line 24: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 27: move-result-object v2
    .line 28: invoke-static {v2}, Landroidx/lifecycle/ViewModel;->closeWithRuntimeException(Ljava/lang/Object;)V
    .line 31: goto :goto_18
    .line 32: monitor-exit v0
    .line 33: goto :goto_37
    .line 34: move-exception v1
    .line 35: monitor-exit v0
    .line 36: throw v1
    .line 37: invoke-virtual {v3}, Landroidx/lifecycle/ViewModel;->onCleared()V
    .line 40: return-void
.end method

# virtual methods
.method  getTag(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .line 0: iget-object v0, v2, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 2: if-nez v0, :cond_6
    .line 4: const/4 v0, 0
    .line 5: return-object v0
    .line 6: monitor-enter v0
    .line 7: iget-object v1, v2, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 9: invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 12: move-result-object v1
    .line 13: monitor-exit v0
    .line 14: return-object v1
    .line 15: move-exception v1
    .line 16: monitor-exit v0
    .line 17: throw v1
.end method

# virtual methods
.method protected onCleared()V
    .registers 1

    .line 0: return-void
.end method

# virtual methods
.method  setTagIfAbsent(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0: iget-object v0, v3, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 2: monitor-enter v0
    .line 3: iget-object v1, v3, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 5: invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 8: move-result-object v1
    .line 9: if-nez v1, :cond_16
    .line 11: iget-object v2, v3, Landroidx/lifecycle/ViewModel;->mBagOfTags:Ljava/util/Map;
    .line 13: invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 16: monitor-exit v0
    .line 17: if-nez v1, :cond_21
    .line 19: move-object v0, v5
    .line 20: goto :goto_22
    .line 21: move-object v0, v1
    .line 22: iget-boolean v2, v3, Landroidx/lifecycle/ViewModel;->mCleared:Z
    .line 24: if-eqz v2, :cond_29
    .line 26: invoke-static {v0}, Landroidx/lifecycle/ViewModel;->closeWithRuntimeException(Ljava/lang/Object;)V
    .line 29: return-object v0
    .line 30: move-exception v1
    .line 31: monitor-exit v0
    .line 32: throw v1
.end method
