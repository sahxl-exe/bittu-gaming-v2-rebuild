.class  Landroidx/lifecycle/ViewModelProvider$OnRequeryFactory;
.super Ljava/lang/Object;
.source "ViewModelProvider.java"

# direct methods
.method constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# virtual methods
.method  onRequery(Landroidx/lifecycle/ViewModel;)V
    .registers 2

    .line 0: return-void
.end method
