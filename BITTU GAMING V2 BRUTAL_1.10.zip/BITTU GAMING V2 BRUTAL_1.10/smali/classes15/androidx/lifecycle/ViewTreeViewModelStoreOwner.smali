.class public Landroidx/lifecycle/ViewTreeViewModelStoreOwner;
.super Ljava/lang/Object;
.source "ViewTreeViewModelStoreOwner.java"

# direct methods
.method private constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method public static get(Landroid/view/View;)Landroidx/lifecycle/ViewModelStoreOwner;
    .registers 5

    .line 0: sget v0, Landroidx/lifecycle/viewmodel/R$id;->view_tree_view_model_store_owner:I
    .line 2: invoke-virtual {v4, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/ViewModelStoreOwner;
    .line 8: if-eqz v0, :cond_11
    .line 10: return-object v0
    .line 11: invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 14: move-result-object v1
    .line 15: if-nez v0, :cond_38
    .line 17: instance-of v2, v1, Landroid/view/View;
    .line 19: if-eqz v2, :cond_38
    .line 21: move-object v2, v1
    .line 22: check-cast v2, Landroid/view/View;
    .line 24: sget v3, Landroidx/lifecycle/viewmodel/R$id;->view_tree_view_model_store_owner:I
    .line 26: invoke-virtual {v2, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;
    .line 29: move-result-object v3
    .line 30: move-object v0, v3
    .line 31: check-cast v0, Landroidx/lifecycle/ViewModelStoreOwner;
    .line 33: invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    .line 36: move-result-object v1
    .line 37: goto :goto_15
    .line 38: return-object v0
.end method

# direct methods
.method public static set(Landroid/view/View;Landroidx/lifecycle/ViewModelStoreOwner;)V
    .registers 3

    .line 0: sget v0, Landroidx/lifecycle/viewmodel/R$id;->view_tree_view_model_store_owner:I
    .line 2: invoke-virtual {v1, v0, v2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V
    .line 5: return-void
.end method
