.class public abstract interface Landroidx/lifecycle/ViewModelStoreOwner;
.super Ljava/lang/Object;
.source "ViewModelStoreOwner.java"

# virtual methods
.method public abstract getViewModelStore()Landroidx/lifecycle/ViewModelStore;
.end method
