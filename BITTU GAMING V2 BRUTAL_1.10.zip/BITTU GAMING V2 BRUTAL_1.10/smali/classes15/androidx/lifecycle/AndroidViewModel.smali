.class public Landroidx/lifecycle/AndroidViewModel;
.super Landroidx/lifecycle/ViewModel;
.source "AndroidViewModel.java"

.field private mApplication:Landroid/app/Application;

# direct methods
.method public constructor <init>(Landroid/app/Application;)V
    .registers 2

    .line 0: invoke-direct {v0}, Landroidx/lifecycle/ViewModel;-><init>()V
    .line 3: iput-object v1, v0, Landroidx/lifecycle/AndroidViewModel;->mApplication:Landroid/app/Application;
    .line 5: return-void
.end method

# virtual methods
.method public getApplication()Landroid/app/Application;
    .registers 2

    .line 0: iget-object v0, v1, Landroidx/lifecycle/AndroidViewModel;->mApplication:Landroid/app/Application;
    .line 2: return-object v0
.end method
