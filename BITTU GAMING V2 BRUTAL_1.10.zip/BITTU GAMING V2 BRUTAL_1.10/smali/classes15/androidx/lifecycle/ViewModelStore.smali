.class public Landroidx/lifecycle/ViewModelStore;
.super Ljava/lang/Object;
.source "ViewModelStore.java"

.field private final mMap:Ljava/util/HashMap;

# direct methods
.method public constructor <init>()V
    .registers 2

    .line 0: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    .line 3: new-instance v0, Ljava/util/HashMap;
    .line 5: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    .line 8: iput-object v0, v1, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 10: return-void
.end method

# virtual methods
.method public final clear()V
    .registers 3

    .line 0: iget-object v0, v2, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 2: invoke-virtual {v0}, Ljava/util/HashMap;->values()Ljava/util/Collection;
    .line 5: move-result-object v0
    .line 6: invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;
    .line 9: move-result-object v0
    .line 10: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    .line 13: move-result v1
    .line 14: if-eqz v1, :cond_26
    .line 16: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    .line 19: move-result-object v1
    .line 20: check-cast v1, Landroidx/lifecycle/ViewModel;
    .line 22: invoke-virtual {v1}, Landroidx/lifecycle/ViewModel;->clear()V
    .line 25: goto :goto_10
    .line 26: iget-object v0, v2, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 28: invoke-virtual {v0}, Ljava/util/HashMap;->clear()V
    .line 31: return-void
.end method

# virtual methods
.method final get(Ljava/lang/String;)Landroidx/lifecycle/ViewModel;
    .registers 3

    .line 0: iget-object v0, v1, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 2: invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/ViewModel;
    .line 8: return-object v0
.end method

# virtual methods
.method  keys()Ljava/util/Set;
    .registers 3

    .line 0: new-instance v0, Ljava/util/HashSet;
    .line 2: iget-object v1, v2, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 4: invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;
    .line 7: move-result-object v1
    .line 8: invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V
    .line 11: return-object v0
.end method

# virtual methods
.method final put(Ljava/lang/String;Landroidx/lifecycle/ViewModel;)V
    .registers 4

    .line 0: iget-object v0, v1, Landroidx/lifecycle/ViewModelStore;->mMap:Ljava/util/HashMap;
    .line 2: invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .line 5: move-result-object v0
    .line 6: check-cast v0, Landroidx/lifecycle/ViewModel;
    .line 8: if-eqz v0, :cond_13
    .line 10: invoke-virtual {v0}, Landroidx/lifecycle/ViewModel;->onCleared()V
    .line 13: return-void
.end method
