.class public Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
.super Ljava/lang/Object;
.source "ViewModelProvider.java"
.implements Landroidx/lifecycle/ViewModelProvider$Factory;

.field private static sInstance:Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;

# direct methods
.method public constructor <init>()V
    .registers 1

    .line 0: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    .line 3: return-void
.end method

# direct methods
.method static getInstance()Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .registers 1

    .line 0: sget-object v0, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .line 2: if-nez v0, :cond_11
    .line 4: new-instance v0, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .line 6: invoke-direct {v0}, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;-><init>()V
    .line 9: sput-object v0, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .line 11: sget-object v0, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;->sInstance:Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;
    .line 13: return-object v0
.end method

# virtual methods
.method public create(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;
    .registers 6

    .line 0: const-string v0, "Cannot create an instance of "
    .line 2: invoke-virtual {v5}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;
    .line 5: move-result-object v1
    .line 6: check-cast v1, Landroidx/lifecycle/ViewModel;
    .line 8: return-object v1
    .line 9: move-exception v1
    .line 10: new-instance v2, Ljava/lang/RuntimeException;
    .line 12: new-instance v3, Ljava/lang/StringBuilder;
    .line 14: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 17: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 20: invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 23: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 26: move-result-object v0
    .line 27: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 30: throw v2
    .line 31: move-exception v1
    .line 32: new-instance v2, Ljava/lang/RuntimeException;
    .line 34: new-instance v3, Ljava/lang/StringBuilder;
    .line 36: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    .line 39: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .line 42: invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    .line 45: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    .line 48: move-result-object v0
    .line 49: invoke-direct {v2, v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .line 52: throw v2
.end method
